package com.dell.prism.eagle.directreceiving.validation.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PoRequestModel {
	private String poNumber;
	private String operatingUnit;
	private String invOrgCode;

}
