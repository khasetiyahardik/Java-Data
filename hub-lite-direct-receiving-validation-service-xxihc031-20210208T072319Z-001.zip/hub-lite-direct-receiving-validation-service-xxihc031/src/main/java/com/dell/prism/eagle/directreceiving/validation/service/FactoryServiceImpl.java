package com.dell.prism.eagle.directreceiving.validation.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.dell.prism.eagle.directreceiving.validation.ebs.repository.EbsPoRepository;
import com.dell.prism.eagle.directreceiving.validation.model.Factory;
import com.dell.prism.eagle.directreceiving.validation.model.PoResponseModel;
import com.dell.prism.eagle.directreceiving.validation.repository.FactoryRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FactoryServiceImpl implements FactoryService {

	@Autowired
	private FactoryRepository factoryRepository;

	@Autowired
	EbsPoRepository ebsPoRepository;

	@Cacheable(cacheNames="poResponse")
	@Override
	public PoResponseModel getEbsPoResponse(String factory, String poNumber) throws IOException {
		Factory factoryDetails = factoryRepository.getInvOrgCodeAndOU(factory);

		log.info("invoking ebs store procedure for po details.");
		log.debug("invoking ebs store procedure for po details for poRequestModel:" + factoryDetails.toString());

		return ebsPoRepository.invokePoEbsProc(factoryDetails.getFactoryOrgCode(), factoryDetails.getOperatingUnit(),
				poNumber);

	}
}