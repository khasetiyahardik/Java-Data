package com.dell.prism.eagle.directreceiving.validation.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class ItemDescriptionModel {

	private String itemDescription;
	private String status;
	private String errorMessage;
}