package com.dell.prism.eagle.directreceiving.validation.config;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.dell.prism.eagle.directreceiving.validation.ebs.repository.EbsUtil;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackageClasses = {
		EbsUtil.class }, entityManagerFactoryRef = "ebsEMF", transactionManagerRef = "ebsTM")
public class EbsConfig {

	@Primary
	@Bean(name = "ebsDSProperties")
	@ConfigurationProperties(prefix = "spring.oracle.datasource")
	public DataSourceProperties ebsDSProperties() {
		return new DataSourceProperties();
	}

	@Primary
	@Bean("ebsDS")
	public DataSource ebsDS(@Qualifier("ebsDSProperties") DataSourceProperties ebsDSProperties) {
		DataSource dataSource = (DataSource) ebsDSProperties.initializeDataSourceBuilder().build();
		dataSource.setTestOnBorrow(true);
		return dataSource;
	}

	
}