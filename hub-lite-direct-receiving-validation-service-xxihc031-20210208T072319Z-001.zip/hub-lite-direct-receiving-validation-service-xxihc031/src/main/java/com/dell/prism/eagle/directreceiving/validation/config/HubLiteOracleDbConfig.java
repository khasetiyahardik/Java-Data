package com.dell.prism.eagle.directreceiving.validation.config;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

//@EnableJpaRepositories(basePackageClasses = { DestinationForHubRepository.class, FactoryDestinationRepository.class,
//		FactoryForHubRepository.class, FactoryRepository.class, HubsForFactoryRepository.class, ReasonCodeRepository.class,
//		SlcHubsRepository.class}, entityManagerFactoryRef = "hubOraEMF", transactionManagerRef = "hubOraTM")

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages =  "com.dell.prism.eagle.directreceiving.validation.repository", 
entityManagerFactoryRef = "hubOraEMF", transactionManagerRef = "hubOraTM")
public class HubLiteOracleDbConfig {

	@Bean(name = "hubOraDSProperties")
	@ConfigurationProperties(prefix = "spring.hublite.oracle.datasource")
	public DataSourceProperties hubOraDSProperties() {
		return new DataSourceProperties();
	}

	@Bean("hubOraDS")
	public DataSource hubOraDS(@Qualifier("hubOraDSProperties") DataSourceProperties hubOraDSProperties) {
		return hubOraDSProperties.initializeDataSourceBuilder().build();
	}

	@Bean("hubOraEMF")
	public LocalContainerEntityManagerFactoryBean hubOraEMF(@Qualifier("hubOraDS") DataSource hubOraDS,
			EntityManagerFactoryBuilder builder) {
		return builder.dataSource(hubOraDS).packages("com.dell.prism.eagle.directreceiving.validation.model").build();
	}
	
	@Bean
	public PlatformTransactionManager hubOraTM(@Qualifier("hubOraEMF") EntityManagerFactory hubOraFactory) {
		return new JpaTransactionManager(hubOraFactory);
	}

}