package com.dell.prism.eagle.directreceiving.validation.model;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PO {

	@JsonProperty("po_header_id")
	private BigDecimal poHeaderId;

	@JsonProperty("po_number")
	private BigDecimal poNumber;

	@JsonProperty("po_style")
	private String poStyle;

	@JsonProperty("po_revision")
	private BigDecimal poRevision;

	@JsonProperty("operating_unit")
	private String operatingUnit;

	@JsonProperty("buyer_code")
	private String buyerCode;

	@JsonProperty("buyer_name")
	private String buyerName;

	@JsonProperty("vendor")
	private String vendor;

	@JsonProperty("venloc")
	private String venLoc;

	@JsonProperty("vendor_number")
	private BigDecimal vendorNumber;

	@JsonProperty("vendor_name")
	private String vendorName;

	@JsonProperty("vendor_site_code")
	private String vendorSiteCode;

	@JsonProperty("vendor_site_ccn")
	private String vendorSiteCcn;

	@JsonProperty("po_status")
	private String poStatus;

	@JsonProperty("PO_LINES")
	private List<POLine> poLines = null;
}
