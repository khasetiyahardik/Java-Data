package com.dell.prism.eagle.directreceiving.validation.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class POLineLocation {

	@JsonProperty("line_location_id")
	private BigDecimal lineLocationId;

	@JsonProperty("po_distribution_id")
	private BigDecimal poDistributionId;

	@JsonProperty("po_header_id")
	private BigDecimal poHeaderId;

	@JsonProperty("po_line_id")
	private BigDecimal poLineId;

	@JsonProperty("shipment_num")
	private BigDecimal shipmentNum;

	@JsonProperty("quantity")
	private BigDecimal quantity;

	@JsonProperty("quantity_received")
	private BigDecimal quantityReceived;

	@JsonProperty("quantity_accepted")
	private BigDecimal quantityAccepted;

	@JsonProperty("quantity_rejected")
	private BigDecimal quantityRejected;

	@JsonProperty("quantity_billed")
	private BigDecimal quantityBilled;

	@JsonProperty("quantity_cancelled")
	private BigDecimal quantityCancelled;

	@JsonProperty("inventory_org_code")
	private String inventoryOrgCode;
	
	@JsonProperty("inventory_org")
	private String inventoryOrg;

	@JsonProperty("po_shipment_status")
	private String poShipmentStatus;
}
