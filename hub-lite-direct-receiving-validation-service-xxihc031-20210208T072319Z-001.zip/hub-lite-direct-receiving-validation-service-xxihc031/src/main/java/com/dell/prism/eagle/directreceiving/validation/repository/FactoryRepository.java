package com.dell.prism.eagle.directreceiving.validation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dell.prism.eagle.directreceiving.validation.constant.DirectReceivingValidationConstant;
import com.dell.prism.eagle.directreceiving.validation.model.Factory;

@Repository
public interface FactoryRepository extends JpaRepository<Factory, String> {

	@Query(value = DirectReceivingValidationConstant.FACTORIES_QUERY, nativeQuery = true)
	public Factory getInvOrgCodeAndOU(@Param(DirectReceivingValidationConstant.P_FACTORY) String pFactory);

}
