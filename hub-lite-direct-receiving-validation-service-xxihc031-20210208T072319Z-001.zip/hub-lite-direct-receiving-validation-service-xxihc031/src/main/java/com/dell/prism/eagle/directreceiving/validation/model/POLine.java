package com.dell.prism.eagle.directreceiving.validation.model;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class POLine {

	@JsonProperty("po_header_id")
	private BigDecimal poHeaderId;

	@JsonProperty("po_line_id")
	private BigDecimal poLineId;

	@JsonProperty("line_num")
	private BigDecimal lineNum;

	@JsonProperty("item_number")
	private String itemNumber;

	@JsonProperty("item_description")
	private String itemDescription;

	@JsonProperty("unit_price")
	private BigDecimal unitPrice;

	@JsonProperty("cost_type")
	private String costType;

	@JsonProperty("quantity")
	private BigDecimal quantity;

	@JsonProperty("open_quantity")
	private BigDecimal openQuantity;

	@JsonProperty("vendor_item_num")
	private String vendorItemNum;

	@JsonProperty("po_line_status")
	private String poLineStatus;

	@JsonProperty("PO_LINE_LOCATIONS")
	private List<POLineLocation> poLineLocations = null;

}