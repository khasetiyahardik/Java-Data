package com.dell.prism.eagle.directreceiving.validation.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.dell.prism.eagle.directreceiving.validation.model.ItemDescriptionModel;

@FeignClient(name = "spring-cloud-gateway-procurement", url = "${cloud.gateway.service.url:localhost:8080}")
public interface FeignProxy {

	@GetMapping(("/v1/getItemDescription"))
	public ItemDescriptionModel callItemValidationService(@RequestHeader("Authorization") String authHeader,
			@RequestHeader("x-dell-dais-sa-subscriber-id") String clientId, @RequestParam("factory") String invOrgCode,
			@RequestParam("itemNumber") String itemNumber);
}