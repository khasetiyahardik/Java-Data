package com.dell.prism.eagle.directreceiving.validation.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@IdClass(Factory.class)
public class Factory implements Serializable {

	@Id
	@Column(name = "factory_org_code")
	private String factoryOrgCode;
	@Id
	@Column(name = "factory_name")
	private String factoryOrgName;

	@Column(name = "operating_unit")
	private String operatingUnit;

}
