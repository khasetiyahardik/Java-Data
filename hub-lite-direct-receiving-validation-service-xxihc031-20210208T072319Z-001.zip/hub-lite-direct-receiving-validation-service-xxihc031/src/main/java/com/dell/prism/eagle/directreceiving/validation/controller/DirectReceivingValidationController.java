package com.dell.prism.eagle.directreceiving.validation.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dell.prism.eagle.directreceiving.validation.feign.FeignProxy;
import com.dell.prism.eagle.directreceiving.validation.feign.Integrator;
import com.dell.prism.eagle.directreceiving.validation.model.ItemDescriptionModel;
import com.dell.prism.eagle.directreceiving.validation.model.PO;
import com.dell.prism.eagle.directreceiving.validation.model.PODetailsJson;
import com.dell.prism.eagle.directreceiving.validation.model.POLine;
import com.dell.prism.eagle.directreceiving.validation.model.PoResponseModel;
import com.dell.prism.eagle.directreceiving.validation.model.ResponseModel;
import com.dell.prism.eagle.directreceiving.validation.service.FactoryService;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;

@RestController
@CrossOrigin
@Slf4j
public class DirectReceivingValidationController {

	@Autowired
	private FactoryService factoryService;

	@Autowired
	private Integrator integrator;

	@GetMapping("v1/getInvOrgAndOU")
	public void getInvOrgCodeAndOU(@RequestParam(value = "pFactory") String pFactory,
			@RequestParam(value = "poNumber") String poNumber, @RequestParam(value = "packslip") String packslip)
			throws IOException {

		if (!StringUtils.isEmpty(poNumber)) {
			// if po number is not null
			factoryService.getEbsPoResponse(pFactory, poNumber);
		} else {
			// if po number is null
			String itemNumber = "YX84Y";
			ItemDescriptionModel itemDescriptionModel = integrator.callItemValidationService(pFactory, itemNumber);
			log.info("itemDescriptionModel :" + itemDescriptionModel.toString());

		}

	}

	@GetMapping("v1/getItemDetails")
	public ResponseEntity<ResponseModel> getItemDetails(@RequestParam(value = "pFactory") String pFactory,
			@RequestParam(value = "poNumber") String poNumber, @RequestParam(value = "itemNumber") String itemNumber)
			throws IOException {
		PoResponseModel poResponseModel = factoryService.getEbsPoResponse(pFactory, poNumber);
		ResponseModel response = new ResponseModel();

		ObjectMapper mapper = new ObjectMapper();
		PODetailsJson poDetailsJson = mapper.readValue(poResponseModel.getPoDetails(), PODetailsJson.class);
		if (null != poDetailsJson && null != poDetailsJson.getPo() && !poDetailsJson.getPo().isEmpty()) {
			PO po = poDetailsJson.getPo().get(0);
			List<POLine> poLine = po.getPoLines();
			for (int i = 0; i < poLine.size(); i++) {

				if (poLine.get(i).getPoLineStatus().equalsIgnoreCase("OPEN")
						&& poLine.get(i).getItemNumber().equalsIgnoreCase(itemNumber)) {
					response.setItemDescription(poLine.get(i).getItemDescription());
				} else {
					response.setErrorMessage(
							"Item : " + itemNumber + " does not exist in the PO : " + poNumber + " in PRISM.");
				}
			}
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping("v1/getVendorDetails")
	public ResponseEntity<ResponseModel> getVendorDetails(@RequestParam(value = "pFactory") String pFactory,
			@RequestParam(value = "poNumber") String poNumber, @RequestParam(value = "vendor") String vendor,
			@RequestParam(value = "vendorLoc") String vendorLoc) throws IOException {
		PoResponseModel poResponseModel = factoryService.getEbsPoResponse(pFactory, poNumber);
		ResponseModel response = new ResponseModel();

		ObjectMapper mapper = new ObjectMapper();
		PODetailsJson poDetailsJson = mapper.readValue(poResponseModel.getPoDetails(), PODetailsJson.class);
		if (null != poDetailsJson && null != poDetailsJson.getPo() && !poDetailsJson.getPo().isEmpty()) {
			PO po = poDetailsJson.getPo().get(0);
			if (po.getVendor().equalsIgnoreCase(vendor) && po.getVenLoc().equalsIgnoreCase(vendorLoc)) {
				response.setVendorName(po.getVendorName());
			} else {
				response.setErrorMessage("Vendor :  " + vendor + " and VendorLoc :  " + vendorLoc
						+ " does not exist in the PO : " + poNumber + " in PRISM.");
			}
		}

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping("v1/clearCache")
	@CacheEvict(cacheNames = "poResponse", allEntries = true)
	public void clearCache() {
	}

}