package com.dell.prism.eagle.directreceiving.validation.config;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ClientDetails {

	@JsonProperty("grant_type")
	private String grantType;

	public ClientDetails(String grantType) {
		super();
		this.grantType = grantType;
	}
}