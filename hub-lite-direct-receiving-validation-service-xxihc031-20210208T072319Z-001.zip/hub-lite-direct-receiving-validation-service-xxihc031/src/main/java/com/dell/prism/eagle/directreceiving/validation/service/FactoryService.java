package com.dell.prism.eagle.directreceiving.validation.service;

import java.io.IOException;

import com.dell.prism.eagle.directreceiving.validation.model.PoResponseModel;

public interface FactoryService {

	//Factory getInvOrgCodeAndOU(String pFactory);

	public PoResponseModel getEbsPoResponse(String factory, String poNumber)
			throws IOException;
}