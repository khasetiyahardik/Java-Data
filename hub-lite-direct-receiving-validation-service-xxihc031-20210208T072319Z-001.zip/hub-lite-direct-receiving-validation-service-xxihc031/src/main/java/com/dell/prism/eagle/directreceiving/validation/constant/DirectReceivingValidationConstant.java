package com.dell.prism.eagle.directreceiving.validation.constant;

public class DirectReceivingValidationConstant {

	private DirectReceivingValidationConstant() {
	}

	public static final String ITEM_DESCRIPTION_URL = "v1/getItemDescription";
	public static final String REASON_CODE_URL = "v1/getReasoncodeDummy";
	public static final String FAILURE = "FAILURE";
	public static final String Y = "Y";
	public static final String PO_DETAILS_URL = "v1/getPoDetails";

	public static final String FACTORIES_QUERY = "SELECT * FROM hublght.XXIHC031_PRC_FACTORY WHERE factory_name = :pFactory";
	public static final String P_FACTORY = "pFactory";

	public static final String X_ERROR_MESSAGE = "x_error_msg";
	public static final String X_STATUS_CODE = "x_status_code";
	public static final String ONHAND_STORE_PROCEDURE = "XXIHC031_PO_HUB_COLLAB_PKG.direct_rec_po";

//	EBS Constants.

	public static final String PO_STORE_PROCEDURE = "XXIHC031_PO_HUB_COLLAB_PKG.direct_rec_po";
	public static final String CATALOG_NAME = "APPS";
	public static final String P_OPERATING_UNIT = "p_operating_unit";
	public static final String P_INV_ORG_CODE = "p_inv_org_code";
	public static final String P_PO_NUMBER = "p_po_number";

	public static final String X_PO_DETAILS = "x_po_details";

}