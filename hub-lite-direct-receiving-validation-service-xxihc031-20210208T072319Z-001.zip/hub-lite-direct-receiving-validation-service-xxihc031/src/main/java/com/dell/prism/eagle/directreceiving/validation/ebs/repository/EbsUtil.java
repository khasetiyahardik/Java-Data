package com.dell.prism.eagle.directreceiving.validation.ebs.repository;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Clob;
import java.sql.SQLException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EbsUtil {

	private EbsUtil() {}

	public static String clobToStringConversion(Clob clb) {
		if (clb == null) { return ""; }
		try(BufferedReader bufferRead = new BufferedReader(clb.getCharacterStream(), 2048);) {
			StringBuilder str = new StringBuilder();
			String strng;
			while ((strng = bufferRead.readLine()) != null) {
				str.append(strng);
			}
			return str.toString();
		} catch (IOException | SQLException e) {
			log.error("Exception in reading json ", e);
		}
		return null;
	}
}