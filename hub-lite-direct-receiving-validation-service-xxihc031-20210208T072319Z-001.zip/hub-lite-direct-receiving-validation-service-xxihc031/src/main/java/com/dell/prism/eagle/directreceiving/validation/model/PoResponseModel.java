package com.dell.prism.eagle.directreceiving.validation.model;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PoResponseModel implements Serializable {

	private static final long serialVersionUID = -5130070011440361652L;

	private String status;
	private String errorMessage;
	private String poDetails;

}
