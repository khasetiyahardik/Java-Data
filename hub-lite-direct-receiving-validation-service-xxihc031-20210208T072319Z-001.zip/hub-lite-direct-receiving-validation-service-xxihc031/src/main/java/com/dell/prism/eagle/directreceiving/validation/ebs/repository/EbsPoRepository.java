package com.dell.prism.eagle.directreceiving.validation.ebs.repository;

import java.io.IOException;
import java.sql.Clob;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.dell.prism.eagle.directreceiving.validation.constant.InvSnapshotConstant;
import com.dell.prism.eagle.directreceiving.validation.model.PoResponseModel;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class EbsPoRepository {

	@Autowired
	private DataSource dataSource;

	private SimpleJdbcCall simpleJdbcCall;

	@Autowired
	ObjectMapper objectMapper;

	@PostConstruct
	private void postConstruct() {

		this.simpleJdbcCall = new SimpleJdbcCall(dataSource).withProcedureName(InvSnapshotConstant.PO_STORE_PROCEDURE)
				.withCatalogName(InvSnapshotConstant.CATALOG_NAME).withoutProcedureColumnMetaDataAccess()
				.declareParameters(new SqlParameter(InvSnapshotConstant.P_PO_NUMBER, Types.VARCHAR),
						new SqlParameter(InvSnapshotConstant.P_OPERATING_UNIT, Types.VARCHAR),
						new SqlParameter(InvSnapshotConstant.P_INV_ORG_CODE, Types.VARCHAR),

						new SqlOutParameter(InvSnapshotConstant.X_PO_DETAILS, Types.CLOB),
						new SqlOutParameter(InvSnapshotConstant.X_STATUS_CODE, Types.VARCHAR),
						new SqlOutParameter(InvSnapshotConstant.X_ERROR_MESSAGE, Types.VARCHAR));

	}

	public PoResponseModel invokePoEbsProc(String factoryOrgCode, String operatingUnit, String poNumber) {
		PoResponseModel poResponseModel = new PoResponseModel();
		try {
			Map<String, Object> in = new HashMap<>();
			in.put(InvSnapshotConstant.P_PO_NUMBER, poNumber);
			in.put(InvSnapshotConstant.P_OPERATING_UNIT, operatingUnit);
			in.put(InvSnapshotConstant.P_INV_ORG_CODE, factoryOrgCode);

			Map<String, Object> out = simpleJdbcCall.execute(in);

			String json = EbsUtil.clobToStringConversion((Clob) out.get(InvSnapshotConstant.X_PO_DETAILS));
			String statusCode = (String) out.get(InvSnapshotConstant.X_STATUS_CODE);
			String errorMsg = (String) out.get(InvSnapshotConstant.X_ERROR_MESSAGE);
			log.info("=============== json :" + json);
			log.info("=============== statusCode :" + statusCode);
			log.info("=============== errorMsg :" + errorMsg);

			if (!StringUtils.isEmpty(json)) {
				poResponseModel = objectMapper.readValue(json, PoResponseModel.class);
				if (!ObjectUtils.isEmpty(poResponseModel)) {
					log.info("Empty po response with status :: {}", out.get(InvSnapshotConstant.X_STATUS_CODE));
				} else {
					log.info("po response with status :: {}", out.get(InvSnapshotConstant.X_ERROR_MESSAGE));
				}
			} else {
				log.info("Empty po json response from EBS.");
			}
			poResponseModel.setPoDetails(json);
			poResponseModel.setStatus(statusCode);
			poResponseModel.setErrorMessage(errorMsg);
		} catch (IOException e) {
			log.error("Exception in reading json ", e);
		}
		return poResponseModel;
	}
}
