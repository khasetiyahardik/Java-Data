package com.dell.prism.eagle.directreceiving.validation.feign;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.dell.prism.eagle.directreceiving.validation.config.SecurityServiceImpl;
import com.dell.prism.eagle.directreceiving.validation.model.ItemDescriptionModel;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class Integrator {

	@Value(value = "${dias.clientdId}")
	String clientid;
	@Autowired
	SecurityServiceImpl securityServiceImpl;

	@Autowired
	FeignProxy feignProxy;

	@Retryable(value = {
			Exception.class }, maxAttemptsExpression = "#{${retry.count}}", backoff = @Backoff(delayExpression = "#{${retry.delay}}"))
	public ItemDescriptionModel callItemValidationService(String pFactory, String itemNumber) {
		log.info("pFactory :" + pFactory);
		log.info("itemNumber :" + itemNumber);
		String accessToken = securityServiceImpl.getAccessToken();
		return feignProxy.callItemValidationService(accessToken, clientid, pFactory, itemNumber);
	}

}