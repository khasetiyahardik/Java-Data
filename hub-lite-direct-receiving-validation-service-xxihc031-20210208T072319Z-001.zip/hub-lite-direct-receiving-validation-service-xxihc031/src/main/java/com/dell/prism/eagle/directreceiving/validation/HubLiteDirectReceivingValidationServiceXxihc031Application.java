package com.dell.prism.eagle.directreceiving.validation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.cache.CacheAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.retry.annotation.EnableRetry;

@SpringBootApplication(scanBasePackages = { "com.dell.prism" })
@EnableCaching
@AutoConfigureBefore(CacheAutoConfiguration.class)
@EnableFeignClients
@EnableRetry
public class HubLiteDirectReceivingValidationServiceXxihc031Application {

	public static void main(String[] args) {
		SpringApplication.run(HubLiteDirectReceivingValidationServiceXxihc031Application.class, args);
	}

}
