package com.dell.prism.eagle.directreceiving.validation.constant;

public class InvSnapshotConstant {

	private InvSnapshotConstant() {
	}

	public static final String SERVICE_NAME = "portal-inventory-snapshot-prc-hublite";

	public static final String INV_SNAPSHOT_HUB_URL = "v1/getHubs";
	public static final String INV_SNAPSHOT_VENDOR_URL = "v1/getVendorDetails";
	public static final String SINGLE_VENDOR_ONHAND_URL = "v1/getInvSnapShotDetails";
	public static final String PO_DETAILS_URL = "v1/getPoDetails";
	public static final String MULTI_VENDOR_ONHAND_URL = "v1/getInvOnHandDetails";
	public static final String INV_SNAPSHOT_ONHAND_REPORT_XL_URL = "/v1/invOnHandReportExcel";
	public static final String EXCEL_FILE_NAME = "inv_onhand_excel.xls";
	public static final String INV_ONHAND_REPORT_SHEET = "Inventory onHand Report";
	public static final String ONHAND_RESPONSE_SUCCESS = "SUCCESS";
	public static final String ONHAND_RESPONSE_FAILED = "FAILED";

//	Oracle Constants.
	public static final String SLC_LOC_ENTITY_NAME = "XXIHC031_PRC_SLC_LOC";
	public static final String FACTORY_HUB_ENTITY_NAME = "XXIHC031_PRC_FACTORY_HUB";
//	EBS Constants.
	//public static final String P_INV_ORG_CODE = "p_inv_org_code";
	public static final String X_ERROR_MESSAGE = "x_error_msg";
	public static final String X_STATUS_CODE = "x_status_code";
	public static final String X_SUPP_DETAILS = "x_supp_details";
	public static final String P_SUB_INV_CODE = "p_sub_inv_code";
	public static final String VENDOR_STORE_PROCEDURE = "XXIHC031_PO_HUB_COLLAB_PKG.derive_supplier_details";
	public static final String X_ERROR_MSG = "x_error_msg";
	public static final String P_HUB_INV_TAB = "p_hub_inv_tab";
	public static final String ONHAND_TABLE_TYPE = "XXIHC031_HUB_INV_TBL_TYPE";
	public static final String ONHAND_RECORD_TYPE = "XXUIP.XXIHC031_HUB_INV_REC_TYPE";
	public static final String ONHAND_STORE_PROCEDURE = "XXIHC031_PO_HUB_COLLAB_PKG.direct_rec_po";

//	EBS Constants.

	public static final String PO_STORE_PROCEDURE = "XXIHC031_PO_HUB_COLLAB_PKG.direct_rec_po";
	public static final String CATALOG_NAME = "APPS";
	public static final String P_OPERATING_UNIT = "p_operating_unit";
	public static final String P_INV_ORG_CODE = "p_inv_org_code";
	public static final String P_PO_NUMBER = "p_po_number";
	
	public static final String P_ORG_CODE = "p_org_code";
	public static final String X_PO_DETAILS = "x_po_details";
	public static final String X_VENDOR_NAME = "p_vendor_name";
	public static final String X_VENDOR_CCN = "p_vendor_ccn";
	public static final String X_RESULT_OUT = "x_result_out";
	public static final String X_RETURN_MESSAGE = "x_return_message";
}