package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class PriceHeaderModel {
	
	private String toLocation;
	private String toLocationCcn;
	private String poType;
	private String poSubType;
	private String odmPoType;
	private String vendor;
	private String vendorCcn;
	private String vendorLocation;
	private List<PricePartDetailsModel> partDetails;
	private String message;
}
