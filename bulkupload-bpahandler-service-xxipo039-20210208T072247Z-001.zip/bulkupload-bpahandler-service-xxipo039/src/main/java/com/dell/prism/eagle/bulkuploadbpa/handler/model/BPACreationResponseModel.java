package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BPACreationResponseModel extends BPACreationModel {

	private String poNumber;
	private String statusCode;
	private String errorMessage;
	private String action;
}