package com.dell.prism.eagle.bulkuploadbpa.handler.config;

import lombok.Data;

@Data
public class AccessTokenResponse {
	private String access_token;
}