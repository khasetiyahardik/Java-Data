package com.dell.prism.eagle.bulkuploadbpa.handler.service;

import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.A;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ADD;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ALLOW_PRICE_OVERRIDE_SHOULD_BE_NULL;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.APPLICATION_ERROR_ENCOUNTERED_DURING_IMPORT;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.APPLICATION_ERROR_ENCOUNTERED_DURING_VALIDATION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BLANKET;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BOOLEAN_N;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BOOLEAN_NO;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BOOLEAN_Y;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BOOLEAN_YES;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.COST_TYPE_MANUAL;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.DUPLICATE_ITEM_ERROR_FOR_GIVEN_PO_NUMBER;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ERROR_COST_TYPE_MN_ATTACHMENT_MANDATORY;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ERROR_IN_UNDERLYING_LINES;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ERROR_MANDATORY_PO_COST_ATTRIBUTES_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ERROR_MESSAGE_DELIMITER;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ERROR_TOTAL_COST_MORE_THAN_DEFINED_LIMIT_ATTACHMENT_MANDATORY;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_BULK_UPLOAD_CREATION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_BULK_UPLOAD_POST_CREATION_NACK;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_BULK_UPLOAD_POST_PRICE_NACK;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_BULK_UPLOAD_POST_VALIDATION_NACK;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_BULK_UPLOAD_PRE_VALIDATION_NACK;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_BULK_UPLOAD_VALIDATION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_FETCH_PO_PRICE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_RECEIVE_BULK_UPLOAD_MESSAGE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.HEADER_DATA_MISMATCH_FOR_GIVEN_PO_NUMBER;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INTERNAL_COMMENTS_IS_MANDATORY_WHEN_REASON_CODE_IS_40;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_ALLOW_PRICE_OVERRIDE_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_ATTACHMENT_FILE_NAME_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_CLAUSES_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_DEFAULT_SHIP_TO_LOCATION_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_INTERNAL_COMMENTS_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_ITEM_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_LAST_TIME_BUY_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_LINE_COMMENTS_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_OPERATING_UNIT_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_PRICE_RETURN_FROM_PRICE_SERVICE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_PURCHASE_ORDER_NUMBER_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_REASON_CODE_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_VALUE_FOR_ACTION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_VALUE_FOR_ALLOW_PRICE_OVERRIDE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_VALUE_FOR_LAST_TIME_BUY;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_VALUE_FOR_LINE_ACTION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ITEM_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ITEM_IS_MANDATORY_FOR_UPDATING_LINE_LEVEL_DETAILS;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.LINE_ACTION_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.LINE_ACTION_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_PO_NUMBER;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.OPERATING_UNIT_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ORGANIZATION_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_PO_NUMBER;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.PURCHASE_ORDER_NUMBER_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.REASON_CODE_40_IS_NOT_ALLOWED_FOR_THE_UPDATE_OPERATION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.REASON_CODE_IS_MANDATORY_WHEN_PRICE_IS_ENTERED;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATING_ASYNC_METHOD_INVOCATION_PART_FOR_TRANSACTION_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATUS_DETAILS_IMPORT;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATUS_DETAILS_PRICE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATUS_DETAILS_VALIDATION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.U;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.UPDATE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dell.prism.eagle.bulkuploadbpa.handler.exception.ApiException;
import com.dell.prism.eagle.bulkuploadbpa.handler.integrator.BulkUploadBPAIntegrator;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPAUpdationInputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPAUpdationModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPAUpdationResponseModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadErrorModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadPayloadModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadPriceModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadUpdationErrorModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportEBSOutputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportHeaderModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportInputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportLineModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportOutputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportShipmentModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.PriceHeaderModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.PricePartDetailsModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationHeaderModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationLineModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.utility.BulkUploadBPAUtil;
import com.dell.prism.eagle.bulkuploadbpa.handler.utility.DateStringUtil;
import com.dell.prism.transactionlogger.model.MessageEventType;
import com.dell.prism.transactionlogger.model.MessageStatus;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BulkUploadBPAUpdateService {

	@Autowired
	BulkUploadBPAUtil util;
	@Autowired
	BulkUploadBPAIntegrator integrator;
	@Autowired
	DateStringUtil dateUtil;

	public void invokeBPAUpdation(BPAUpdationInputModel bpaUpdationInputModel) {

		String transactionId = bpaUpdationInputModel.getTransactionId();
		util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null,
				EVENT_RECEIVE_BULK_UPLOAD_MESSAGE, UPDATE);

		// Initialize bulkUploadPayloadModel
		BulkUploadPayloadModel<BPAUpdationModel, BPAUpdationResponseModel> bulkUploadPayloadModel = new BulkUploadPayloadModel<>();
		util.initializeBulkUploadPayloadModel(bulkUploadPayloadModel, transactionId);
		bulkUploadPayloadModel.setTranType(UPDATE);
		bulkUploadPayloadModel.setFileName(bpaUpdationInputModel.getFileName());
		bulkUploadPayloadModel.setUserName(bpaUpdationInputModel.getUserName());

		// Respond with transaction id and continue Async processing
		log.info(STATING_ASYNC_METHOD_INVOCATION_PART_FOR_TRANSACTION_ID + transactionId);

		util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bpaUpdationInputModel,
				EVENT_RECEIVE_BULK_UPLOAD_MESSAGE, UPDATE);

		CompletableFuture
				.supplyAsync(() -> executeBPAUpdation(bpaUpdationInputModel, transactionId, bulkUploadPayloadModel))
				.exceptionally(exception -> {
					util.prismLogger(bpaUpdationInputModel.getTransactionId(), MessageEventType.END,
							MessageStatus.FAILURE, bpaUpdationInputModel, EVENT_RECEIVE_BULK_UPLOAD_MESSAGE, UPDATE);
					log.error("Transaction ID: " + transactionId + " Exception in async call.  Exception: "
							+ ExceptionUtils.getStackTrace(exception));
					// Update Payload collection status as failed
					util.updatePayloadCollectionStatus(bulkUploadPayloadModel,
							bpaUpdationInputModel.getBpaUpdationModels().size());
					return null;
				});
	}

	public Object executeBPAUpdation(BPAUpdationInputModel bpaUpdationInputModel, String transactionId,
			BulkUploadPayloadModel<BPAUpdationModel, BPAUpdationResponseModel> bulkUploadPayloadModel) {
		Integer[] failedInValidationOrPriceRecords = { 0 };

		BulkUploadErrorModel<BulkUploadUpdationErrorModel> bulkUploadErrorModel = new BulkUploadErrorModel<>();
		util.initializeBulkUploadErrorModel(bulkUploadErrorModel, transactionId);
		Set<String> errorGroupIdSet = new HashSet<>();
		Set<String> failedPONumbers = new HashSet<>();

		bpaUpdationInputModel.getBpaUpdationModels().forEach(bpaUpdationModel -> {
			// Remove leading and trailing spaces for varChar fields
			removeLeadingAndTrailingSpaces(bpaUpdationModel);
		});

		// Add input records into BulkUploadPayload collection
		bulkUploadPayloadModel.setInputPayload(bpaUpdationInputModel.getBpaUpdationModels());

		Map<String, Map<String, List<BPAUpdationModel>>> inputMappedByPONumberAndItem = bpaUpdationInputModel
				.getBpaUpdationModels().stream()
				.filter(pOCreationModel -> null != pOCreationModel.getExistingPoNumber()
						&& null != pOCreationModel.getItem())
				.collect(Collectors.groupingBy(BPAUpdationModel::getExistingPoNumber,
						Collectors.groupingBy(BPAUpdationModel::getItem)));

		bpaUpdationInputModel.getBpaUpdationModels().stream()
				.filter(pOCreationModel -> null == pOCreationModel.getExistingPoNumber())
				.forEach(pOCreationModel -> populateBulkUploadPOErrorModel(pOCreationModel,
						PURCHASE_ORDER_NUMBER_FIELD_IS_MISSING, bulkUploadErrorModel, failedPONumbers));

		Map<String, List<BPAUpdationModel>> poUpdationModelGroup = bpaUpdationInputModel.getBpaUpdationModels().stream()
				.filter(pOUpdationModel -> null != pOUpdationModel.getExistingPoNumber())
				.collect(Collectors.groupingBy(BPAUpdationModel::getExistingPoNumber, Collectors.toList()));

		log.info("Transaction ID: " + bpaUpdationInputModel.getTransactionId() + " poUpdationModelGroup: "
				+ poUpdationModelGroup);

		poUpdationModelGroup.forEach((groupId, poUpdationModelList) -> {
			List<BulkUploadUpdationErrorModel> poUpdationErrorModels = new ArrayList<>();
			Set<String> itemSet = new HashSet<>();
			poUpdationModelList.forEach(poUpdationModel -> {
				StringJoiner errorMessage = new StringJoiner(" | ");
				log.info("Transaction ID: " + bpaUpdationInputModel.getTransactionId() + " itemSet: " + itemSet
						+ " poNumber : " + groupId);
				if (null != poUpdationModel.getItem() && !itemSet.add(poUpdationModel.getItem()))
					errorMessage.add(DUPLICATE_ITEM_ERROR_FOR_GIVEN_PO_NUMBER);

				// common attributes check
				errorMessage.merge(validateCommonAttributes(poUpdationModelList.get(0), poUpdationModel));

				// mandatory parameters check
				errorMessage.merge(validateMandatoryFields(poUpdationModel));
				// field length check
				errorMessage.merge(validateFieldLength(poUpdationModel));

				if (!StringUtils.isEmpty(errorMessage.toString())) {
					// Record failed Group ID for removal
					errorGroupIdSet.add(groupId);
					failedPONumbers.add(groupId);
					log.info("Transaction ID: " + bpaUpdationInputModel.getTransactionId()
							+ " Pre-validation check failed with error message: " + errorMessage);
				}
				poUpdationErrorModels.add(BulkUploadUpdationErrorModel.builder().errorMessage(errorMessage.toString())
						.inputPayload(poUpdationModel).build());
			});
			if (errorGroupIdSet.contains(groupId))
				poUpdationErrorModels.forEach(
						poUpdationErrorModel -> bulkUploadErrorModel.getErrorPayload().add(poUpdationErrorModel));
		});
		errorGroupIdSet.forEach(poUpdationModelGroup::remove);

		Integer failedInPreValidationRecords = bulkUploadErrorModel.getErrorPayload().size();
		bulkUploadPayloadModel.getStatusDetails().setFailedInPreValidationRecords(failedInPreValidationRecords);
		if (failedInPreValidationRecords >= 1) {
			util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null,
					EVENT_BULK_UPLOAD_PRE_VALIDATION_NACK, UPDATE);
			util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bulkUploadErrorModel,
					EVENT_BULK_UPLOAD_PRE_VALIDATION_NACK, UPDATE);
		}
		// persist the records in corresponding bulkUpload payload/error collection
		if (!bulkUploadPayloadModel.getInputPayload().isEmpty())
			integrator.savePayloadCollection(bulkUploadPayloadModel);
		log.info("Transaction ID: " + bpaUpdationInputModel.getTransactionId()
				+ " bulkUpload payload saved to MongoDB: ");

		// Update Mongo collection for the given input with current status
		util.updatePayloadCollectionStatusDetails(bulkUploadPayloadModel, STATUS_DETAILS_VALIDATION);
//		if (failedInPreValidationRecords >= 1) {
//			util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bulkUploadErrorModel,
//					EVENT_BULK_UPLOAD_PRE_VALIDATION_NACK, UPDATE);
//		}

		// make a validation call

		ValidationModel bulkUploadValidationOutput = null;
//		Integer failedInValidationRecords = 0;
		if (!poUpdationModelGroup.isEmpty())
			try {
				bulkUploadValidationOutput = executeBulkUploadValidation(poUpdationModelGroup, bpaUpdationInputModel,
						transactionId, bulkUploadErrorModel, failedPONumbers);

			} catch (ApiException ex) {
				log.error("Transaction ID: " + bpaUpdationInputModel.getTransactionId()
						+ " Api Exception encountered during Validation: " + ex);
				bulkUploadPayloadModel.getInputPayload().stream()
						.filter(errorInputModel -> !failedPONumbers.contains(errorInputModel.getExistingPoNumber()))
						.collect(Collectors.toList())
						.forEach(errorInputModel -> populateBulkUploadPOErrorModel(errorInputModel,
								ex.getErrorMessage(), bulkUploadErrorModel, failedPONumbers));
				util.prismLogger(transactionId, MessageEventType.START, MessageStatus.FAILURE, bulkUploadErrorModel,
						EVENT_BULK_UPLOAD_VALIDATION, UPDATE);
			} catch (Exception ex) {
				log.error("Transaction ID: " + bpaUpdationInputModel.getTransactionId()
						+ " Unexpected Exception encountered during Validation: " + ExceptionUtils.getStackTrace(ex));
				bulkUploadPayloadModel.getInputPayload().stream()
						.filter(errorInputModel -> !failedPONumbers.contains(errorInputModel.getExistingPoNumber()))
						.collect(Collectors.toList())
						.forEach(errorInputModel -> populateBulkUploadPOErrorModel(errorInputModel,
								APPLICATION_ERROR_ENCOUNTERED_DURING_VALIDATION, bulkUploadErrorModel,
								failedPONumbers));
				util.prismLogger(transactionId, MessageEventType.START, MessageStatus.FAILURE, bulkUploadErrorModel,
						EVENT_BULK_UPLOAD_VALIDATION, UPDATE);
			}
//		failedInValidationRecords = bulkUploadErrorModel.getErrorPayload().size() - failedInPreValidationRecords;
//		bulkUploadPayloadModel.getStatusDetails().setFailedInValidationRecords(failedInValidationRecords);
//		if (failedInValidationRecords >= 1) {
//			util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bulkUploadErrorModel,
//					EVENT_BULK_UPLOAD_POST_VALIDATION_NACK, UPDATE);
//		}
		// Make price service call
		if (null != bulkUploadValidationOutput && !bulkUploadValidationOutput.getHeaderModels().isEmpty()) {
			try {
				// Make price service call
				util.updatePayloadCollectionStatusDetails(bulkUploadPayloadModel, STATUS_DETAILS_PRICE);
				// set bulk upload po validation response
				// Update Mongo collection for the given input with current status
				invokePoPriceService(bulkUploadValidationOutput, transactionId);
				filterValidationOrPriceErrorRecords(bulkUploadValidationOutput, bpaUpdationInputModel, transactionId,
						bulkUploadErrorModel, failedPONumbers);
//				log.info("========== errorGroupIdMap.toString()" + errorGroupIdMap.toString());
//				// Map error group ids to error collection
//				errorGroupIdMap.forEach((errorMessage, errorGroupIDList) -> {
//					List<BPAUpdationModel> errorInputModels = bulkUploadPayloadModel.getInputPayload().parallelStream()
//							.filter(inputPayload -> errorGroupIDList.contains(inputPayload.getExistingPoNumber()))
//							.collect(Collectors.toList());
//
//					errorInputModels.forEach(errorInputModel -> {
//						failedInValidationOrPriceRecords[0]++;
//						populateBulkUploadPOErrorModel(errorInputModel, errorMessage, bulkUploadErrorModel,
//								failedPONumbers);
//					});
//				});
			} catch (ApiException ex) {
				log.error("Transaction ID: " + bpaUpdationInputModel.getTransactionId()
						+ " Api Exception encountered during Price: " + ex);
				bulkUploadPayloadModel.getInputPayload().stream()
						.filter(errorInputModel -> !failedPONumbers.contains(errorInputModel.getExistingPoNumber()))
						.collect(Collectors.toList()).forEach(errorInputModel -> {
							populateBulkUploadPOErrorModel(errorInputModel, ex.getErrorMessage(), bulkUploadErrorModel,
									failedPONumbers);
						});
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.FAILURE, bulkUploadErrorModel,
						EVENT_FETCH_PO_PRICE, UPDATE);
			} catch (Exception ex) {
				log.error("Transaction ID: " + bpaUpdationInputModel.getTransactionId()
						+ " Unexpected Exception encountered during Price: " + ExceptionUtils.getStackTrace(ex));
				bulkUploadPayloadModel.getInputPayload().stream()
						.filter(errorInputModel -> !failedPONumbers.contains(errorInputModel.getExistingPoNumber()))
						.collect(Collectors.toList()).forEach(errorInputModel -> {
							populateBulkUploadPOErrorModel(errorInputModel,
									APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST, bulkUploadErrorModel,
									failedPONumbers);
						});
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.FAILURE, bulkUploadErrorModel,
						EVENT_FETCH_PO_PRICE, UPDATE);
			}
		}
		failedInValidationOrPriceRecords[0] = bulkUploadErrorModel.getErrorPayload().size()
				- failedInPreValidationRecords;
		bulkUploadPayloadModel.getStatusDetails()
				.setFailedInValidationOrPriceRecords(failedInValidationOrPriceRecords[0]);
		if (failedInValidationOrPriceRecords[0] >= 1) {
			util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null,
					EVENT_BULK_UPLOAD_POST_PRICE_NACK, UPDATE);
			util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bulkUploadErrorModel,
					EVENT_BULK_UPLOAD_POST_PRICE_NACK, UPDATE);
		}
		// Make import service call
		ImportOutputModel bulkUploadImportOutput = null;
		if (null != bulkUploadValidationOutput && !bulkUploadValidationOutput.getHeaderModels().isEmpty()) {
			// Update Mongo collection for the given input with current status
			util.updatePayloadCollectionStatusDetails(bulkUploadPayloadModel, STATUS_DETAILS_IMPORT);
			try {
				util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null,
						EVENT_BULK_UPLOAD_CREATION, UPDATE);
				// construct header and line model for po import and call import service
				bulkUploadImportOutput = executePoImportService(bulkUploadValidationOutput, transactionId);
				filterImportErrorRecords(bulkUploadImportOutput, bpaUpdationInputModel, transactionId,
						bulkUploadErrorModel, failedPONumbers);
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bulkUploadImportOutput,
						EVENT_BULK_UPLOAD_CREATION, UPDATE);
			} catch (ApiException e) {
				log.error("Transaction ID: " + bpaUpdationInputModel.getTransactionId()
						+ " Api Exception encountered during Import: " + e);
				bulkUploadPayloadModel.getInputPayload().stream()
						.filter(errorInputModel -> !failedPONumbers.contains(errorInputModel.getExistingPoNumber()))
						.collect(Collectors.toList())
						.forEach(errorInputModel -> populateBulkUploadPOErrorModel(errorInputModel, e.getErrorMessage(),
								bulkUploadErrorModel, failedPONumbers));
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.FAILURE, bulkUploadErrorModel,
						EVENT_BULK_UPLOAD_CREATION, UPDATE);
			} catch (Exception ex) {
				log.error("Transaction ID: " + bpaUpdationInputModel.getTransactionId()
						+ " Unexpected Exception encountered during Import: " + ExceptionUtils.getStackTrace(ex));

				bulkUploadPayloadModel.getInputPayload().stream()
						.filter(errorInputModel -> !failedPONumbers.contains(errorInputModel.getExistingPoNumber()))
						.collect(Collectors.toList())
						.forEach(errorInputModel -> populateBulkUploadPOErrorModel(errorInputModel,
								APPLICATION_ERROR_ENCOUNTERED_DURING_IMPORT, bulkUploadErrorModel, failedPONumbers));
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.FAILURE, bulkUploadErrorModel,
						EVENT_BULK_UPLOAD_CREATION, UPDATE);
			}
			int failedInImportRecords = (bulkUploadErrorModel.getErrorPayload().size()
					- (failedInPreValidationRecords + failedInValidationOrPriceRecords[0]));
			bulkUploadPayloadModel.getStatusDetails().setFailedInImportRecords(failedInImportRecords);
			if (failedInImportRecords >= 1) {
				util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null,
						EVENT_BULK_UPLOAD_POST_CREATION_NACK, UPDATE);
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bulkUploadErrorModel,
						EVENT_BULK_UPLOAD_POST_CREATION_NACK, UPDATE);
			}
		}
		// Setting Response Payload for header and lines
		if (null != bulkUploadImportOutput && !bulkUploadImportOutput.getBulkUploadImportOutput().isEmpty())
			bulkUploadImportOutput.getBulkUploadImportOutput().forEach(importOutput -> {
				ImportHeaderModel importHeader = importOutput.getBulkUploadImportHeaderModel();
				if ("S".equals(importHeader.getStatusCode()) && !importHeader.getLines().isEmpty()) {
					Map<String, List<BPAUpdationModel>> inputPayloadForGroupId = inputMappedByPONumberAndItem
							.get(importHeader.getExistingPoNumber());
					importHeader.getLines().forEach(importLine -> {
						List<BPAUpdationModel> inputPayload = inputPayloadForGroupId.get(importLine.getItem());
						BPAUpdationResponseModel responsePayload = new BPAUpdationResponseModel();
						BeanUtils.copyProperties(inputPayload.get(0), responsePayload);
						responsePayload.setExistingPoNumber(importHeader.getExistingPoNumber());
						responsePayload.setStatusCode(importLine.getStatusCode());
						responsePayload.setErrorMessage(importLine.getErrorMessage());
						responsePayload.setAction(importLine.getAction());
						bulkUploadPayloadModel.getResponsePayload().add(responsePayload);
					});
				} else if ("S".equals(importHeader.getStatusCode()) && importHeader.getLines().isEmpty()) {
					BPAUpdationModel inputPayloadForPONumber = bpaUpdationInputModel
							.getBpaUpdationModels().stream().filter(bpaUpdationModel -> importHeader
									.getExistingPoNumber().equals(bpaUpdationModel.getExistingPoNumber()))
							.findFirst().get();
					BPAUpdationResponseModel responsePayload = new BPAUpdationResponseModel();
					BeanUtils.copyProperties(inputPayloadForPONumber, responsePayload);
					responsePayload.setExistingPoNumber(importHeader.getExistingPoNumber());
					responsePayload.setStatusCode(importHeader.getStatusCode());
					responsePayload.setErrorMessage(importHeader.getErrorMessage());
					responsePayload.setAction(importHeader.getAction());
					bulkUploadPayloadModel.getResponsePayload().add(responsePayload);
				}

			});
		// Setting Response Payload for only header update
		if (!bulkUploadErrorModel.getErrorPayload().isEmpty()) {
			integrator.saveErrorPayloadCollection(bulkUploadErrorModel);
		}
		util.updatePayloadCollectionStatus(bulkUploadPayloadModel, bulkUploadErrorModel.getErrorPayload().size());
		return bulkUploadImportOutput;
	}

	private void populateBulkUploadPOErrorModel(BPAUpdationModel inputPayload, String errorMessage,
			BulkUploadErrorModel<BulkUploadUpdationErrorModel> bulkUploadErrorModel, Set<String> failedPONumbers) {
		BulkUploadUpdationErrorModel bulkUploadPOCreationErrorModel = new BulkUploadUpdationErrorModel();
		bulkUploadPOCreationErrorModel.setInputPayload(inputPayload);
		bulkUploadPOCreationErrorModel.setErrorMessage(errorMessage);
		bulkUploadErrorModel.getErrorPayload().add(bulkUploadPOCreationErrorModel);
		failedPONumbers.add(inputPayload.getExistingPoNumber());
	}

	private ImportOutputModel executePoImportService(ValidationModel validationOutput, String transactionId) {

		ImportInputModel importInputModel = ImportInputModel.builder().importHeaderModels(new ArrayList<>())
				.transactionId(transactionId).build();
		validationOutput.getHeaderModels().forEach(validationHeader -> {
			ImportHeaderModel importHeaderModel = new ImportHeaderModel();
			List<ImportLineModel> importLineModelList = new ArrayList<>();
			// Populate Header details
			BeanUtils.copyProperties(validationHeader, importHeaderModel);

			validationHeader.getLines().forEach(validationLine -> {
				ImportLineModel importLineModel = new ImportLineModel();
				// Populate Line details
				BeanUtils.copyProperties(validationLine, importLineModel);

				// Populate Shipment details
				importLineModel.setShipments(new ArrayList<>(Arrays.asList(ImportShipmentModel.builder()
						.shipToLocationIdShipping(validationLine.getShipToLocationIdShipping())
						.shipToOrgId(validationLine.getShipToOrgId())
						.subinventoryName(validationLine.getSubInventoryName()).build())));
				importLineModelList.add(importLineModel);
			});
			importHeaderModel.setLines(importLineModelList);
			importInputModel.getImportHeaderModels().add(importHeaderModel);
		});
		return integrator.callbulkUploadImportService(importInputModel);
	}

	private ValidationModel executeBulkUploadValidation(Map<String, List<BPAUpdationModel>> bpaUpdationModelGroup,
			BPAUpdationInputModel bpaUpdationInputModel, String transactionId,
			BulkUploadErrorModel<BulkUploadUpdationErrorModel> bulkUploadErrorModel, Set<String> failedPONumbers) {
		util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null,
				EVENT_BULK_UPLOAD_VALIDATION, UPDATE);
		// converting into header and line model for validation this will have list of
		// headers
		ValidationModel bulkUploadValidationModel = new ValidationModel();
		bulkUploadValidationModel.setHeaderModels(new ArrayList<>());
		bulkUploadValidationModel.setTransactionId(transactionId);

		log.info("Transaction ID: " + bpaUpdationInputModel.getTransactionId() + " bpaUpdationModelGroup: "
				+ bpaUpdationModelGroup);

		bpaUpdationModelGroup.forEach((existingPONumber, poUpdationModels) -> {

			// Create Validation Header
			BPAUpdationModel bpaUpdationHeaderModel = poUpdationModels.get(0);

			ValidationHeaderModel validationHeaderModel = ValidationHeaderModel.builder().poTypeLookUpCode(BLANKET)
					.action(bpaUpdationHeaderModel.getAction())
					.existingPoNumber(bpaUpdationHeaderModel.getExistingPoNumber())
					.buyerId(bpaUpdationInputModel.getBuyerId()).applicationUser(bpaUpdationInputModel.getUserName())
					.operatingUnit(bpaUpdationHeaderModel.getOperatingUnit())
					// .inventoryOrgCode(bpaUpdationHeaderModel.getInventoryOrg())
					// .IccSlcLocation(bpaUpdationHeaderModel.getIccSlcLocation())
					.defaultShipToLocation(bpaUpdationHeaderModel.getDefaultShipToLocation())
					.clauses(bpaUpdationHeaderModel.getClauses())
					.attachmentFileName(StringUtils.isEmpty(bpaUpdationHeaderModel.getAttachment()) ? null
							: transactionId + "_" + bpaUpdationHeaderModel.getAttachment())
					.lines(new ArrayList<>()).build();
			util.populateDefaultValues(validationHeaderModel);

			poUpdationModels.forEach(bpaUpdationModel -> {
				if (!StringUtils.isEmpty(bpaUpdationModel.getItem())) {
					// Create Validation Lines
					ValidationLineModel validationLineModel = ValidationLineModel.builder()
							.action(bpaUpdationModel.getAction()).item(bpaUpdationModel.getItem())
							.quantity(bpaUpdationModel.getQuantity()).unitPrice(bpaUpdationModel.getPrice())
							.lastTimeBuy(bpaUpdationModel.getLastTimeBuy())
							.lineComments(bpaUpdationModel.getLineComments())
							.reasonCode(bpaUpdationModel.getReasonCode())
							.shipToOrgname(bpaUpdationModel.getInventoryOrg())
							.internalComments(bpaUpdationModel.getInternalComments())
							.allowPriceOverride(bpaUpdationModel.getAllowPriceOverride()).build();

					if ("MX-MX_BSE_USD_OU".equalsIgnoreCase(bpaUpdationModel.getOperatingUnit())
							&& !UPDATE.equalsIgnoreCase(validationLineModel.getAction())) {
						validationLineModel.setAllowPriceOverride("Y");
					}

					util.populateDefaultValues(validationLineModel);
					validationHeaderModel.getLines().add(validationLineModel);
				}
			});
			bulkUploadValidationModel.getHeaderModels().add(validationHeaderModel);
		});

		log.info("Transaction ID: " + bpaUpdationInputModel.getTransactionId() + " bulkUploadValidationModel: "
				+ bulkUploadValidationModel);

		// call bulk upload po validation service
		ValidationModel validationResponse = null;
		if (!bulkUploadValidationModel.getHeaderModels().isEmpty()) {
			validationResponse = integrator.callbulkUploadValidationService(bulkUploadValidationModel);
			filterValidationOrPriceErrorRecords(validationResponse, bpaUpdationInputModel, transactionId,
					bulkUploadErrorModel, failedPONumbers);
		}
		util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, validationResponse,
				EVENT_BULK_UPLOAD_VALIDATION, UPDATE);
		if (null == validationResponse) {
			throw new ApiException(APPLICATION_ERROR_ENCOUNTERED_DURING_VALIDATION);
		}
		return validationResponse;
	}

	public void invokePoPriceService(ValidationModel bulkUploadPoValidationOutput, String transactionId) {
//		Map<String, List<String>> errorGroupIdMap = new HashMap<>();
		util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null, EVENT_FETCH_PO_PRICE,
				UPDATE);
		BulkUploadPriceModel bulkUploadPriceModel = util.initializeBulkUploadPriceModel(transactionId);
//		errorGroupIdMap.put(ERROR_MANDATORY_PO_COST_ATTRIBUTES_MISSING, new ArrayList<>());
//		errorGroupIdMap.put(APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST, new ArrayList<>());
//		List<ValidationHeaderModel> invalidValidationHeaderModels = new ArrayList<>();
		bulkUploadPoValidationOutput.getHeaderModels().forEach(validationHeader -> {
			try {
				Double[] totalBPOCost = { 0.0 };
				PriceHeaderModel priceHeaderModel = PriceHeaderModel.builder().build();
				priceHeaderModel.setToLocation(validationHeader.getPoSite());
				priceHeaderModel.setToLocationCcn(validationHeader.getPoSiteCCN());
				priceHeaderModel.setPoType(validationHeader.getPoType());
				priceHeaderModel.setPoSubType(validationHeader.getPoSubType());
				priceHeaderModel.setOdmPoType(validationHeader.getOdmPoType());
				priceHeaderModel.setVendorCcn(validationHeader.getVendorCCN());
				priceHeaderModel.setVendor(validationHeader.getVendor());
				priceHeaderModel.setVendorLocation(validationHeader.getVendorLoc());
				priceHeaderModel.setPartDetails(new ArrayList<>());

				validationHeader.getLines().forEach(validationLines -> {
					// if (null == validationLines.getUnitPrice()) {
					if (!(UPDATE.equals(validationLines.getAction()) && validationLines.getUnitPrice() == null)) {
						priceHeaderModel.getPartDetails()
								.add(PricePartDetailsModel.builder().partNumber(validationLines.getItem())
										.effectiveDate(DateStringUtil.getStringFromDate(new Date())).build());
					} else {
						// For update scenario
						// If quantity is getting updated but price is not, calculate line cost using
						// old price & add to PO Total
						if (null != validationLines.getQuantity())
							totalBPOCost[0] += validationLines.getLineOldPrice().doubleValue()
									* validationLines.getQuantity().doubleValue();
					}
					// }
				});

				if (!priceHeaderModel.getPartDetails().isEmpty()) {

					if (StringUtils.isEmpty(priceHeaderModel.getPoType())
							|| StringUtils.isEmpty(priceHeaderModel.getPoSubType())
							|| StringUtils.isEmpty(priceHeaderModel.getToLocation())
							|| StringUtils.isEmpty(priceHeaderModel.getToLocationCcn())
							|| StringUtils.isEmpty(priceHeaderModel.getVendorCcn())) {
//						invalidValidationHeaderModels.add(validationHeader);
//						errorGroupIdMap.get(ERROR_MANDATORY_PO_COST_ATTRIBUTES_MISSING)
//								.add(validationHeader.getExistingPoNumber());
						util.markPriceHeaderError(bulkUploadPoValidationOutput, validationHeader,
								ERROR_MANDATORY_PO_COST_ATTRIBUTES_MISSING);
					} else {
						PriceHeaderModel priceOutput = null;
						bulkUploadPriceModel.getInputPayload().add(priceHeaderModel);
						priceOutput = integrator.fetchPOPrice(priceHeaderModel, transactionId);
						bulkUploadPriceModel.getResponsePayload().add(priceOutput);

						if (priceOutput != null && priceOutput.getPartDetails() != null) {

							if (priceOutput != null && priceOutput.getMessage() != null) {
								log.info("Message received from PO Price Service " + priceOutput.getMessage()
										+ " for transactionId :" + transactionId);
//								errorGroupIdMap.put(priceOutput.getMessage(), new ArrayList<>());
//								invalidValidationHeaderModels.add(validationHeader);
//								errorGroupIdMap.get(priceOutput.getMessage())
//										.add(validationHeader.getExistingPoNumber());
								util.markPriceHeaderError(bulkUploadPoValidationOutput, validationHeader,
										priceOutput.getMessage());

							} else {

								priceOutput.getPartDetails().forEach(partDetails -> {

									validationHeader.getLines().forEach(validationLine -> {
										if (validationLine.getItem().equals(partDetails.getPartNumber())) {
											// Set List price as the price returned from One Cost
											validationLine.setListPrice(partDetails.getPrice());

											// Scenario 1 : User entered Unit price in excel
											if (validationLine.getUnitPrice() != null) {
												// If the User entered price is same as One cost, use the cost type
												// returned from One Cost, i.e., Buy (B) else it will be Manual (MN)
												if (validationLine.getUnitPrice()
														.equals(validationLine.getListPrice())) {
													validationLine.setCostType(partDetails.getCostType());
												} else {
													validationLine.setCostType(COST_TYPE_MANUAL);
												}
											}
											// Scenario 2 : User did not enter Unit price in excel
											if (validationLine.getUnitPrice() == null) {
												validationLine.setUnitPrice(partDetails.getPrice());
												validationLine.setCostType(partDetails.getCostType());
											}

											// if old cost type is not MN .. new cost type = MN then attachment
											// is required for update scenario
											if (UPDATE.equals(validationLine.getAction())
													&& (!validationLine.getLineOldCostType()
															.equalsIgnoreCase(COST_TYPE_MANUAL))
													&& validationLine.getCostType().equalsIgnoreCase(COST_TYPE_MANUAL)
													&& validationHeader.getOldAttachmentFileName()
															.equalsIgnoreCase("AMT")) {
												log.error("Transaction ID: " + transactionId + " "
														+ ERROR_COST_TYPE_MN_ATTACHMENT_MANDATORY);
												util.markPriceLineError(bulkUploadPoValidationOutput, validationHeader,
														validationLine, ERROR_COST_TYPE_MN_ATTACHMENT_MANDATORY);
											} else if (ADD.equals(validationLine.getAction())
													&& validationLine.getCostType().equalsIgnoreCase(COST_TYPE_MANUAL)
													&& validationHeader.getOldAttachmentFileName()
															.equalsIgnoreCase("AMT")) {
												log.error("Transaction ID: " + transactionId + " "
														+ ERROR_COST_TYPE_MN_ATTACHMENT_MANDATORY);
												util.markPriceLineError(bulkUploadPoValidationOutput, validationHeader,
														validationLine, ERROR_COST_TYPE_MN_ATTACHMENT_MANDATORY);
											}

											if (validationLine.getUnitPrice() == null
													|| validationLine.getUnitPrice() <= 0) {
												if (StringUtils.isNotBlank(partDetails.getValidationMessage())) {
													log.info("Transaction ID: " + transactionId
															+ " Validation Message received from PO Price Service: "
															+ partDetails.getValidationMessage());
													util.markPriceLineError(bulkUploadPoValidationOutput,
															validationHeader, validationLine,
															partDetails.getValidationMessage());
												} else {
													log.error("Transaction ID: " + transactionId + " "
															+ INVALID_PRICE_RETURN_FROM_PRICE_SERVICE
															+ " Price returned: " + partDetails.getPrice()
															+ " Validation message: "
															+ partDetails.getValidationMessage());
													util.markPriceLineError(bulkUploadPoValidationOutput,
															validationHeader, validationLine,
															INVALID_PRICE_RETURN_FROM_PRICE_SERVICE);
												}
											} else {
												if (null != validationLine.getQuantity())
													totalBPOCost[0] += validationLine.getUnitPrice()
															* validationLine.getQuantity().doubleValue();
												// If price is getting updated but quantity is not, calculate
												// line cost using old quantity & add to PO Total
												else
													totalBPOCost[0] += validationLine.getUnitPrice()
															* validationLine.getLineOldQuantity().doubleValue();
											}
										}

									});

								});

							}

						}
					}

					log.info("Transaction ID: " + transactionId + " Total BPO Cost: " + totalBPOCost[0]
							+ " BPO Amount Limit: " + validationHeader.getPoAmountLimit());
					totalBPOCost[0] += validationHeader.getPoAmount();

					// 1.If old attachment is empty. 2.Sum of all lines (unit price*quantity) in a
					// particular header should be less
					// than BPO Amount Limit. 3. If both the conditions is true then attachment is
					// mandatory.
					if (validationHeader.getOldAttachmentFileName().equalsIgnoreCase("CST")
							&& totalBPOCost[0] >= validationHeader.getPoAmountLimit()) {
						log.error("Transaction ID: " + transactionId + " "
								+ ERROR_TOTAL_COST_MORE_THAN_DEFINED_LIMIT_ATTACHMENT_MANDATORY + "BPO Amount Limit: "
								+ validationHeader.getPoAmountLimit() + " totalBPOCostPO Total: " + totalBPOCost[0]);
						util.markPriceHeaderError(bulkUploadPoValidationOutput, validationHeader,
								ERROR_TOTAL_COST_MORE_THAN_DEFINED_LIMIT_ATTACHMENT_MANDATORY
										+ validationHeader.getPoAmountLimit() + " USD");
					}
				}

			} catch (Exception e) {
				log.error("Price Service Call Exception", e);
//				errorGroupIdMap.get(APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST)
//						.add(validationHeader.getGroupId());
//				invalidValidationHeaderModels.add(validationHeader);
				util.markPriceHeaderError(bulkUploadPoValidationOutput, validationHeader,
						APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST);
				util.prismLogger(transactionId, MessageEventType.START, MessageStatus.FAILURE,
						APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST, EVENT_FETCH_PO_PRICE, UPDATE);
			}
		});
		util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bulkUploadPoValidationOutput,
				EVENT_FETCH_PO_PRICE, UPDATE);
		integrator.savePricePayloadCollection(bulkUploadPriceModel);
//		bulkUploadPoValidationOutput.getHeaderModels().removeAll(invalidValidationHeaderModels);
//		return errorGroupIdMap;
	}

	private StringJoiner validateCommonAttributes(BPAUpdationModel poUpdationHeaderModel,
			BPAUpdationModel poUpdationModel) {
		log.info("ValidateCommonAttributes Called");
		log.info("ValidateCommonAttributes poUpdationHeaderModel" + poUpdationHeaderModel);
		log.info("ValidateCommonAttributes poUpdationModel" + poUpdationModel);
		StringJoiner errorMessage = new StringJoiner(" | ");

		if (!poUpdationHeaderModel.equals(poUpdationModel))
			errorMessage.add(HEADER_DATA_MISMATCH_FOR_GIVEN_PO_NUMBER);

		// validate cost attributes to be same across lines
		if (!StringUtils.equals(poUpdationHeaderModel.getInventoryOrg(), poUpdationModel.getInventoryOrg()))
			errorMessage.add(ORGANIZATION_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_PO_NUMBER);

		// validate Line Action to be same across lines
		if (!StringUtils.equals(poUpdationHeaderModel.getAction(), poUpdationModel.getAction()))
			errorMessage.add(LINE_ACTION_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_PO_NUMBER);
		log.info("ValidateCommonAttributes Called ErrorMessage : " + errorMessage);
		return errorMessage;
	}

	private void populateDefaultValues(BPAUpdationModel bpaUpdationModel) {

		log.info("populateDefaultValues Called");

		// Convert OperatingUnit to Upper Case
		bpaUpdationModel.setOperatingUnit(bpaUpdationModel.getOperatingUnit().toUpperCase());

		// LastTimeBuy : If NULL then N. Can be Y or N
		if (bpaUpdationModel.getAction().equalsIgnoreCase(A)) {
			if (StringUtils.isEmpty(bpaUpdationModel.getLastTimeBuy()))
				bpaUpdationModel.setLastTimeBuy(BOOLEAN_N);
			else if (bpaUpdationModel.getLastTimeBuy().equalsIgnoreCase(BOOLEAN_YES)
					|| bpaUpdationModel.getLastTimeBuy().equalsIgnoreCase(BOOLEAN_Y))
				bpaUpdationModel.setLastTimeBuy(BOOLEAN_Y);
			else if (bpaUpdationModel.getLastTimeBuy().equalsIgnoreCase(BOOLEAN_NO)
					|| bpaUpdationModel.getLastTimeBuy().equalsIgnoreCase(BOOLEAN_N))
				bpaUpdationModel.setLastTimeBuy(BOOLEAN_N);
			else
				throw new ApiException(INVALID_VALUE_FOR_LAST_TIME_BUY);
		}

		// LineAction : A - ADD, U - UPDATE
		if (bpaUpdationModel.getAction().equalsIgnoreCase(A) || bpaUpdationModel.getAction().equalsIgnoreCase(ADD))
			bpaUpdationModel.setAction(ADD);
		else if (bpaUpdationModel.getAction().equalsIgnoreCase(U)
				|| bpaUpdationModel.getAction().equalsIgnoreCase(UPDATE))
			bpaUpdationModel.setAction(UPDATE);
		else
			throw new ApiException(INVALID_VALUE_FOR_LINE_ACTION);

		// LastTimeBuy : If NULL then Y. Can be Y or N
		if (bpaUpdationModel.getAction().equalsIgnoreCase(A)) {
			if (StringUtils.isEmpty(bpaUpdationModel.getAllowPriceOverride()))
				bpaUpdationModel.setAllowPriceOverride(BOOLEAN_Y);
			else if (bpaUpdationModel.getAllowPriceOverride().equalsIgnoreCase(BOOLEAN_YES)
					|| bpaUpdationModel.getAllowPriceOverride().equalsIgnoreCase(BOOLEAN_Y))
				bpaUpdationModel.setAllowPriceOverride(BOOLEAN_Y);
			else if (bpaUpdationModel.getAllowPriceOverride().equalsIgnoreCase(BOOLEAN_NO)
					|| bpaUpdationModel.getAllowPriceOverride().equalsIgnoreCase(BOOLEAN_N))
				bpaUpdationModel.setAllowPriceOverride(BOOLEAN_N);
			else
				throw new ApiException(INVALID_VALUE_FOR_ALLOW_PRICE_OVERRIDE);

		}
	}

	private StringJoiner validateMandatoryFields(BPAUpdationModel bpaUpdationModel) {

		log.info("ValidateMandatoryFields Called");

		StringJoiner errorMessage = new StringJoiner(" | ");

		if (StringUtils.isEmpty(bpaUpdationModel.getOperatingUnit())) {
			errorMessage.add(OPERATING_UNIT_FIELD_IS_MISSING);
		}
		if (StringUtils.isEmpty(bpaUpdationModel.getExistingPoNumber())) {
			errorMessage.add(PURCHASE_ORDER_NUMBER_FIELD_IS_MISSING);
		}
		if (StringUtils.isEmpty(bpaUpdationModel.getAction())) {
			errorMessage.add(LINE_ACTION_FIELD_IS_MISSING);

		} else if (!(A.equalsIgnoreCase(bpaUpdationModel.getAction())
				|| U.equalsIgnoreCase(bpaUpdationModel.getAction()))) {
			errorMessage.add(INVALID_VALUE_FOR_ACTION);
		}

		if (null != bpaUpdationModel.getAction()) {
			if (bpaUpdationModel.getAction().equalsIgnoreCase(A)) {

				if (StringUtils.isEmpty(bpaUpdationModel.getItem())) {
					errorMessage.add(ITEM_FIELD_IS_MISSING);
				}
			}
			if (bpaUpdationModel.getAction().equalsIgnoreCase(U)) {

				if (StringUtils.isNotEmpty(bpaUpdationModel.getAllowPriceOverride())) {
					errorMessage.add(ALLOW_PRICE_OVERRIDE_SHOULD_BE_NULL);
				}
				if (StringUtils.isNotEmpty(bpaUpdationModel.getInternalComments())) {
					errorMessage.add("Internal Comments should be null when Action is update");
				}

			}
		}

		if ("40".equals(bpaUpdationModel.getReasonCode())) {

			if (null != bpaUpdationModel.getAction()) {
				if (bpaUpdationModel.getAction().equalsIgnoreCase(U)) {
					errorMessage.add(REASON_CODE_40_IS_NOT_ALLOWED_FOR_THE_UPDATE_OPERATION);
				}
			}
			if (StringUtils.isEmpty(bpaUpdationModel.getInternalComments())) {
				errorMessage.add(INTERNAL_COMMENTS_IS_MANDATORY_WHEN_REASON_CODE_IS_40);
			}
		}

		// LastTimeBuy : If Y then Quantity cannot be NULL
		if (null != bpaUpdationModel.getAction()) {
			if (bpaUpdationModel.getAction().equalsIgnoreCase(A)
					&& (null != bpaUpdationModel.getLastTimeBuy()
							&& bpaUpdationModel.getLastTimeBuy().equalsIgnoreCase(BOOLEAN_Y))
					&& null == bpaUpdationModel.getQuantity()) {
				errorMessage.add("Quantity is mandatory when Last Time Buy is Y");
			}
		}

		// DEFECT - 9481089
		// Price : If Price is entered Reason Code is mandatory
		if (null != bpaUpdationModel.getPrice() && StringUtils.isEmpty(bpaUpdationModel.getReasonCode())) {
			errorMessage.add(REASON_CODE_IS_MANDATORY_WHEN_PRICE_IS_ENTERED);
		}

		if (U.equalsIgnoreCase(bpaUpdationModel.getAction()) && StringUtils.isEmpty(bpaUpdationModel.getItem())
				&& (null != bpaUpdationModel.getQuantity() || null != bpaUpdationModel.getPrice()
						|| StringUtils.isNotEmpty(bpaUpdationModel.getLastTimeBuy())
						|| StringUtils.isNotEmpty(bpaUpdationModel.getReasonCode())
						|| StringUtils.isNotEmpty(bpaUpdationModel.getLineComments())))
			errorMessage.add(ITEM_IS_MANDATORY_FOR_UPDATING_LINE_LEVEL_DETAILS);

		if (StringUtils.isNotEmpty(bpaUpdationModel.getAllowPriceOverride())
				&& !(BOOLEAN_N.equals(bpaUpdationModel.getAllowPriceOverride())
						|| BOOLEAN_Y.equals(bpaUpdationModel.getAllowPriceOverride())))
			errorMessage.add(INVALID_VALUE_FOR_ALLOW_PRICE_OVERRIDE);

		if (StringUtils.isNotEmpty(bpaUpdationModel.getLastTimeBuy())
				&& !(BOOLEAN_N.equals(bpaUpdationModel.getLastTimeBuy())
						|| BOOLEAN_Y.equals(bpaUpdationModel.getLastTimeBuy())))
			errorMessage.add(INVALID_VALUE_FOR_LAST_TIME_BUY);

		log.info("ValidateMandatoryFields Called ErrorMessage : " + errorMessage);
		return errorMessage;
	}

	private void filterValidationOrPriceErrorRecords(ValidationModel validationResponse,
			BPAUpdationInputModel bpaUpdationInputModel, String transactionId,
			BulkUploadErrorModel<BulkUploadUpdationErrorModel> bulkUploadErrorModel, Set<String> failedPONumbers) {
		if (!validationResponse.getStatusCode().equals("SUCCESS")) {
			List<ValidationHeaderModel> invalidRecordList = new ArrayList<>();
			if (StringUtils.isEmpty(validationResponse.getErrorMessage()))
				validationResponse.getHeaderModels().forEach(validationHeaderResponse -> {
					if (!validationHeaderResponse.getStatusCode().equals("S")) {
						invalidRecordList.add(validationHeaderResponse);
						Map<String, String> lineErrorMap = new HashMap<>();
						// validationResponse.getHeaderModels().remove(validationHeaderResponse);
//						invalidRecordList.add(validationHeaderResponse);
						validationHeaderResponse.getLines().forEach(validationLineResponse -> {
							if (!validationLineResponse.getStatusCode().equals("S")) {
								// If already error records exist with same error message, then add to that list
								// else create new entry
								lineErrorMap.put(validationLineResponse.getItem(),
										validationLineResponse.getErrorMessage());
							}
						});
						List<BPAUpdationModel> bpaUpdationModels = bpaUpdationInputModel
								.getBpaUpdationModels().stream().filter(poCreationModel -> validationHeaderResponse
										.getExistingPoNumber().equals(poCreationModel.getExistingPoNumber()))
								.collect(Collectors.toList());
						String[] headerErrorMessage = { null };
						if (!StringUtils.isEmpty(validationHeaderResponse.getErrorMessage())) {
							headerErrorMessage[0] = validationHeaderResponse.getErrorMessage()
									.replaceAll(ERROR_IN_UNDERLYING_LINES, "");
						}
						bpaUpdationModels.forEach(bpaUpdationModel -> {
							String lineErrorMessage = lineErrorMap.get(bpaUpdationModel.getItem());
							if (StringUtils.isBlank(headerErrorMessage[0]))
								populateBulkUploadPOErrorModel(bpaUpdationModel, lineErrorMessage, bulkUploadErrorModel,
										failedPONumbers);
							else if (StringUtils.isBlank(lineErrorMessage))
								populateBulkUploadPOErrorModel(bpaUpdationModel, headerErrorMessage[0],
										bulkUploadErrorModel, failedPONumbers);
							else
								populateBulkUploadPOErrorModel(bpaUpdationModel,
										headerErrorMessage[0] + ERROR_MESSAGE_DELIMITER + lineErrorMessage,
										bulkUploadErrorModel, failedPONumbers);
						});
					}
				});
			else
				throw new ApiException(APPLICATION_ERROR_ENCOUNTERED_DURING_VALIDATION);
			validationResponse.getHeaderModels().removeAll(invalidRecordList);
			if (!invalidRecordList.isEmpty()) {
				util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null,
						EVENT_BULK_UPLOAD_POST_VALIDATION_NACK, UPDATE);
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, invalidRecordList,
						EVENT_BULK_UPLOAD_POST_VALIDATION_NACK, UPDATE);
			}
		}
	}

	private void filterImportErrorRecords(ImportOutputModel importOutputModel,
			BPAUpdationInputModel bpaUpdationInputModel, String transactionId,
			BulkUploadErrorModel<BulkUploadUpdationErrorModel> bulkUploadErrorModel, Set<String> failedPONumbers) {
		if (null == importOutputModel) {
			throw new ApiException(APPLICATION_ERROR_ENCOUNTERED_DURING_IMPORT);
		} else {
			List<ImportEBSOutputModel> invalidRecordList = new ArrayList<>();
			importOutputModel.getBulkUploadImportOutput().forEach(importoutputResponse -> {
				if (!importoutputResponse.getStatusCode().equals("SUCCESS")) {
					if (StringUtils.isEmpty(importoutputResponse.getErrorMessage()))
						if (!importoutputResponse.getStatusCode().equals("S")) {
							invalidRecordList.add(importoutputResponse);
							Map<String, String> lineErrorMap = new HashMap<>();
							importoutputResponse.getBulkUploadImportHeaderModel().getLines()
									.forEach(importLineResponse -> {
										if (!importLineResponse.getStatusCode().equals("S")) {
											// If already error records exist with same error message, then add to that
											// list
											// else create new entry
											lineErrorMap.put(importLineResponse.getItem(),
													importLineResponse.getErrorMessage());
										}
									});
							List<BPAUpdationModel> bpaUpdationModels = bpaUpdationInputModel.getBpaUpdationModels()
									.stream()
									.filter(poUpdationModel -> importoutputResponse.getBulkUploadImportHeaderModel()
											.getExistingPoNumber().equals(poUpdationModel.getExistingPoNumber()))
									.collect(Collectors.toList());
							String[] headerErrorMessage = { null };
							if (!StringUtils.isEmpty(importoutputResponse.getErrorMessage())) {
								headerErrorMessage[0] = importoutputResponse.getErrorMessage()
										.replaceAll(ERROR_IN_UNDERLYING_LINES, "");
							}
							bpaUpdationModels.forEach(bpaUpdationModel -> {
								String lineErrorMessage = lineErrorMap.get(bpaUpdationModel.getItem());
								if (StringUtils.isBlank(headerErrorMessage[0]))
									populateBulkUploadPOErrorModel(bpaUpdationModel, lineErrorMessage,
											bulkUploadErrorModel, failedPONumbers);
								else if (StringUtils.isBlank(lineErrorMessage))
									populateBulkUploadPOErrorModel(bpaUpdationModel, headerErrorMessage[0],
											bulkUploadErrorModel, failedPONumbers);
								else
									populateBulkUploadPOErrorModel(bpaUpdationModel,
											headerErrorMessage[0] + ERROR_MESSAGE_DELIMITER + lineErrorMessage,
											bulkUploadErrorModel, failedPONumbers);

							});
						} else
							throw new ApiException(APPLICATION_ERROR_ENCOUNTERED_DURING_IMPORT);
				}
			});
			importOutputModel.getBulkUploadImportOutput().removeAll(invalidRecordList);
			if (!invalidRecordList.isEmpty()) {
				util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, invalidRecordList,
						EVENT_BULK_UPLOAD_POST_CREATION_NACK, UPDATE);
			}
		}

	}

	private StringJoiner validateFieldLength(BPAUpdationModel poUpdationModel) {
		StringJoiner errorMessage = new StringJoiner(" | ");

		if (StringUtils.length(poUpdationModel.getOperatingUnit()) > 240) {
			errorMessage.add(INVALID_OPERATING_UNIT_LENGTH);
		}
		if (StringUtils.length(poUpdationModel.getExistingPoNumber()) > 20)
			errorMessage.add(INVALID_PURCHASE_ORDER_NUMBER_LENGTH);

		if (StringUtils.length(poUpdationModel.getClauses()) > 150) {
			errorMessage.add(INVALID_CLAUSES_LENGTH);
		}
		if (StringUtils.length(poUpdationModel.getAttachment()) > 100) {
			errorMessage.add(INVALID_ATTACHMENT_FILE_NAME_LENGTH);
		}
		if (StringUtils.length(poUpdationModel.getItem()) > 1000) {
			errorMessage.add(INVALID_ITEM_LENGTH);
		}
		if (StringUtils.length(poUpdationModel.getLastTimeBuy()) > 150) {
			errorMessage.add(INVALID_LAST_TIME_BUY_LENGTH);
		}
		if (StringUtils.length(poUpdationModel.getLineComments()) > 1000) {
			errorMessage.add(INVALID_LINE_COMMENTS_LENGTH);
		}
		if (StringUtils.length(poUpdationModel.getInternalComments()) > 480) {
			errorMessage.add(INVALID_INTERNAL_COMMENTS_LENGTH);
		}
		if (StringUtils.length(poUpdationModel.getReasonCode()) > 10) {
			errorMessage.add(INVALID_REASON_CODE_LENGTH);
		}
		/*
		 * if (StringUtils.length(poUpdationModel.getInventoryOrg()) > 150) {
		 * errorMessage.add(INVALID_INVENTORY_ORG_LENGTH); }
		 */
		if (StringUtils.length(poUpdationModel.getAllowPriceOverride()) > 150) {
			errorMessage.add(INVALID_ALLOW_PRICE_OVERRIDE_LENGTH);
		}
		/*
		 * if (StringUtils.length(poUpdationModel.getIccSlcLocation()) > 150) {
		 * errorMessage.add(INVALID_ICC_SLC_LOCATION_LENGTH); }
		 */

		if (StringUtils.length(poUpdationModel.getDefaultShipToLocation()) > 60) {
			errorMessage.add(INVALID_DEFAULT_SHIP_TO_LOCATION_LENGTH);
		}
		return errorMessage;
	}

	private void removeLeadingAndTrailingSpaces(BPAUpdationModel bpaUpdationModel) {

		bpaUpdationModel.setOperatingUnit(StringUtils.trim(bpaUpdationModel.getOperatingUnit()));
		bpaUpdationModel.setClauses(StringUtils.trim(bpaUpdationModel.getClauses()));
		bpaUpdationModel.setAttachment(StringUtils.trim(bpaUpdationModel.getAttachment()));
		bpaUpdationModel.setItem(StringUtils.trim(bpaUpdationModel.getItem()));
		bpaUpdationModel.setLastTimeBuy(StringUtils.trim(bpaUpdationModel.getLastTimeBuy()));
		bpaUpdationModel.setLineComments(StringUtils.trim(bpaUpdationModel.getLineComments()));
		bpaUpdationModel.setInternalComments(StringUtils.trim(bpaUpdationModel.getInternalComments()));
		bpaUpdationModel.setReasonCode(StringUtils.trim(bpaUpdationModel.getReasonCode()));
		// bpaUpdationModel.setInventoryOrg(StringUtils.trim(bpaUpdationModel.getInventoryOrg()));
		bpaUpdationModel.setAllowPriceOverride(StringUtils.trim(bpaUpdationModel.getAllowPriceOverride()));
		bpaUpdationModel.setDefaultShipToLocation(StringUtils.trim(bpaUpdationModel.getDefaultShipToLocation()));
	}
}