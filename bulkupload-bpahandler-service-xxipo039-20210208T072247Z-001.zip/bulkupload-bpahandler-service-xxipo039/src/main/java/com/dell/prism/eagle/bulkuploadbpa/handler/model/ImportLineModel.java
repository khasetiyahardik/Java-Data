package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class ImportLineModel {

	private BigDecimal lineNum;
	private BigDecimal poLineId;
	private String action;
	private String item;
	private BigDecimal itemId;
	private BigDecimal quantity;
	private Double unitPrice;
	private Double listPrice;
	private String costType;
	private String priceCompleteFlag;
	private String lastTimeBuy;
	private String allowPriceOverride;
	private Timestamp needByDate;
	private Timestamp shipByDate;
	private Timestamp releaseByDate;
	private String vendorProductNum;
	private BigDecimal itemBuyerId;
	private String itemType;
	private String lineComments;
	private String internalComments;
	private String reasonCode;
	private String statusCode;
	private String errorMessage;
	private String errorCode;
	private List<ImportShipmentModel> shipments;
}