package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class PricePartDetailsModel {

	private String partNumber;
	private String effectiveDate;
	private String partType;
	private Date releaseDate;
	private Double price;
	private String costType;
	private String validationMessage;
}
