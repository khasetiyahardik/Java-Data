package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class BulkUploadUpdationErrorModel {

	private BPAUpdationModel inputPayload;
	private String errorMessage;
}