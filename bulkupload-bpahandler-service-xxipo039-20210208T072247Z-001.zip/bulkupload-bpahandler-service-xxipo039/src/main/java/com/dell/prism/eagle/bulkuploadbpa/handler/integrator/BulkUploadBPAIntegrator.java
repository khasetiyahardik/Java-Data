package com.dell.prism.eagle.bulkuploadbpa.handler.integrator;

import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BULK_UPLOAD_TRANSACTION_ID_SEQUENCE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.COLLECTION_BULK_UPLOAD_ERROR;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.COLLECTION_BULK_UPLOAD_PAYLOAD;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.COLLECTION_BULK_UPLOAD_PRICE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.FOR_TRANSACTION_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.GENERATED_TRANSACTION_ID_SEQUENCE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.GENERATING_TRANSACTION_ID_SEQUENCE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVOKING_BULK_UPLOAD_IMPORT_SERVICE_FOR_TRANSACTION_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVOKING_BULK_UPLOAD_VALIDATION_SERVICE_FOR_TRANSACTION_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVOKING_PO_PRICE_SERVICE_FOR_TRANSACTION_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.PAYLOAD;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.SAVING_DATA_TO_BULK_UPLOAD_ERROR_COLLECTION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.SAVING_DATA_TO_BULK_UPLOAD_PAYLOAD_COLLECTION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.SAVING_DATA_TO_BULK_UPLOAD_PRICE_COLLECTION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.TRANSACTION_ID_SEQUENCE_PREFIX;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.dell.prism.eagle.bulkuploadbpa.handler.config.SecurityServiceImpl;
import com.dell.prism.eagle.bulkuploadbpa.handler.feign.BulkUploadBPAProxy;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadErrorModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadPayloadModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadPriceModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportInputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportOutputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.PriceHeaderModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.Sequence;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationModel;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class BulkUploadBPAIntegrator {

	@Value(value = "${dias.clientdId}")
	String clientid;
	@Autowired
	SecurityServiceImpl securityServiceImpl;

	@Autowired
	MongoTemplate mongoTemplate;
	@Autowired
	BulkUploadBPAProxy bulkUploadBPAProxy;

	@Retryable(value = {
			Exception.class }, maxAttemptsExpression = "#{${retry.count}}", backoff = @Backoff(delayExpression = "#{${retry.delay}}"))
	public String generateTransactionId() {
		log.info(GENERATING_TRANSACTION_ID_SEQUENCE);
		Sequence transactionIdSequence = mongoTemplate.findAndModify(
				new Query(Criteria.where("_id").is(BULK_UPLOAD_TRANSACTION_ID_SEQUENCE)),
				new Update().inc("sequenceValue", 1), new FindAndModifyOptions().returnNew(true), Sequence.class);
		log.info(GENERATED_TRANSACTION_ID_SEQUENCE + transactionIdSequence);
		return TRANSACTION_ID_SEQUENCE_PREFIX + transactionIdSequence.getSequenceValue().toString();
	}

	@Retryable(value = {
			Exception.class }, maxAttemptsExpression = "#{${retry.count}}", backoff = @Backoff(delayExpression = "#{${retry.delay}}"))
	public ValidationModel callbulkUploadValidationService(ValidationModel bulkUploadValidationModel) {
		log.info(INVOKING_BULK_UPLOAD_VALIDATION_SERVICE_FOR_TRANSACTION_ID
				+ bulkUploadValidationModel.getTransactionId());
		log.info(PAYLOAD + bulkUploadValidationModel);
		String accessToken = securityServiceImpl.getAccessToken();
		return bulkUploadBPAProxy.callbulkUploadValidationService(accessToken, clientid, bulkUploadValidationModel);
	}

	@Retryable(value = {
			Exception.class }, maxAttemptsExpression = "#{${retry.count}}", backoff = @Backoff(delayExpression = "#{${retry.delay}}"))
	public PriceHeaderModel fetchPOPrice(PriceHeaderModel priceHeaderModel, String transactionId) {
		log.info(INVOKING_PO_PRICE_SERVICE_FOR_TRANSACTION_ID + transactionId);
		log.info(PAYLOAD + priceHeaderModel);
		String accessToken = securityServiceImpl.getAccessToken();
		return bulkUploadBPAProxy.fetchPOPrice(accessToken, clientid, priceHeaderModel, transactionId);
	}

	@Retryable(value = {
			Exception.class }, maxAttemptsExpression = "#{${retry.count}}", backoff = @Backoff(delayExpression = "#{${retry.delay}}"))
	public ImportOutputModel callbulkUploadImportService(ImportInputModel importInputModel) {
		log.info(INVOKING_BULK_UPLOAD_IMPORT_SERVICE_FOR_TRANSACTION_ID + importInputModel.getTransactionId());
		log.info(PAYLOAD + importInputModel);
		String accessToken = securityServiceImpl.getAccessToken();
		return bulkUploadBPAProxy.callbulkUploadImportService(accessToken, clientid, importInputModel);
	}

	@Retryable(value = {
			Exception.class }, maxAttemptsExpression = "#{${retry.count}}", backoff = @Backoff(delayExpression = "#{${retry.delay}}"))
	public <X, Y> void savePayloadCollection(BulkUploadPayloadModel<X, Y> bulkUploadPayloadModel) {
		log.info(SAVING_DATA_TO_BULK_UPLOAD_PAYLOAD_COLLECTION + COLLECTION_BULK_UPLOAD_PAYLOAD + FOR_TRANSACTION_ID
				+ bulkUploadPayloadModel.getTransactionId());
		log.info(PAYLOAD + bulkUploadPayloadModel);
		bulkUploadPayloadModel.setModifiedDate(new Date());
		mongoTemplate.save(bulkUploadPayloadModel);
	}

	@Retryable(value = {
			Exception.class }, maxAttemptsExpression = "#{${retry.count}}", backoff = @Backoff(delayExpression = "#{${retry.delay}}"))
	public <T> void saveErrorPayloadCollection(BulkUploadErrorModel<T> bulkUploadErrorModel) {
		log.info(SAVING_DATA_TO_BULK_UPLOAD_ERROR_COLLECTION + COLLECTION_BULK_UPLOAD_ERROR + FOR_TRANSACTION_ID
				+ bulkUploadErrorModel.getTransactionId());
		log.info(PAYLOAD + bulkUploadErrorModel);
		bulkUploadErrorModel.setModifiedDate(new Date());
		mongoTemplate.save(bulkUploadErrorModel);
	}

	@Retryable(value = {
			Exception.class }, maxAttemptsExpression = "#{${retry.count}}", backoff = @Backoff(delayExpression = "#{${retry.delay}}"))
	public void savePricePayloadCollection(BulkUploadPriceModel bulkUploadPriceModel) {
		log.info(SAVING_DATA_TO_BULK_UPLOAD_PRICE_COLLECTION + COLLECTION_BULK_UPLOAD_PRICE + FOR_TRANSACTION_ID
				+ bulkUploadPriceModel.getTransactionId());
		log.info(PAYLOAD + bulkUploadPriceModel);
		bulkUploadPriceModel.setModifiedDate(new Date());
		mongoTemplate.save(bulkUploadPriceModel);
	}
}
