package com.dell.prism.eagle.bulkuploadbpa.handler.controller;

import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BULKUPLOAD_BPA_CREATE_URI;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BULKUPLOAD_BPA_UPDATE_URI;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BULKUPLOAD_GET_TRANSACTION_ID_URI;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.PAYLOAD;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPACreationInputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPAUpdationInputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.service.BulkUploadBPACreateService;
import com.dell.prism.eagle.bulkuploadbpa.handler.service.BulkUploadBPAUpdateService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@CrossOrigin
@RestController
public class BulkUploadBPAController {

	public static final String RECEIVED_INPUT_FOR_GETTING_TRANSACTION_ID = "Received input for getting transactionId";

	public static final String RECEIVED_INPUT_FOR_BPA_CREATION = "Received input for BPA Creation";

	public static final String RECEIVED_INPUT_FOR_BPA_UPDATION = "Received input for BPA Updation";

	@Autowired
	private BulkUploadBPACreateService bulkuploadBPACreateService;

	@Autowired
	private BulkUploadBPAUpdateService bulkUploadBPAUpdateService;

	@Value("${springdoc.swagger-ui.path:/swagger-ui.html}")
	private String swaggerPath;
	
	@PostMapping(path = BULKUPLOAD_BPA_CREATE_URI)
	public void bulkuploadPoCreate(@RequestBody @Valid BPACreationInputModel bpaCreationInputModel) {
		log.info(RECEIVED_INPUT_FOR_BPA_CREATION);
		log.info(PAYLOAD + bpaCreationInputModel);
		bulkuploadBPACreateService.invokeBPACreation(bpaCreationInputModel);
	}

	@PostMapping(path = BULKUPLOAD_BPA_UPDATE_URI)
	public void bulkuploadPoUpdate(@RequestBody @Valid BPAUpdationInputModel poUpdationInputModel) {
		log.info(RECEIVED_INPUT_FOR_BPA_UPDATION);
		log.info(PAYLOAD + poUpdationInputModel);
		bulkUploadBPAUpdateService.invokeBPAUpdation(poUpdationInputModel);
	}

	@GetMapping(path = BULKUPLOAD_GET_TRANSACTION_ID_URI)
	public ResponseEntity<String> getTransactionId() {
		log.info(RECEIVED_INPUT_FOR_GETTING_TRANSACTION_ID);
		return new ResponseEntity<>(bulkuploadBPACreateService.getTransactionId(), HttpStatus.OK);
	}

	@GetMapping("/")
	public void swaggerRedirect(HttpServletResponse response) {
		response.setHeader("Location", swaggerPath);
		response.setStatus(302);
	}
}