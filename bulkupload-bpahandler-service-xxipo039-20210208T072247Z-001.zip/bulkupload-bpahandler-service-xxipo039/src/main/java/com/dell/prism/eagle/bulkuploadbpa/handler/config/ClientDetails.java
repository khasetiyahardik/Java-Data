package com.dell.prism.eagle.bulkuploadbpa.handler.config;

import lombok.Data;

@Data
public class ClientDetails {

	private String grant_type;

	public ClientDetails(String grant_type) {
		super();
		this.grant_type = grant_type;
	}
}