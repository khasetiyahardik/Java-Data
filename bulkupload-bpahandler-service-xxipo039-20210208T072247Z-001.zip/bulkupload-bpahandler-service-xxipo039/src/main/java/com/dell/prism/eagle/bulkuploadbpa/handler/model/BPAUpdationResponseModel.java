package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BPAUpdationResponseModel extends BPACreationModel {

	private String existingPoNumber;
	private String statusCode;
	private String errorMessage;
	private String action;
}
