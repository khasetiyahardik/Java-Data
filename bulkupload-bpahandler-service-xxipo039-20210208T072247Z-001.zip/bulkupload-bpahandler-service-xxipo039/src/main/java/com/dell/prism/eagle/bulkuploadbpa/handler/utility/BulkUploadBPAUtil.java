package com.dell.prism.eagle.bulkuploadbpa.handler.utility;

import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.A;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ADD;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BLANKET_PURCHASE_ORDER;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BLANKET_SOURCE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BOOLEAN_N;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BOOLEAN_Y;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BUSSINESS_OBJECT;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ERROR_MESSAGE_DELIMITER;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.KEY_ACTION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.KEY_SOURCE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATUS_DETAILS_PRE_VALIDATION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATUS_FAILED;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATUS_IN_PROCESS;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATUS_PARTIAL_SUCCESS;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATUS_SUCCESS;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.U;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.UPDATE;

import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.dell.prism.eagle.bulkuploadbpa.handler.integrator.BulkUploadBPAIntegrator;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadErrorModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadPayloadModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadPriceModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.StatusDetails;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationHeaderModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationLineModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationModel;
import com.dell.prism.transactionlogger.model.Message.MessageBuilder;
import com.dell.prism.transactionlogger.model.MessageEventType;
import com.dell.prism.transactionlogger.model.MessageStatus;
import com.dell.prism.transactionlogger.services.PrismTransactionsLogger;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class BulkUploadBPAUtil {

	@Value("${spring.application.name}")
	private static String serviceName;

	@Autowired
	BulkUploadBPAIntegrator retryUtil;

	@Autowired
	private PrismTransactionsLogger prismTransactionsLogger;

	public BulkUploadPriceModel initializeBulkUploadPriceModel(String transactionId) {
		BulkUploadPriceModel bulkUploadPriceModel = new BulkUploadPriceModel();
		bulkUploadPriceModel.setTransactionId(transactionId);
		bulkUploadPriceModel.setInputPayload(new ArrayList<>());
		bulkUploadPriceModel.setResponsePayload(new ArrayList<>());
		bulkUploadPriceModel.setCreatedDate(new Date());
		bulkUploadPriceModel.setModifiedDate(new Date());
		bulkUploadPriceModel.setModifiedBy(serviceName);
		return bulkUploadPriceModel;
	}

	public <X, Y> BulkUploadPayloadModel<X, Y> initializeBulkUploadPayloadModel(
			BulkUploadPayloadModel<X, Y> bulkUploadPayloadModel, String transactionId) {
		bulkUploadPayloadModel.setTransactionId(transactionId);
		bulkUploadPayloadModel.setTemplate(BLANKET_PURCHASE_ORDER);
		bulkUploadPayloadModel.setInputPayload(new ArrayList<>());
		bulkUploadPayloadModel.setResponsePayload(new ArrayList<>());
		bulkUploadPayloadModel.setStatus(STATUS_IN_PROCESS);
		bulkUploadPayloadModel.setStatusDetails(StatusDetails.builder().stage(STATUS_DETAILS_PRE_VALIDATION).build());
		bulkUploadPayloadModel.setCreatedDate(new Date());
		bulkUploadPayloadModel.setModifiedDate(new Date());
		bulkUploadPayloadModel.setModifiedBy(serviceName);
		return bulkUploadPayloadModel;
	}

	public <T> BulkUploadErrorModel<T> initializeBulkUploadErrorModel(BulkUploadErrorModel<T> bulkUploadErrorModel,
			String transactionId) {
		bulkUploadErrorModel.setTransactionId(transactionId);
		bulkUploadErrorModel.setErrorPayload(new ArrayList<>());
		bulkUploadErrorModel.setCreatedDate(new Date());
		bulkUploadErrorModel.setModifiedDate(new Date());
		bulkUploadErrorModel.setModifiedBy(serviceName);
		return bulkUploadErrorModel;
	}

	public <X, Y> void updatePayloadCollectionStatus(BulkUploadPayloadModel<X, Y> bulkUploadPayloadModel,
			int errorRecordsSize) {
		Integer totalRecordsSize = bulkUploadPayloadModel.getInputPayload().size();
		if (errorRecordsSize == 0) {
			bulkUploadPayloadModel.getStatusDetails().setSuccessRate((double) 100);
			bulkUploadPayloadModel.getStatusDetails().setSuccessRecords(totalRecordsSize);
			bulkUploadPayloadModel.setStatus(STATUS_SUCCESS);
		} else if (bulkUploadPayloadModel.getInputPayload().size() == errorRecordsSize) {
			bulkUploadPayloadModel.getStatusDetails().setSuccessRate((double) 0);
			bulkUploadPayloadModel.getStatusDetails().setSuccessRecords(0);
			bulkUploadPayloadModel.setStatus(STATUS_FAILED);
		} else {
			int successRecords = totalRecordsSize - errorRecordsSize;
			double successRate = ((double) successRecords / bulkUploadPayloadModel.getInputPayload().size()) * (100);
			bulkUploadPayloadModel.getStatusDetails().setSuccessRate(successRate);
			bulkUploadPayloadModel.getStatusDetails().setSuccessRecords(successRecords);
			bulkUploadPayloadModel.setStatus(STATUS_PARTIAL_SUCCESS);
		}
		bulkUploadPayloadModel.getStatusDetails().setTotalRecords(totalRecordsSize);
		retryUtil.savePayloadCollection(bulkUploadPayloadModel);
	}

	public <X, Y> void updatePayloadCollectionStatusDetails(BulkUploadPayloadModel<X, Y> bulkUploadPayloadModel,
			String statusDetails) {
		bulkUploadPayloadModel.getStatusDetails().setStage(statusDetails);
		retryUtil.savePayloadCollection(bulkUploadPayloadModel);
	}

	public void prismLogger(String transactionId, MessageEventType eventType, MessageStatus status, Object payload,
			String eventName, String action) {
		try {
			prismTransactionsLogger.send(new MessageBuilder().traceId(transactionId).businessObject(BUSSINESS_OBJECT)
					.eventName(eventName).eventType(eventType).status(status).payload(payload)
					.addAdditionalPayloadAttribute(KEY_SOURCE, BLANKET_SOURCE)
					.addAdditionalPayloadAttribute(KEY_ACTION, action).build());
		} catch (Exception e) {
			log.error("Transaction ID: " + transactionId + " Failed to send to Prism logger.", e);
		}
	}

	public void markPriceHeaderError(ValidationModel validationModel, ValidationHeaderModel validationHeader,
			String errorMessage) {
		validationModel.setStatusCode("FAILURE");
		validationHeader.setStatusCode("E");
		validationHeader.setErrorMessage(StringUtils.isBlank(validationHeader.getErrorMessage()) ? errorMessage
				: validationHeader.getErrorMessage() + ERROR_MESSAGE_DELIMITER + errorMessage);
	}

	public void markPriceLineError(ValidationModel validationModel, ValidationHeaderModel validationHeader,
			ValidationLineModel validationLine, String errorMessage) {
		validationModel.setStatusCode("FAILURE");
		validationHeader.setStatusCode("E");
		validationLine.setStatusCode("E");
		validationLine.setErrorMessage(StringUtils.isBlank(validationLine.getErrorMessage()) ? errorMessage
				: validationLine.getErrorMessage() + ERROR_MESSAGE_DELIMITER + errorMessage);
	}

	public void populateDefaultValues(ValidationLineModel validationLineModel) {

		if (A.equalsIgnoreCase(validationLineModel.getAction()))
			validationLineModel.setAction(ADD);
		else if (U.equalsIgnoreCase(validationLineModel.getAction()))
			validationLineModel.setAction(UPDATE);

		// LastTimeBuy : If NULL then N. Not to be defaulted for UPDATE action
		if (!UPDATE.equalsIgnoreCase(validationLineModel.getAction())
				&& StringUtils.isEmpty(validationLineModel.getLastTimeBuy()))
			validationLineModel.setLastTimeBuy(BOOLEAN_N);

		// AllowPriceOverride : If NULL then Y. Not to be defaulted for UPDATE action
		if (!UPDATE.equalsIgnoreCase(validationLineModel.getAction())
				&& StringUtils.isEmpty(validationLineModel.getAllowPriceOverride()))
			validationLineModel.setAllowPriceOverride(BOOLEAN_Y);
	}

	public void populateDefaultValues(ValidationHeaderModel validationHeaderModel) {

		// Convert OperatingUnit to Upper Case
		validationHeaderModel.setOperatingUnit(validationHeaderModel.getOperatingUnit().toUpperCase());

		if (A.equalsIgnoreCase(validationHeaderModel.getAction()))
			validationHeaderModel.setAction(ADD);
		else if (U.equalsIgnoreCase(validationHeaderModel.getAction()))
			validationHeaderModel.setAction(UPDATE);

	}
}