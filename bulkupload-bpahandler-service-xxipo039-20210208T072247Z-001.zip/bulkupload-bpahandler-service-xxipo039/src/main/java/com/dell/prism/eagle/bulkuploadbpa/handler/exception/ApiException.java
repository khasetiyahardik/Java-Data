package com.dell.prism.eagle.bulkuploadbpa.handler.exception;

import lombok.Getter;

@Getter
public class ApiException extends RuntimeException {

	private static final long serialVersionUID = 6718252450246325984L;

	private final String errorMessage;

	public ApiException(String errorMessage) {
		this.errorMessage = errorMessage;
	}
}