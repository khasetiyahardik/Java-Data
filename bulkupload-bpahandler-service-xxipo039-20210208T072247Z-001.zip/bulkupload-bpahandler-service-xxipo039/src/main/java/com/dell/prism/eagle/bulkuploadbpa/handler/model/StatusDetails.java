package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StatusDetails {

	private String stage;
	private Double successRate;
	private Integer failedInPreValidationRecords;
	private Integer failedInValidationOrPriceRecords;
	private Integer failedInImportRecords;
	private Integer successRecords;
	private Integer totalRecords;
}
