package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import java.math.BigDecimal;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class BPAUpdationModel {

	@JsonProperty("Operating Unit")
	private String operatingUnit;
	@JsonProperty("Blanket Purchase Order")
	private String existingPoNumber;
	@JsonProperty("Clauses")
	private String clauses;
	@JsonProperty("Attachment File Name")
	private String attachment;
	@JsonProperty("Inventory Org")
	private String inventoryOrg;
	@JsonProperty("ICC SLC Location")
	private String iccSlcLocation;
	@JsonProperty("Default Ship To Location")
	private String defaultShipToLocation;

	// Line Level fields
	@JsonProperty("Action")
	private String action;
	@JsonProperty("Item")
	private String item;
	@JsonProperty("Quantity Agreed")
	private BigDecimal quantity;
	@JsonProperty("Price")
	private Double price;
	@JsonProperty("Reason Code")
	private String reasonCode;
	@JsonProperty("Last Time Buy")
	private String lastTimeBuy;
	@JsonProperty("Line Comments")
	private String lineComments;
	@JsonProperty("Internal Comments")
	private String internalComments;
	@JsonProperty("Allow Price Override")
	private String allowPriceOverride;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BPAUpdationModel other = (BPAUpdationModel) obj;
		return Objects.equals(attachment, other.attachment) && Objects.equals(inventoryOrg, other.inventoryOrg)
				&& Objects.equals(defaultShipToLocation, other.defaultShipToLocation)
				&& Objects.equals(clauses, other.clauses) && Objects.equals(existingPoNumber, other.existingPoNumber)
				&& Objects.equals(operatingUnit, other.operatingUnit);
	}

	@Override
	public int hashCode() {
		return Objects.hash(attachment, inventoryOrg, defaultShipToLocation, clauses, existingPoNumber, operatingUnit);
	}
}