package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class ImportHeaderModel {

	private String poNumber;
	private String existingPoNumber;
	private BigDecimal poHeaderId;
	private BigDecimal poRevisionNumber;
	private BigDecimal poAmount;
	private String action;
	private String poTypeLookUpCode;
	private String styleName;
	private BigDecimal styleId;
	private String groupId;
	private String operatingUnit;
	private BigDecimal orgId;
	private String poSite;
	private String shipTo;
	private String vendor;
	private BigDecimal vendorId;
	private String vendorLoc;
	private BigDecimal vendorSiteId;
	private String defaultShipToLocation;
	private String shipToLocation;
	private BigDecimal shipToLocationId;
	private String billToLocation;
	private BigDecimal billToLocationId;
	private String buyerCode;
	private BigDecimal buyerId;
	private String buyerEmailId;
	private String inventoryOrgCode;
	private BigDecimal inventoryOrgId;
	private String vmiDirect;
	private String iccSlcLocation;
	private String emailAddress;
	private String byPassAutogen;
	private String comments;
	private String trnsMethod;
	private String freightCarrier;
	private String delTerms;
	private String clauses;
	private String receiptType;
	private String paletteNumber;
	private String attachmentFileName;
	private String odmPoFlag;
	private String statusCode;
	private String errorMessage;
	private String errorCode;
	private List<ImportLineModel> lines;

}