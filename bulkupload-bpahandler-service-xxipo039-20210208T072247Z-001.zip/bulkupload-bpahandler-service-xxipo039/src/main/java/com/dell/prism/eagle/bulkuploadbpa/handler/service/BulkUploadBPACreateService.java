package com.dell.prism.eagle.bulkuploadbpa.handler.service;

import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ADD;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.APPLICATION_ERROR_ENCOUNTERED_DURING_IMPORT;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.APPLICATION_ERROR_ENCOUNTERED_DURING_VALIDATION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BLANKET;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BOOLEAN_N;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BOOLEAN_NO;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BOOLEAN_Y;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BOOLEAN_YES;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BPA_TYPE_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.BULK_UPLOAD_PAYLOAD_SAVED_TO_MONGODB_FOR_TRANSACTION_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.COST_TYPE_MANUAL;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.CREATE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.DEFAULT_SHIP_TO_LOCATION_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.DUPLICATE_ITEM_ERROR_FOR_GIVEN_GROUP_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ERROR_COST_TYPE_MN_ATTACHMENT_MANDATORY;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ERROR_IN_UNDERLYING_LINES;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ERROR_MANDATORY_PO_COST_ATTRIBUTES_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ERROR_MESSAGE_DELIMITER;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_BULK_UPLOAD_CREATION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_BULK_UPLOAD_POST_CREATION_NACK;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_BULK_UPLOAD_POST_PRICE_NACK;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_BULK_UPLOAD_POST_VALIDATION_NACK;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_BULK_UPLOAD_PRE_VALIDATION_NACK;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_BULK_UPLOAD_VALIDATION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_FETCH_PO_PRICE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.EVENT_RECEIVE_BULK_UPLOAD_MESSAGE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.GROUP_ID_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.HEADER_DATA_MISMATCH_FOR_GIVEN_GROUP_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INTERNAL_COMMENTS_IS_MANDATORY_WHEN_REASON_CODE_IS_40;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_ALLOW_PRICE_OVERRIDE_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_ATTACHMENT_FILE_NAME_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_BILL_TO_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_BPA_TYPE_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_CLAUSES_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_DEFAULT_SHIP_TO_LOCATION_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_DESCRIPTION_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_FREIGHT_TERMS_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_GROUP_ID_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_INTERNAL_COMMENTS_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_ITEM_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_LAST_TIME_BUY_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_LINE_COMMENTS_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_OPERATING_UNIT_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_PO_SITE_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_PRICE_RETURN_FROM_PRICE_SERVICE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_REASON_CODE_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_SHIP_VIA_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_SITE_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_STYLE_NAME_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_SUPPLIER_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_TRANS_METHOD_LENGTH;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_VALUE_FOR_ALLOW_PRICE_OVERRIDE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVALID_VALUE_FOR_LAST_TIME_BUY;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.INVENTORY_ORG_CODE_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_GROUP_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ITEM_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.OPERATING_UNIT_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.PO_SITE_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.PRE_VALIDATION_CHECK_FAILED_WITH_ERROR_MESSAGE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.QUANTITY_IS_MANDATORY_WHEN_LAST_TIME_BUY_IS_Y;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.REASON_CODE_IS_MANDATORY_WHEN_PRICE_IS_ENTERED;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.SITE_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATING_ASYNC_METHOD_INVOCATION_PART_FOR_TRANSACTION_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATUS_DETAILS_IMPORT;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATUS_DETAILS_PRICE;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STATUS_DETAILS_VALIDATION;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.STYLE_NAME_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.SUPPLIER_FIELD_IS_MISSING;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.VALIDATE_COMMON_ATTRIBUTES_CALLED_FOR_TRANSACTION_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.VALIDATE_FIELD_LENGTH_CALLED_FOR_TRANSACTION_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.VMI_DIRECT_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_GROUP_ID;
import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.ERROR_TOTAL_COST_MORE_THAN_DEFINED_LIMIT_ATTACHMENT_MANDATORY;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dell.prism.eagle.bulkuploadbpa.handler.exception.ApiException;
import com.dell.prism.eagle.bulkuploadbpa.handler.integrator.BulkUploadBPAIntegrator;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPACreationInputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPACreationModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPACreationResponseModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadCreationErrorModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadErrorModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadPayloadModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadPriceModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportEBSOutputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportHeaderModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportInputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportLineModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportOutputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportShipmentModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.PriceHeaderModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.PricePartDetailsModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationHeaderModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationLineModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.utility.BulkUploadBPAUtil;
import com.dell.prism.eagle.bulkuploadbpa.handler.utility.DateStringUtil;
import com.dell.prism.eagle.bulkuploadbpa.handler.utility.MailUtil;
import com.dell.prism.transactionlogger.model.MessageEventType;
import com.dell.prism.transactionlogger.model.MessageStatus;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BulkUploadBPACreateService {

	@Autowired
	BulkUploadBPAUtil util;
	@Autowired
	BulkUploadBPAIntegrator integrator;

	@Autowired
	MailUtil mailUtil;

	public String getTransactionId() {
		// Generate transaction id
		return integrator.generateTransactionId();
	}

	public void invokeBPACreation(BPACreationInputModel bpaCreationInputModel) {
		mailUtil.mailNotification("BU_BPA_PROCESSED");
		String transactionId = bpaCreationInputModel.getTransactionId();
		util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null,
				EVENT_RECEIVE_BULK_UPLOAD_MESSAGE, CREATE);

		// Initialize bulkUploadPayloadModel
		BulkUploadPayloadModel<BPACreationModel, BPACreationResponseModel> bulkUploadPayloadModel = new BulkUploadPayloadModel<>();
		util.initializeBulkUploadPayloadModel(bulkUploadPayloadModel, transactionId);
		bulkUploadPayloadModel.setTranType(CREATE);
		bulkUploadPayloadModel.setFileName(bpaCreationInputModel.getFileName());
		bulkUploadPayloadModel.setUserName(bpaCreationInputModel.getUserName());

		// Respond with transaction id and continue Async processing
		log.info(STATING_ASYNC_METHOD_INVOCATION_PART_FOR_TRANSACTION_ID + transactionId);

		util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bpaCreationInputModel,
				EVENT_RECEIVE_BULK_UPLOAD_MESSAGE, CREATE);

		CompletableFuture
				.supplyAsync(() -> executeBPACreation(bpaCreationInputModel, transactionId, bulkUploadPayloadModel))
				.exceptionally(exception -> {
					log.error("Transaction ID: " + transactionId + " Exception in async call. Exception: "
							+ ExceptionUtils.getStackTrace(exception));
					// Update Payload collection status as failed
					util.updatePayloadCollectionStatus(bulkUploadPayloadModel,
							bpaCreationInputModel.getBpaCreationModels().size());
					return null;
				});
	}

	public ImportOutputModel executeBPACreation(BPACreationInputModel bpaCreationInputModel, String transactionId,
			BulkUploadPayloadModel<BPACreationModel, BPACreationResponseModel> bulkUploadPayloadModel) {
		Integer[] failedInValidationOrPriceRecords = { 0 };

		bpaCreationInputModel.getBpaCreationModels().forEach(bpaCreationModel -> {
			// Remove leading and trailing spaces for varChar fields
			removeLeadingAndTrailingSpaces(bpaCreationModel);
		});

		// Add input records into BulkUploadPayload collection
		bulkUploadPayloadModel.setInputPayload(bpaCreationInputModel.getBpaCreationModels());

		// Initialize bulkUploadErrorModel
		BulkUploadErrorModel<BulkUploadCreationErrorModel> bulkUploadErrorModel = new BulkUploadErrorModel<>();
		util.initializeBulkUploadErrorModel(bulkUploadErrorModel, transactionId);
		Set<String> failedGroupIds = new HashSet<>();

		Set<String> errorGroupIdSet = new HashSet<>();

		Map<String, Map<String, List<BPACreationModel>>> inputMappedByGroupIdAndItem = bpaCreationInputModel
				.getBpaCreationModels().stream()
				.filter(bpaCreationModel -> null != bpaCreationModel.getGroupId() && null != bpaCreationModel.getItem())
				.collect(Collectors.groupingBy(BPACreationModel::getGroupId,
						Collectors.groupingBy(BPACreationModel::getItem)));

		bpaCreationInputModel.getBpaCreationModels().stream()
				.filter(bpaCreationModel -> null == bpaCreationModel.getGroupId()).forEach(bpaCreationModel -> {
					populateCreationErrorModel(bpaCreationModel, GROUP_ID_FIELD_IS_MISSING, bulkUploadErrorModel,
							failedGroupIds);
				});

		Map<String, List<BPACreationModel>> bpaCreationModelGroup = bpaCreationInputModel.getBpaCreationModels()
				.stream().filter(pOCreationModel -> null != pOCreationModel.getGroupId())
				.collect(Collectors.groupingBy(BPACreationModel::getGroupId, Collectors.toList()));

		log.info("Transaction ID: " + bpaCreationInputModel.getTransactionId() + " bpaCreationModelGroup: "
				+ bpaCreationModelGroup);

		bpaCreationModelGroup.forEach((groupId, bpaCreationModelList) -> {
			List<BulkUploadCreationErrorModel> bpaCreationErrorModels = new ArrayList<>();
			Set<String> itemSet = new HashSet<>();

			bpaCreationModelList.forEach(bpaCreationModel -> {

				StringJoiner errorMessage = new StringJoiner(" | ");
				log.info("Transaction ID: " + bpaCreationInputModel.getTransactionId() + " itemSet: " + itemSet
						+ " groupId : " + groupId);
				if (!itemSet.add(bpaCreationModel.getItem()))
					errorMessage.add(DUPLICATE_ITEM_ERROR_FOR_GIVEN_GROUP_ID);

				// common attributes check
				errorMessage
						.merge(validateCommonAttributes(bpaCreationModelList.get(0), bpaCreationModel, transactionId));

				// mandatory parameters check
				errorMessage.merge(validateMandatoryFields(bpaCreationModel, transactionId));
				// field length check
				errorMessage.merge(validateFieldLength(bpaCreationModel, transactionId));

				if (!StringUtils.isEmpty(errorMessage.toString())) {
					// Record failed Group ID for removal
					errorGroupIdSet.add(groupId);
					failedGroupIds.add(groupId);
					log.info(PRE_VALIDATION_CHECK_FAILED_WITH_ERROR_MESSAGE + errorMessage + " for TransactionID : "
							+ transactionId);
				}
				bpaCreationErrorModels.add(BulkUploadCreationErrorModel.builder().errorMessage(errorMessage.toString())
						.inputPayload(bpaCreationModel).build());
			});
			if (errorGroupIdSet.contains(groupId))
				bpaCreationErrorModels.forEach(
						bpaCreationErrorModel -> bulkUploadErrorModel.getErrorPayload().add(bpaCreationErrorModel));
		});
		errorGroupIdSet.forEach(bpaCreationModelGroup::remove);
		Integer failedInPreValidationRecords = bulkUploadErrorModel.getErrorPayload().size();
		if (failedInPreValidationRecords >= 1) {
			util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null,
					EVENT_BULK_UPLOAD_PRE_VALIDATION_NACK, CREATE);
			util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bulkUploadErrorModel,
					EVENT_BULK_UPLOAD_PRE_VALIDATION_NACK, CREATE);
		}
		bulkUploadPayloadModel.getStatusDetails().setFailedInPreValidationRecords(failedInPreValidationRecords);
		// persist the records in corresponding bulkUpload payload/error collection
		if (!bulkUploadPayloadModel.getInputPayload().isEmpty())
			integrator.savePayloadCollection(bulkUploadPayloadModel);
		log.info(BULK_UPLOAD_PAYLOAD_SAVED_TO_MONGODB_FOR_TRANSACTION_ID + transactionId);

		// Update Mongo collection for the given input with current status
		util.updatePayloadCollectionStatusDetails(bulkUploadPayloadModel, STATUS_DETAILS_VALIDATION);
		/*
		 * if (failedInPreValidationRecords >= 1) { util.prismLogger(transactionId,
		 * MessageEventType.END, MessageStatus.SUCCESS, bulkUploadErrorModel,
		 * EVENT_BULK_UPLOAD_PRE_VALIDATION_NACK, CREATE); }
		 */
		// make a validation call
		ValidationModel bulkUploadValidationOutput = null;
		// calling validation service
//		Integer failedInValidationRecords = 0;
		if (!bpaCreationModelGroup.isEmpty())
			try {
				bulkUploadValidationOutput = executeBulkUploadValidation(bpaCreationModelGroup, bpaCreationInputModel,
						transactionId, bulkUploadErrorModel, failedGroupIds);

			} catch (ApiException ex) {
				log.error("Transaction ID: " + bpaCreationInputModel.getTransactionId()
						+ " Api Exception encountered during Validation: " + ex);
				bulkUploadPayloadModel.getInputPayload().stream()
						.filter(errorInputModel -> !failedGroupIds.contains(errorInputModel.getGroupId()))
						.collect(Collectors.toList())
						.forEach(errorInputModel -> populateCreationErrorModel(errorInputModel, ex.getErrorMessage(),
								bulkUploadErrorModel, failedGroupIds));
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.FAILURE, bulkUploadErrorModel,
						EVENT_BULK_UPLOAD_VALIDATION, CREATE);
			} catch (Exception ex) {
				log.error("Transaction ID: " + bpaCreationInputModel.getTransactionId()
						+ " Unexpected Exception encountered during Validation: " + ExceptionUtils.getStackTrace(ex));
				bulkUploadPayloadModel.getInputPayload().stream()
						.filter(errorInputModel -> !failedGroupIds.contains(errorInputModel.getGroupId()))
						.collect(Collectors.toList())
						.forEach(errorInputModel -> populateCreationErrorModel(errorInputModel,
								APPLICATION_ERROR_ENCOUNTERED_DURING_VALIDATION, bulkUploadErrorModel, failedGroupIds));
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.FAILURE, bulkUploadErrorModel,
						EVENT_BULK_UPLOAD_VALIDATION, CREATE);
			}
//		failedInValidationRecords = bulkUploadErrorModel.getErrorPayload().size() - failedInPreValidationRecords;
//		bulkUploadPayloadModel.getStatusDetails().setFailedInValidationRecords(failedInValidationRecords);
//		if (failedInValidationRecords >= 1) {
//			util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bulkUploadErrorModel,
//					EVENT_BULK_UPLOAD_POST_VALIDATION_NACK, CREATE);
//		}
		// calling price service
		if (null != bulkUploadValidationOutput && !bulkUploadValidationOutput.getHeaderModels().isEmpty()) {
			try {
				// Update Mongo collection for the given input with current status
				util.updatePayloadCollectionStatusDetails(bulkUploadPayloadModel, STATUS_DETAILS_PRICE);
				// set bulk upload po validation response
//				Map<String, List<String>> errorGroupIdMap = invokePoPriceService(bulkUploadValidationOutput,
//						transactionId, bpaCreationInputModel, bulkUploadErrorModel, failedGroupIds);
				invokePoPriceService(bulkUploadValidationOutput, transactionId, bpaCreationInputModel,
						bulkUploadErrorModel, failedGroupIds, failedInValidationOrPriceRecords);
				filterValidationOrPriceErrorRecords(bulkUploadValidationOutput, bpaCreationInputModel, transactionId,
						bulkUploadErrorModel, failedGroupIds);
				// log.info("errorGroupIdMap received after price call : " +
				// errorGroupIdMap.toString());
				// Map error group ids to error collection--this map is having price service
				// error records
//				errorGroupIdMap.forEach((errorMessage, errorGroupIDList) -> {
//					List<BPACreationModel> errorInputModels = bulkUploadPayloadModel.getInputPayload().parallelStream()
//							.filter(inputPayload -> errorGroupIDList.contains(inputPayload.getGroupId()))
//							.collect(Collectors.toList());
//
//					errorInputModels.forEach(errorInputModel -> {
//						failedInPricingRecords[0]++;
//						populateCreationErrorModel(errorInputModel, errorMessage, bulkUploadErrorModel, failedGroupIds);
//					});
//				});
			} catch (ApiException ex) {
				log.error("Transaction ID: " + bpaCreationInputModel.getTransactionId()
						+ " Api Exception encountered during Price: " + ex);
				bulkUploadPayloadModel.getInputPayload().stream()
						.filter(errorInputModel -> !failedGroupIds.contains(errorInputModel.getGroupId()))
						.collect(Collectors.toList()).forEach(errorInputModel -> {
							populateCreationErrorModel(errorInputModel, ex.getErrorMessage(), bulkUploadErrorModel,
									failedGroupIds);
						});
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.FAILURE, bulkUploadErrorModel,
						EVENT_FETCH_PO_PRICE, CREATE);
			} catch (Exception ex) {
				log.error("Transaction ID: " + bpaCreationInputModel.getTransactionId()
						+ " Unexpected Exception encountered during Price: " + ExceptionUtils.getStackTrace(ex));
				bulkUploadPayloadModel.getInputPayload().stream()
						.filter(errorInputModel -> !failedGroupIds.contains(errorInputModel.getGroupId()))
						.collect(Collectors.toList()).forEach(errorInputModel -> {
							populateCreationErrorModel(errorInputModel,
									APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST, bulkUploadErrorModel,
									failedGroupIds);
						});
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.FAILURE, bulkUploadErrorModel,
						EVENT_FETCH_PO_PRICE, CREATE);
			}
		}
		failedInValidationOrPriceRecords[0] = bulkUploadErrorModel.getErrorPayload().size()
				- failedInPreValidationRecords;
		bulkUploadPayloadModel.getStatusDetails()
				.setFailedInValidationOrPriceRecords(failedInValidationOrPriceRecords[0]);
		if (failedInValidationOrPriceRecords[0] >= 1) {
			util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null,
					EVENT_BULK_UPLOAD_POST_PRICE_NACK, CREATE);
			util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bulkUploadErrorModel,
					EVENT_BULK_UPLOAD_POST_PRICE_NACK, CREATE);
		}
		// calling import service
		ImportOutputModel importOutputModel = null;
		if (null != bulkUploadValidationOutput && !bulkUploadValidationOutput.getHeaderModels().isEmpty()) {
			// Update Mongo collection for the given input with current status
			util.updatePayloadCollectionStatusDetails(bulkUploadPayloadModel, STATUS_DETAILS_IMPORT);

			// construct header and line model for po import and call import service
			try {
				util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS,
						bulkUploadValidationOutput, EVENT_BULK_UPLOAD_CREATION, CREATE);
				importOutputModel = executePoImportService(bulkUploadValidationOutput, transactionId);
				filterImportErrorRecords(importOutputModel, bpaCreationInputModel, transactionId, bulkUploadErrorModel,
						failedGroupIds);
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, importOutputModel,
						EVENT_BULK_UPLOAD_CREATION, CREATE);
			} catch (ApiException e) {
				log.error("Transaction ID: " + bpaCreationInputModel.getTransactionId()
						+ " Api Exception encountered during Import: " + e);
				bulkUploadPayloadModel.getInputPayload().stream()
						.filter(errorInputModel -> !failedGroupIds.contains(errorInputModel.getGroupId()))
						.collect(Collectors.toList())
						.forEach(errorInputModel -> populateCreationErrorModel(errorInputModel,
								APPLICATION_ERROR_ENCOUNTERED_DURING_IMPORT, bulkUploadErrorModel, failedGroupIds));
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.FAILURE, bulkUploadErrorModel,
						EVENT_BULK_UPLOAD_CREATION, CREATE);
			} catch (Exception ex) {
				log.error("Transaction ID: " + bpaCreationInputModel.getTransactionId()
						+ " Unexpected Exception encountered during Import: " + ExceptionUtils.getStackTrace(ex));
				bulkUploadPayloadModel.getInputPayload().stream()
						.filter(errorInputModel -> !failedGroupIds.contains(errorInputModel.getGroupId()))
						.collect(Collectors.toList())
						.forEach(errorInputModel -> populateCreationErrorModel(errorInputModel,
								APPLICATION_ERROR_ENCOUNTERED_DURING_IMPORT, bulkUploadErrorModel, failedGroupIds));
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.FAILURE, bulkUploadErrorModel,
						EVENT_BULK_UPLOAD_CREATION, CREATE);
			}
			int failedInImportRecords = (bulkUploadErrorModel.getErrorPayload().size()
					- (failedInPreValidationRecords + failedInValidationOrPriceRecords[0]));
			bulkUploadPayloadModel.getStatusDetails().setFailedInImportRecords(failedInImportRecords);

//			log.info("failedInImportRecords :" + failedInImportRecords);
//			log.info(
//					"(bulkUploadErrorModel.getErrorPayload().size() :" + bulkUploadErrorModel.getErrorPayload().size());
//			log.info("failedInValidationRecords :" + failedInValidationRecords);
//			log.info("failedInPreValidationRecords :" + failedInPreValidationRecords);
//			log.info("failedInPricingRecords :" + failedInValidationOrPriceRecords[0]);

			if (failedInImportRecords >= 1) {
				util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null,
						EVENT_BULK_UPLOAD_POST_CREATION_NACK, CREATE);
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bulkUploadErrorModel,
						EVENT_BULK_UPLOAD_POST_CREATION_NACK, CREATE);
			}
		}

		// Setting Response Payload
		if (null != importOutputModel && !importOutputModel.getBulkUploadImportOutput().isEmpty())
			importOutputModel.getBulkUploadImportOutput().forEach(importOutput -> {
				ImportHeaderModel importHeader = importOutput.getBulkUploadImportHeaderModel();
				Map<String, List<BPACreationModel>> inputPayloadForGroupId = inputMappedByGroupIdAndItem
						.get(importHeader.getGroupId());
				if ("S".equals(importHeader.getStatusCode())) {
					importHeader.getLines().forEach(importLine -> {
						List<BPACreationModel> inputPayload = inputPayloadForGroupId.get(importLine.getItem());
						BPACreationResponseModel responsePayload = new BPACreationResponseModel();
						BeanUtils.copyProperties(inputPayload.get(0), responsePayload);
						responsePayload.setPoNumber(importHeader.getPoNumber());
						responsePayload.setStatusCode(importLine.getStatusCode());
						responsePayload.setErrorMessage(importLine.getErrorMessage());
						responsePayload.setAction(importLine.getAction());
						bulkUploadPayloadModel.getResponsePayload().add(responsePayload);
					});
					mailUtil.mailNotification("BPA_CREATED");
				}
			});
		if (!bulkUploadErrorModel.getErrorPayload().isEmpty()) {
			integrator.saveErrorPayloadCollection(bulkUploadErrorModel);
		}
		util.updatePayloadCollectionStatus(bulkUploadPayloadModel, bulkUploadErrorModel.getErrorPayload().size());
		util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, bulkUploadPayloadModel,
				EVENT_RECEIVE_BULK_UPLOAD_MESSAGE, CREATE);
		return importOutputModel;
	}

	private ImportOutputModel executePoImportService(ValidationModel validationOutput, String transactionId) {

		ImportInputModel importInputModel = ImportInputModel.builder().importHeaderModels(new ArrayList<>())
				.transactionId(transactionId).build();
		validationOutput.getHeaderModels().forEach(validationHeader -> {
			ImportHeaderModel importHeaderModel = new ImportHeaderModel();
			List<ImportLineModel> importLineModelList = new ArrayList<>();
			// Populate Header details
			BeanUtils.copyProperties(validationHeader, importHeaderModel);

			validationHeader.getLines().forEach(validationLine -> {
				ImportLineModel importLineModel = new ImportLineModel();
				// Populate Line details
				BeanUtils.copyProperties(validationLine, importLineModel);

				// Populate Shipment details
				importLineModel.setShipments(new ArrayList<>(Arrays.asList(ImportShipmentModel.builder()
						.shipToLocationIdShipping(validationLine.getShipToLocationIdShipping())
						.shipToOrgId(validationLine.getShipToOrgId())
						.subinventoryName(validationLine.getSubInventoryName()).build())));
				importLineModelList.add(importLineModel);
			});
			importHeaderModel.setLines(importLineModelList);
			importInputModel.getImportHeaderModels().add(importHeaderModel);
		});

		return integrator.callbulkUploadImportService(importInputModel);
	}

	private void populateCreationErrorModel(BPACreationModel bpaCreationModel, String errorMessage,
			BulkUploadErrorModel<BulkUploadCreationErrorModel> bulkUploadErrorModel, Set<String> failedGroupIds) {
		BulkUploadCreationErrorModel bulkUploadPOCreationErrorModel = new BulkUploadCreationErrorModel();
		bulkUploadPOCreationErrorModel.setInputPayload(bpaCreationModel);
		bulkUploadPOCreationErrorModel.setErrorMessage(errorMessage);
		bulkUploadErrorModel.getErrorPayload().add(bulkUploadPOCreationErrorModel);
		failedGroupIds.add(bpaCreationModel.getGroupId());
	}

	private ValidationModel executeBulkUploadValidation(Map<String, List<BPACreationModel>> bpaCreationModelGroup,
			BPACreationInputModel bpaCreationInputModel, String transactionId,
			BulkUploadErrorModel<BulkUploadCreationErrorModel> bulkUploadErrorModel, Set<String> failedGroupIds) {

		util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, bpaCreationModelGroup,
				EVENT_BULK_UPLOAD_VALIDATION, CREATE);
		// converting into header and line model for validation this will have list of
		// headers
		ValidationModel bulkUploadValidationModel = new ValidationModel();
		bulkUploadValidationModel.setTransactionId(transactionId);
		bulkUploadValidationModel.setHeaderModels(new ArrayList<>());

		bpaCreationModelGroup.forEach((groupId, bpaCreationModels) -> {
			// Create Validation Header
			BPACreationModel bpaCreationHeaderModel = bpaCreationModels.get(0);

			ValidationHeaderModel validationHeaderModel = ValidationHeaderModel.builder().poTypeLookUpCode(BLANKET)
					.action(CREATE).styleName(bpaCreationHeaderModel.getStyleName())
					.groupId(bpaCreationHeaderModel.getGroupId())
					.operatingUnit(bpaCreationHeaderModel.getOperatingUnit())
//					.inventoryOrgCode(bpaCreationHeaderModel.getInventoryOrg())
					.vendor(bpaCreationHeaderModel.getSupplier()).vendorLoc(bpaCreationHeaderModel.getSupplierSite())
					// .shipToLocation(bpaCreationHeaderModel.getShipTo())
					.billToLocation(bpaCreationHeaderModel.getBillTo()).buyerId(bpaCreationInputModel.getBuyerId())
					.applicationUser(bpaCreationInputModel.getUserName())
					.comments(bpaCreationHeaderModel.getDescription())
					.trnsMethod(bpaCreationHeaderModel.getTransMethod())
					.freightCarrier(bpaCreationHeaderModel.getFreightCarrier())
					.delTerms(bpaCreationHeaderModel.getDeliveryTerms()).clauses(bpaCreationHeaderModel.getClauses())
					.vmiDirect(bpaCreationHeaderModel.getVmiDirect())
					// .IccSlcLocation(bpaCreationHeaderModel.getIccSlcLocation())
					.attachmentFileName(StringUtils.isEmpty(bpaCreationHeaderModel.getAttachment()) ? null
							: transactionId + "_" + bpaCreationHeaderModel.getAttachment())
					.poSite(bpaCreationHeaderModel.getPoSite())
					.defaultShipToLocation(bpaCreationHeaderModel.getDefaultShipToLocation()).lines(new ArrayList<>())
					.build();
			util.populateDefaultValues(validationHeaderModel);

			// Create Validation Lines
			bpaCreationModels.forEach(poCreationModel -> {

				// Create Validation Lines
				ValidationLineModel validationLineModel = ValidationLineModel.builder().action(ADD)
						.item(poCreationModel.getItem()).quantity(poCreationModel.getQuantity())
						.unitPrice(poCreationModel.getPrice()).costType(poCreationModel.getCostType())
						.lastTimeBuy(poCreationModel.getLastTimeBuy()).lineComments(poCreationModel.getLineComments())
						.internalComments(poCreationModel.getInternalComments())
						.reasonCode(poCreationModel.getReasonCode())
						.allowPriceOverride(poCreationModel.getAllowPriceOverride()).build();

				if ("MX-MX_BSE_USD_OU".equalsIgnoreCase(poCreationModel.getOperatingUnit())) {
					validationLineModel.setAllowPriceOverride("Y");
				}

				util.populateDefaultValues(validationLineModel);
				validationHeaderModel.getLines().add(validationLineModel);
			});
			bulkUploadValidationModel.getHeaderModels().add(validationHeaderModel);
		});

		// call bulk upload po validation service
		ValidationModel validationResponse = null;
		if (!bulkUploadValidationModel.getHeaderModels().isEmpty()) {
			log.info("Transaction ID: " + bpaCreationInputModel.getTransactionId() + " bulkUploadValidationModel: "
					+ bulkUploadValidationModel);
			validationResponse = integrator.callbulkUploadValidationService(bulkUploadValidationModel);

		}
		util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, validationResponse,
				EVENT_BULK_UPLOAD_VALIDATION, CREATE);
		if (null == validationResponse) {
			throw new ApiException(APPLICATION_ERROR_ENCOUNTERED_DURING_VALIDATION);
		}
		return validationResponse;
	}

	private void filterValidationOrPriceErrorRecords(ValidationModel validationResponse,
			BPACreationInputModel bpaCreationInputModel, String transactionId,
			BulkUploadErrorModel<BulkUploadCreationErrorModel> bulkUploadErrorModel, Set<String> failedGroupIds) {
		List<ValidationHeaderModel> invalidRecordList = new ArrayList<>();
		if (!validationResponse.getStatusCode().equals("SUCCESS")) {
			if (StringUtils.isEmpty(validationResponse.getErrorMessage()))
				validationResponse.getHeaderModels().forEach(validationHeaderResponse -> {
					if (!validationHeaderResponse.getStatusCode().equals("S")) {
						invalidRecordList.add(validationHeaderResponse);
						Map<String, String> lineErrorMap = new HashMap<>();
						validationHeaderResponse.getLines().forEach(validationLineResponse -> {
							if (!validationLineResponse.getStatusCode().equals("S")) {
								// If already error records exist with same error message, then add to that list
								// else create new entry
								lineErrorMap.put(validationLineResponse.getItem(),
										validationLineResponse.getErrorMessage());
							}
						});
						List<BPACreationModel> bpaCreationModels = bpaCreationInputModel
								.getBpaCreationModels().stream().filter(poCreationModel -> validationHeaderResponse
										.getGroupId().equals(poCreationModel.getGroupId()))
								.collect(Collectors.toList());
						String[] headerErrorMessage = { null };
						if (!StringUtils.isEmpty(validationHeaderResponse.getErrorMessage())) {
							headerErrorMessage[0] = validationHeaderResponse.getErrorMessage()
									.replaceAll(ERROR_IN_UNDERLYING_LINES, "");
						}
						bpaCreationModels.forEach(bpaCreationModel -> {
							String lineErrorMessage = lineErrorMap.get(bpaCreationModel.getItem());
							if (StringUtils.isBlank(headerErrorMessage[0]))
								populateCreationErrorModel(bpaCreationModel, lineErrorMessage, bulkUploadErrorModel,
										failedGroupIds);
							else if (StringUtils.isBlank(lineErrorMessage))
								populateCreationErrorModel(bpaCreationModel, headerErrorMessage[0],
										bulkUploadErrorModel, failedGroupIds);
							else
								populateCreationErrorModel(bpaCreationModel,
										headerErrorMessage[0] + ERROR_MESSAGE_DELIMITER + lineErrorMessage,
										bulkUploadErrorModel, failedGroupIds);
						});
					}
				});
			else
				throw new ApiException(APPLICATION_ERROR_ENCOUNTERED_DURING_VALIDATION);
			validationResponse.getHeaderModels().removeAll(invalidRecordList);
			if (!invalidRecordList.isEmpty()) {
				util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null,
						EVENT_BULK_UPLOAD_POST_VALIDATION_NACK, CREATE);
				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, invalidRecordList,
						EVENT_BULK_UPLOAD_POST_VALIDATION_NACK, CREATE);
			}
		}
	}

	private void filterImportErrorRecords(ImportOutputModel importOutputModel,
			BPACreationInputModel bpaCreationInputModel, String transactionId,
			BulkUploadErrorModel<BulkUploadCreationErrorModel> bulkUploadErrorModel, Set<String> failedGroupIds) {
		if (null == importOutputModel) {
			throw new ApiException(APPLICATION_ERROR_ENCOUNTERED_DURING_IMPORT);
		} else {
			List<ImportEBSOutputModel> invalidRecordList = new ArrayList<>();
			importOutputModel.getBulkUploadImportOutput().forEach(importoutputResponse -> {
				List<BPACreationModel> bpaCreationModels = bpaCreationInputModel
						.getBpaCreationModels().stream().filter(poCreationModel -> importoutputResponse
								.getBulkUploadImportHeaderModel().getGroupId().equals(poCreationModel.getGroupId()))
						.collect(Collectors.toList());

				if (!importoutputResponse.getStatusCode().equals("SUCCESS")) {
					if (StringUtils.isEmpty(importoutputResponse.getErrorMessage()))
						if (!importoutputResponse.getStatusCode().equals("S")) {
							invalidRecordList.add(importoutputResponse);
							Map<String, String> lineErrorMap = new HashMap<>();
							importoutputResponse.getBulkUploadImportHeaderModel().getLines()
									.forEach(importLineResponse -> {
										if (!importLineResponse.getStatusCode().equals("S")) {
											// If already error records exist with same error message, then add to that
											// list else create new entry
											lineErrorMap.put(importLineResponse.getItem(),
													importLineResponse.getErrorMessage());
										}
									});
							String[] headerErrorMessage = { null };
							if (!StringUtils.isEmpty(importoutputResponse.getErrorMessage())) {
								headerErrorMessage[0] = importoutputResponse.getErrorMessage()
										.replaceAll(ERROR_IN_UNDERLYING_LINES, "");
							}
							bpaCreationModels.forEach(bpaCreationModel -> {
								String lineErrorMessage = lineErrorMap.get(bpaCreationModel.getItem());
								if (StringUtils.isBlank(headerErrorMessage[0]))
									populateCreationErrorModel(bpaCreationModel, lineErrorMessage, bulkUploadErrorModel,
											failedGroupIds);
								else if (StringUtils.isBlank(lineErrorMessage))
									populateCreationErrorModel(bpaCreationModel, headerErrorMessage[0],
											bulkUploadErrorModel, failedGroupIds);
								else
									populateCreationErrorModel(bpaCreationModel,
											headerErrorMessage[0] + ERROR_MESSAGE_DELIMITER + lineErrorMessage,
											bulkUploadErrorModel, failedGroupIds);

							});
						} else
							throw new ApiException(APPLICATION_ERROR_ENCOUNTERED_DURING_IMPORT);
				}
			});
			importOutputModel.getBulkUploadImportOutput().removeAll(invalidRecordList);
			if (!invalidRecordList.isEmpty()) {
				util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, invalidRecordList,
						EVENT_BULK_UPLOAD_POST_CREATION_NACK, CREATE);
			}
		}
	}

	public void invokePoPriceService(ValidationModel poValidationOutput, String transactionId,
			BPACreationInputModel bpaCreationInputModel,
			BulkUploadErrorModel<BulkUploadCreationErrorModel> bulkUploadErrorModel, Set<String> failedGroupIds,
			Integer[] failedInPricingRecords) {
		util.prismLogger(transactionId, MessageEventType.START, MessageStatus.SUCCESS, null, EVENT_FETCH_PO_PRICE,
				CREATE);
		BulkUploadPriceModel bulkUploadPriceModel = util.initializeBulkUploadPriceModel(transactionId);
//		Map<String, String> errorGroupIdMap = new HashMap<>();
//		Map<String, String> lineErrorMap = new HashMap<>();
//		String[] headerErrorMessage = { null };
//
//		List<ValidationHeaderModel> invalidValidationHeaderModels = new ArrayList<>();
		poValidationOutput.getHeaderModels().forEach(validationHeader -> {
			try {
				Double[] totalBPOCost = { 0.0 };
				Double[] bpaAgreedQty = { 0.0 };
				PriceHeaderModel priceHeaderModel = PriceHeaderModel.builder().build();
				priceHeaderModel.setToLocation(validationHeader.getPoSite());
				priceHeaderModel.setToLocationCcn(validationHeader.getPoSiteCCN());
				priceHeaderModel.setPoType(validationHeader.getPoType());
				priceHeaderModel.setPoSubType(validationHeader.getPoSubType());
				priceHeaderModel.setOdmPoType(validationHeader.getOdmPoType());
				priceHeaderModel.setVendorCcn(validationHeader.getVendorCCN());
				priceHeaderModel.setVendor(validationHeader.getVendor());
				priceHeaderModel.setVendorLocation(validationHeader.getVendorLoc());
				priceHeaderModel.setPartDetails(new ArrayList<>());
				validationHeader.getLines().forEach(validationLines -> {
					// if (null == validationLines.getUnitPrice()) {
					priceHeaderModel.getPartDetails()
							.add(PricePartDetailsModel.builder().partNumber(validationLines.getItem())
									.effectiveDate(DateStringUtil.getStringFromDate(new Date())).build());
					// }
				});

				if (!priceHeaderModel.getPartDetails().isEmpty()) {

					// Check if mandatory PO Cost attributes are populated
					if (StringUtils.isEmpty(priceHeaderModel.getPoType())
							|| StringUtils.isEmpty(priceHeaderModel.getPoSubType())
					// mandatory only when posubtype is ODMF
					// only for information
					// Sell, System, ODM Buy
							|| StringUtils.isEmpty(priceHeaderModel.getToLocation())
							|| StringUtils.isEmpty(priceHeaderModel.getToLocationCcn())
							|| StringUtils.isEmpty(priceHeaderModel.getVendorCcn())) {
//						invalidValidationHeaderModels.add(validationHeader);
//						headerErrorMessage[0] = ERROR_MANDATORY_PO_COST_ATTRIBUTES_MISSING;
						util.markPriceHeaderError(poValidationOutput, validationHeader,
								ERROR_MANDATORY_PO_COST_ATTRIBUTES_MISSING);
					} else {
						PriceHeaderModel priceOutput = null;
						bulkUploadPriceModel.getInputPayload().add(priceHeaderModel);
						priceOutput = integrator.fetchPOPrice(priceHeaderModel, transactionId);
						bulkUploadPriceModel.getResponsePayload().add(priceOutput);

						if (priceOutput != null && priceOutput.getPartDetails() != null) {
							if (priceOutput != null && priceOutput.getMessage() != null) {
								log.info("Message received from PO Price Service " + priceOutput.getMessage()
										+ " for transactionId :" + transactionId);
								util.markPriceHeaderError(poValidationOutput, validationHeader,
										priceOutput.getMessage());
								// errorGroupIdMap.put(priceOutput.getMessage(), new ArrayList<>());
//								invalidValidationHeaderModels.add(validationHeader);
								// errorGroupIdMap.get(priceOutput.getMessage()).add(validationHeader.getGroupId());
//								headerErrorMessage[0] = priceOutput.getMessage();

							} else {
								priceOutput.getPartDetails().forEach(partDetails -> {
									validationHeader.getLines().forEach(validationLine -> {
										Integer i = 0;
										if (validationLine.getItem().equals(partDetails.getPartNumber())) {
											// Set List price as the price returned from One Cost
											validationLine.setListPrice(partDetails.getPrice());

											// Scenario 1 : User entered Unit price in excel
											if (validationLine.getUnitPrice() != null) {
												// If the User entered price is same as One cost, use the cost type
												// returned from One Cost, i.e., Buy (B) else it will be Manual (MN)
												if (validationLine.getUnitPrice().equals(partDetails.getPrice())) {
													validationLine.setCostType(partDetails.getCostType());
												} else {
													validationLine.setCostType(COST_TYPE_MANUAL);
													if (StringUtils.isEmpty(validationHeader.getAttachmentFileName())) {
														log.error("Transaction ID: " + transactionId + " "
																+ ERROR_COST_TYPE_MN_ATTACHMENT_MANDATORY);
														util.markPriceLineError(poValidationOutput, validationHeader,
																validationLine,
																ERROR_COST_TYPE_MN_ATTACHMENT_MANDATORY);
													}
												}
											}
											// Scenario 2 : User did not enter Unit price in excel
											if (validationLine.getUnitPrice() == null) {
												validationLine.setUnitPrice(partDetails.getPrice());
												validationLine.setCostType(partDetails.getCostType());
												log.info("scenarion 2 :" + validationLine.getCostType());
												log.info("scenarion 2 :" + validationLine.getUnitPrice());
											}
											if (validationLine.getUnitPrice() == null
													|| validationLine.getUnitPrice() <= 0) {
												if (StringUtils.isNotBlank(partDetails.getValidationMessage())) {
													log.info("Transaction ID: " + transactionId
															+ " Validation Message received from PO Price Service: "
															+ partDetails.getValidationMessage());
													util.markPriceLineError(poValidationOutput, validationHeader,
															validationLine, partDetails.getValidationMessage());
												} else {
													log.error("Transaction ID: " + transactionId + " "
															+ INVALID_PRICE_RETURN_FROM_PRICE_SERVICE
															+ " Price returned: " + partDetails.getPrice()
															+ " Validation message: "
															+ partDetails.getValidationMessage());
													util.markPriceLineError(poValidationOutput, validationHeader,
															validationLine, INVALID_PRICE_RETURN_FROM_PRICE_SERVICE);
												}
											} else {
												if (null != validationLine.getQuantity()) {
													totalBPOCost[0] += validationLine.getUnitPrice()
															* validationLine.getQuantity().doubleValue();
												} else {
													bpaAgreedQty[0] += 1;
												}
											}
										}
									});
								});
							}
						}
					}

					if (bpaAgreedQty[0] > 0.0) {
						totalBPOCost[0] = 0.0;
					}
					// if totalPOCost> po amount limit and cost type is not MN, attachment is
					// necessary
					if (totalBPOCost[0] >= validationHeader.getPoAmountLimit()
							&& StringUtils.isEmpty(validationHeader.getAttachmentFileName())) {

						log.error("Transaction ID: " + transactionId + " "
								+ ERROR_TOTAL_COST_MORE_THAN_DEFINED_LIMIT_ATTACHMENT_MANDATORY + "BPO Amount Limit: "
								+ validationHeader.getPoAmountLimit() + " BPO Total: " + totalBPOCost[0]);
						util.markPriceHeaderError(poValidationOutput, validationHeader,
								ERROR_TOTAL_COST_MORE_THAN_DEFINED_LIMIT_ATTACHMENT_MANDATORY
										+ validationHeader.getPoAmountLimit() + " USD.");
					}
				}

			} catch (Exception e) {
				log.error(APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST, e);
				util.markPriceHeaderError(poValidationOutput, validationHeader,
						APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST);
//				invalidValidationHeaderModels.add(validationHeader);
//				bpaCreationInputModel.getBpaCreationModels().stream()
//						.filter(poCreationModel -> validationHeader.getGroupId().equals(poCreationModel.getGroupId()))
//						.collect(Collectors.toList()).forEach(errorInputModel -> {
//							populateCreationErrorModel(errorInputModel,
//									APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST, bulkUploadErrorModel,
//									failedGroupIds);
//							failedInPricingRecords[0]++;
//						});

				util.prismLogger(transactionId, MessageEventType.END, MessageStatus.FAILURE,
						APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST, EVENT_FETCH_PO_PRICE, CREATE);
			}
		});
		util.prismLogger(transactionId, MessageEventType.END, MessageStatus.SUCCESS, poValidationOutput,
				EVENT_FETCH_PO_PRICE, CREATE);
		integrator.savePricePayloadCollection(bulkUploadPriceModel);
//		poValidationOutput.getHeaderModels().removeAll(invalidValidationHeaderModels);
		// return errorGroupIdMap;
	}

	private StringJoiner validateCommonAttributes(BPACreationModel bpaCreationHeaderModel,
			BPACreationModel poCreationModel, String transactionId) {

		log.info(VALIDATE_COMMON_ATTRIBUTES_CALLED_FOR_TRANSACTION_ID + transactionId);

		StringJoiner errorMessage = new StringJoiner(" | ");
		if (!bpaCreationHeaderModel.equals(poCreationModel))
			errorMessage.add(HEADER_DATA_MISMATCH_FOR_GIVEN_GROUP_ID);
		if (!StringUtils.equals(bpaCreationHeaderModel.getInventoryOrg(), poCreationModel.getInventoryOrg()))
			errorMessage.add(INVENTORY_ORG_CODE_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_GROUP_ID);
		if (!StringUtils.equals(bpaCreationHeaderModel.getVmiDirect(), poCreationModel.getVmiDirect()))
			errorMessage.add(VMI_DIRECT_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_GROUP_ID);
		return errorMessage;
	}

	private void populateDefaultValues(BPACreationModel bpaCreationModel, String transactionId) {

		log.info("PopulateDefaultValues Called for transactionId :" + transactionId);

		// Convert OperatingUnit to Upper Case
		bpaCreationModel.setOperatingUnit(bpaCreationModel.getOperatingUnit().toUpperCase());

		// CostType : Set to MN if UNIT_PRICE is NOT NULL from UI
//		if (null != bpaCreationModel.getPrice())
//			bpaCreationModel.setCostType(COST_TYPE_MANUAL);

		// LastTimeBuy : If NULL then N. Can be Y or N
		if (StringUtils.isEmpty(bpaCreationModel.getLastTimeBuy()))
			bpaCreationModel.setLastTimeBuy(BOOLEAN_N);
		else if (bpaCreationModel.getLastTimeBuy().equalsIgnoreCase(BOOLEAN_YES)
				|| bpaCreationModel.getLastTimeBuy().equalsIgnoreCase(BOOLEAN_Y))
			bpaCreationModel.setLastTimeBuy(BOOLEAN_Y);
		else if (bpaCreationModel.getLastTimeBuy().equalsIgnoreCase(BOOLEAN_NO)
				|| bpaCreationModel.getLastTimeBuy().equalsIgnoreCase(BOOLEAN_N))
			bpaCreationModel.setLastTimeBuy(BOOLEAN_N);
		else
			throw new ApiException(INVALID_VALUE_FOR_LAST_TIME_BUY);

		// Allow Price Override : If NULL then Y. Can be Y or N
		if (StringUtils.isEmpty(bpaCreationModel.getAllowPriceOverride()))
			bpaCreationModel.setAllowPriceOverride(BOOLEAN_Y);
		else if (bpaCreationModel.getAllowPriceOverride().equalsIgnoreCase(BOOLEAN_YES)
				|| bpaCreationModel.getAllowPriceOverride().equalsIgnoreCase(BOOLEAN_Y))
			bpaCreationModel.setAllowPriceOverride(BOOLEAN_Y);
		else if (bpaCreationModel.getAllowPriceOverride().equalsIgnoreCase(BOOLEAN_NO)
				|| bpaCreationModel.getAllowPriceOverride().equalsIgnoreCase(BOOLEAN_N))
			bpaCreationModel.setAllowPriceOverride(BOOLEAN_N);
		else
			throw new ApiException(INVALID_VALUE_FOR_ALLOW_PRICE_OVERRIDE);
	}

	private StringJoiner validateMandatoryFields(BPACreationModel bpaCreationModel, String transactionId) {

		log.info("ValidateMandatoryFields Called for transactionId :" + transactionId);

		StringJoiner errorMessage = new StringJoiner(" | ");

		if (StringUtils.isEmpty(bpaCreationModel.getGroupId())) {
			errorMessage.add(GROUP_ID_FIELD_IS_MISSING);
		}
		if (StringUtils.isEmpty(bpaCreationModel.getOperatingUnit())) {
			errorMessage.add(OPERATING_UNIT_FIELD_IS_MISSING);
		}
		if (StringUtils.isEmpty(bpaCreationModel.getStyleName())) {
			errorMessage.add(STYLE_NAME_FIELD_IS_MISSING);
		}
		if (StringUtils.isEmpty(bpaCreationModel.getSupplier())) {
			errorMessage.add(SUPPLIER_FIELD_IS_MISSING);
		}
		if (StringUtils.isEmpty(bpaCreationModel.getSupplierSite())) {
			errorMessage.add(SITE_FIELD_IS_MISSING);
		}
		if (StringUtils.isEmpty(bpaCreationModel.getItem())) {
			errorMessage.add(ITEM_FIELD_IS_MISSING);
		}
		if (null == bpaCreationModel.getVmiDirect()) {
			errorMessage.add(BPA_TYPE_FIELD_IS_MISSING);
		}
		/*
		 * if (StringUtils.isEmpty(bpaCreationModel.getInventoryOrg())) {
		 * errorMessage.add(INVENTORY_ORG_FIELD_IS_MISSING); }
		 */
		if (StringUtils.isEmpty(bpaCreationModel.getPoSite())) {
			errorMessage.add(PO_SITE_FIELD_IS_MISSING);
		}
		if (StringUtils.isEmpty(bpaCreationModel.getDefaultShipToLocation())) {
			errorMessage.add(DEFAULT_SHIP_TO_LOCATION_FIELD_IS_MISSING);
		}
		// Price : If Price is entered Reason Code is mandatory
		if (null != bpaCreationModel.getPrice() && StringUtils.isEmpty(bpaCreationModel.getReasonCode())) {
			errorMessage.add(REASON_CODE_IS_MANDATORY_WHEN_PRICE_IS_ENTERED);
		}
		// Reason Code : If 40 then Internal Comments cannot be NULL
		if ("40".equals(bpaCreationModel.getReasonCode())
				&& StringUtils.isEmpty(bpaCreationModel.getInternalComments())) {
			errorMessage.add(INTERNAL_COMMENTS_IS_MANDATORY_WHEN_REASON_CODE_IS_40);
		}
		// LastTimeBuy : If Y then Quantity cannot be NULL
		if ((null != bpaCreationModel.getLastTimeBuy() && bpaCreationModel.getLastTimeBuy().equalsIgnoreCase(BOOLEAN_Y))
				&& null == bpaCreationModel.getQuantity()) {
			errorMessage.add(QUANTITY_IS_MANDATORY_WHEN_LAST_TIME_BUY_IS_Y);
		}

		if (StringUtils.isNotEmpty(bpaCreationModel.getAllowPriceOverride())
				&& !(BOOLEAN_N.equals(bpaCreationModel.getAllowPriceOverride())
						|| BOOLEAN_Y.equals(bpaCreationModel.getAllowPriceOverride())))
			errorMessage.add(INVALID_VALUE_FOR_ALLOW_PRICE_OVERRIDE);

		if (StringUtils.isNotEmpty(bpaCreationModel.getLastTimeBuy())
				&& !(BOOLEAN_N.equals(bpaCreationModel.getLastTimeBuy())
						|| BOOLEAN_Y.equals(bpaCreationModel.getLastTimeBuy())))
			errorMessage.add(INVALID_VALUE_FOR_LAST_TIME_BUY);
		// DEFECT - 9481089

		// AllowPriceOverride : If Y then Reason Code cannot be NULL
		/*
		 * if ((null != bpaCreationModel.getAllowPriceOverride() &&
		 * bpaCreationModel.getAllowPriceOverride().equalsIgnoreCase(BOOLEAN_N)) && null
		 * == bpaCreationModel.getReasonCode()) {
		 * errorMessage.add(REASON_CODE_IS_MANDATORY_WHEN_ALLOW_PRICE_OVERRIDE_IS_N); }
		 */

		return errorMessage;
	}

	private StringJoiner validateFieldLength(BPACreationModel bpaCreationModel, String transactionId) {

		log.info(VALIDATE_FIELD_LENGTH_CALLED_FOR_TRANSACTION_ID + transactionId);

		StringJoiner errorMessage = new StringJoiner(" | ");

		if (StringUtils.length(bpaCreationModel.getStyleName()) > 240) {
			errorMessage.add(INVALID_STYLE_NAME_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getGroupId()) > 10) {
			errorMessage.add(INVALID_GROUP_ID_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getOperatingUnit()) > 240) {
			errorMessage.add(INVALID_OPERATING_UNIT_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getSupplier()) > 30) {
			errorMessage.add(INVALID_SUPPLIER_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getSupplierSite()) > 30) {
			errorMessage.add(INVALID_SITE_LENGTH);
		}
		/*
		 * if (StringUtils.length(bpaCreationModel.getShipTo()) > 60) {
		 * errorMessage.add(INVALID_SHIP_TO_LENGTH); }
		 */
		if (StringUtils.length(bpaCreationModel.getBillTo()) > 60) {
			errorMessage.add(INVALID_BILL_TO_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getDescription()) > 240) {
			errorMessage.add(INVALID_DESCRIPTION_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getTransMethod()) > 25) {
			errorMessage.add(INVALID_TRANS_METHOD_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getFreightCarrier()) > 25) {
			errorMessage.add(INVALID_SHIP_VIA_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getDeliveryTerms()) > 25) {
			errorMessage.add(INVALID_FREIGHT_TERMS_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getClauses()) > 150) {
			errorMessage.add(INVALID_CLAUSES_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getAttachment()) > 100) {
			errorMessage.add(INVALID_ATTACHMENT_FILE_NAME_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getItem()) > 1000) {
			errorMessage.add(INVALID_ITEM_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getLastTimeBuy()) > 150) {
			errorMessage.add(INVALID_LAST_TIME_BUY_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getLineComments()) > 1000) {
			errorMessage.add(INVALID_LINE_COMMENTS_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getInternalComments()) > 480) {
			errorMessage.add(INVALID_INTERNAL_COMMENTS_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getReasonCode()) > 10) {
			errorMessage.add(INVALID_REASON_CODE_LENGTH);
		}
		/*
		 * if (StringUtils.length(bpaCreationModel.getInventoryOrg()) > 150) {
		 * errorMessage.add(INVALID_INVENTORY_ORG_LENGTH); }
		 */
		if (StringUtils.length(bpaCreationModel.getAllowPriceOverride()) > 150) {
			errorMessage.add(INVALID_ALLOW_PRICE_OVERRIDE_LENGTH);
		}
		if (StringUtils.length(bpaCreationModel.getVmiDirect()) > 150) {
			errorMessage.add(INVALID_BPA_TYPE_LENGTH);
		}
		/*
		 * if (StringUtils.length(bpaCreationModel.getIccSlcLocation()) > 150) {
		 * errorMessage.add(INVALID_ICC_SLC_LOCATION_LENGTH); }
		 */

		if (StringUtils.length(bpaCreationModel.getPoSite()) > 30) {
			errorMessage.add(INVALID_PO_SITE_LENGTH);
		}

		if (StringUtils.length(bpaCreationModel.getDefaultShipToLocation()) > 60) {
			errorMessage.add(INVALID_DEFAULT_SHIP_TO_LOCATION_LENGTH);
		}
		return errorMessage;
	}

	private void removeLeadingAndTrailingSpaces(BPACreationModel bpaCreationModel) {

		bpaCreationModel.setStyleName(StringUtils.trim(bpaCreationModel.getStyleName()));
		bpaCreationModel.setOperatingUnit(StringUtils.trim(bpaCreationModel.getOperatingUnit()));
		bpaCreationModel.setSupplier(StringUtils.trim(bpaCreationModel.getSupplier()));
		bpaCreationModel.setSupplierSite(StringUtils.trim(bpaCreationModel.getSupplierSite()));
		// bpaCreationModel.setShipTo(StringUtils.trim(bpaCreationModel.getShipTo()));
		bpaCreationModel.setBillTo(StringUtils.trim(bpaCreationModel.getBillTo()));
		bpaCreationModel.setDescription(StringUtils.trim(bpaCreationModel.getDescription()));
		bpaCreationModel.setTransMethod(StringUtils.trim(bpaCreationModel.getTransMethod()));
		bpaCreationModel.setFreightCarrier(StringUtils.trim(bpaCreationModel.getFreightCarrier()));
		bpaCreationModel.setClauses(StringUtils.trim(bpaCreationModel.getClauses()));
		bpaCreationModel.setAttachment(StringUtils.trim(bpaCreationModel.getAttachment()));
		bpaCreationModel.setItem(StringUtils.trim(bpaCreationModel.getItem()));
		bpaCreationModel.setLastTimeBuy(StringUtils.trim(bpaCreationModel.getLastTimeBuy()));
		bpaCreationModel.setLineComments(StringUtils.trim(bpaCreationModel.getLineComments()));
		bpaCreationModel.setInternalComments(StringUtils.trim(bpaCreationModel.getInternalComments()));
		bpaCreationModel.setReasonCode(StringUtils.trim(bpaCreationModel.getReasonCode()));
		// bpaCreationModel.setInventoryOrg(StringUtils.trim(bpaCreationModel.getInventoryOrg()));
		bpaCreationModel.setAllowPriceOverride(StringUtils.trim(bpaCreationModel.getAllowPriceOverride()));
		bpaCreationModel.setVmiDirect(StringUtils.trim(bpaCreationModel.getVmiDirect()));
		bpaCreationModel.setDeliveryTerms(StringUtils.trim(bpaCreationModel.getDeliveryTerms()));
		bpaCreationModel.setDefaultShipToLocation(StringUtils.trim(bpaCreationModel.getDefaultShipToLocation()));
		bpaCreationModel.setPoSite(StringUtils.trim(bpaCreationModel.getPoSite()));
	}
}