package com.dell.prism.eagle.bulkuploadbpa.handler.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportInputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportOutputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.PriceHeaderModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationModel;

@FeignClient(name = "spring-cloud-gateway-procurement", url = "${cloud.gateway.service.url:localhost:8080}")
public interface BulkUploadBPAProxy {

	@PostMapping(("${bulkupload.validation.url}"))
	public ValidationModel callbulkUploadValidationService(@RequestHeader("Authorization") String authHeader,
			@RequestHeader("x-dell-dais-sa-subscriber-id") String clientId,
			@RequestBody ValidationModel bulkUploadValidationModel);

	@PostMapping("${po.price.url}")
	public PriceHeaderModel fetchPOPrice(@RequestHeader("Authorization") String authHeader,
			@RequestHeader("x-dell-dais-sa-subscriber-id") String clientId,
			@RequestBody PriceHeaderModel priceHeaderModel, @RequestParam("eventId") String transactionID);

	@PostMapping("${bulkupload.import.url}")
	public ImportOutputModel callbulkUploadImportService(@RequestHeader("Authorization") String authHeader,
			@RequestHeader("x-dell-dais-sa-subscriber-id") String clientId,
			@RequestBody ImportInputModel importInputModel);
}