package com.dell.prism.eagle.bulkuploadbpa.handler.constant;

public class BulkUploadBPAConstant {

	private BulkUploadBPAConstant() {
	}

	public static final String BULK_UPLOAD_TRANSACTION_ID_SEQUENCE = "bulkUploadTransactionID";
	public static final String COLLECTION_SEQUENCE = "prcSequence";
	public static final String TRANSACTION_ID_SEQUENCE_PREFIX = "TX";

	public static final String COLLECTION_BULK_UPLOAD_PAYLOAD = "prcBulkUploadPayloadXxipo039";
	public static final String COLLECTION_BULK_UPLOAD_VALIDATION = "prcBulkUploadValidationXxipo039";
	public static final String COLLECTION_BULK_UPLOAD_PRICE = "prcBulkUploadPriceXxipo039";
	public static final String COLLECTION_BULK_UPLOAD_IMPORT = "prcBulkUploadImportXxipo040";
	public static final String COLLECTION_BULK_UPLOAD_ERROR = "prcBulkUploadErrorXxipo040";
	public static final String BULKUPLOAD_PO_CREATION_URI = "/bulkupload/pocreation";
	public static final String BULKUPLOAD_BPA_CREATE_URI = "/api/bulkupload/createBPA";
	public static final String BULKUPLOAD_BPA_UPDATE_URI = "/api/bulkupload/updateBPA";
	public static final String BULKUPLOAD_GET_TRANSACTION_ID_URI = "/api/bulkupload/getBPATransactionId";

	public static final String BOOLEAN_YES = "YES";
	public static final String BOOLEAN_NO = "NO";
	public static final String BOOLEAN_Y = "Y";
	public static final String BOOLEAN_N = "N";
	public static final String A = "A";
	public static final String U = "U";
	public static final String ERROR_MESSAGE_DELIMITER = " | ";
	public static final String COST_TYPE_MANUAL = "MN";

	public static final String BLANKET_PURCHASE_ORDER = "Blanket Purchase Order";
	public static final String CREATE = "CREATE";
	public static final String UPDATE = "UPDATE";
	public static final String ADD = "ADD";
	public static final String BLANKET = "BLANKET";

	public static final String ERROR_MANDATORY_PO_COST_ATTRIBUTES_MISSING = "Mandatory PO Cost Attributes are missing";

	// Status Details
	public static final String STATUS_DETAILS_PRE_VALIDATION = "PRE-VALIDATION";
	public static final String STATUS_DETAILS_VALIDATION = "VALIDATION";
	public static final String STATUS_DETAILS_IMPORT = "IMPORT";
	public static final String STATUS_DETAILS_PRICE = "PRICE";
	public static final String STATUS_IN_PROCESS = "IN_PROCESS";
	public static final String STATUS_PARTIAL_SUCCESS = "PARTIAL_SUCCESS";
	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String STATUS_FAILED = "FAILED";

	// Validation errror messages
	public static final String SUB_INVENTORY_FIELD_IS_MISSING = "Sub-Inventory field is missing";
	public static final String LOCATION_FIELD_IS_MISSING = "Location field is missing";
	public static final String ORGANIZATION_FIELD_IS_MISSING = "Organization field is missing";
	public static final String QUANTITY_FIELD_IS_MISSING = "Quantity field is missing";
	public static final String LINE_ACTION_FIELD_IS_MISSING = "Line Action field is missing";
	public static final String PURCHASE_ORDER_NUMBER_FIELD_IS_MISSING = "Purchase Order Number field is missing";
	public static final String INVALID_VALUE_FOR_LINE_ACTION = "Invalid value for Line Action";
	public static final String INVALID_VALUE_FOR_BYPASS_AUTOGEN = "Invalid value for Bypass Autogen";
	public static final String ALLOW_PRICE_OVERRIDE_SHOULD_BE_NULL = "Allow Price Override should be null when Action is update";
	public static final String REASON_CODE_40_IS_NOT_ALLOWED_FOR_THE_UPDATE_OPERATION = "Reason code 40 is not allowed for update operation";
	public static final String LINE_ACTION_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_PO_NUMBER = "Line Action should be same for all lines for given PO Number";
	public static final String ORGANIZATION_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_PO_NUMBER = "Organization should be same for all lines for given PO Number";
	public static final String LOCATION_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_PO_NUMBER = "Location should be same for all lines for given PO Number";
	public static final String SUBINVENTORY_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_PO_NUMBER = "Subinventory should be same for all lines for given PO Number";
	public static final String HEADER_DATA_MISMATCH_FOR_GIVEN_PO_NUMBER = "Header data mismatch for given PO Number";
	public static final String ERROR_IN_UNDERLYING_LINES = "Error in Underlying Lines[ | ]*";
	public static final String APPLICATION_ERROR_ENCOUNTERED_DURING_VALIDATION = "Application error encountered during validation";
	public static final String APPLICATION_ERROR_ENCOUNTERED_DURING_IMPORT = "Application error encountered during import";
	// public static final String APPLICATION_ERROR_ENCOUNTERED_DURING_PRICE =
	// "Application error encountered during price";
	public static final String INVENTORY_ORG_CODE_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_GROUP_ID = "Inventory Org Code should be same for all lines for given Group ID";
	public static final String VMI_DIRECT_SHOULD_BE_SAME_FOR_ALL_LINES_FOR_GIVEN_GROUP_ID = "VMI Direct should be same for all lines for given Group ID";
	public static final String HEADER_DATA_MISMATCH_FOR_GIVEN_GROUP_ID = "Header data mismatch for given Group ID";
	public static final String GROUP_ID_FIELD_IS_MISSING = "Group ID field is missing";
	public static final String DUPLICATE_ITEM_ERROR_FOR_GIVEN_PO_NUMBER = "Same Item can not be repeated across lines for given PO Number";
	public static final String DUPLICATE_ITEM_ERROR_FOR_GIVEN_GROUP_ID = "Same Item can not be repeated across lines for given Group ID";
	public static final String ITEM_IS_MANDATORY_FOR_UPDATING_LINE_LEVEL_DETAILS = "Item is mandatory for updating Line level details";
	public static final String INVALID_VALUE_FOR_ACTION = "Invalid value for Action";
	// Prism Logger
	public static final String BLANKET_SOURCE = "BLANKET";
	public static final String KEY_SOURCE = "identifier1";
	public static final String KEY_ACTION = "identifier2";
	public static final String KEY_TRANSACTION_TYPE = "identifier3";
	public static final String TXN_TYPE_VALUE = "Request";
	public static final String BUSSINESS_OBJECT = "Bulkupload-PO-BPA";

	public static final String EVENT_RECEIVE_BULK_UPLOAD_MESSAGE = "ReceiveBulkUploadMessage";
	public static final String EVENT_BULK_UPLOAD_PRE_VALIDATION_NACK = "BulkUploadPreValidationNack";
	public static final String EVENT_BULK_UPLOAD_VALIDATION = "BulkUploadValidation";
	public static final String EVENT_BULK_UPLOAD_POST_VALIDATION_NACK = "BulkUploadPostValidationNack";
	public static final String EVENT_FETCH_PO_PRICE = "FetchPOPrice";
	public static final String EVENT_BULK_UPLOAD_POST_PRICE_NACK = "BulkUploadPostPriceNack";
	public static final String EVENT_BULK_UPLOAD_CREATION = "BulkUploadCreation";
	public static final String EVENT_BULK_UPLOAD_POST_CREATION_NACK = "BulkUploadPostCreationNack";

	// field length error
	public static final String INVALID_STYLE_NAME_LENGTH = "Style Name should not contain more than 240 characters";
	public static final String INVALID_OPERATING_UNIT_LENGTH = "Operating Unit should not contain more than 240 characters";
	public static final String INVALID_SUPPLIER_LENGTH = "Supplier should not contain more than 30 characters";
	public static final String INVALID_SITE_LENGTH = "Site should not contain more than 30 characters";
	public static final String INVALID_SHIP_TO_LENGTH = "Ship To should not contain more than 60 characters";
	public static final String INVALID_BILL_TO_LENGTH = "Bill To should not contain more than 60 characters";
	public static final String INVALID_DESCRIPTION_LENGTH = "Description should not contain more than 240 characters";
	public static final String INVALID_BPA_TYPE_LENGTH = "BPA Type should not contain more than 150 characters";
	public static final String INVALID_INVENTORY_ORG_LENGTH = "Organization should not contain more than 150 characters";
	public static final String INVALID_ALLOW_PRICE_OVERRIDE_LENGTH = "Allow Price Override should not contain more than 150 characters";
	public static final String INVALID_REASON_CODE_LENGTH = "Reason Code should not contain more than 10 characters";
	public static final String INVALID_INTERNAL_COMMENTS_LENGTH = "Internal Comments should not contain more than 480 characters";
	public static final String INVALID_LINE_COMMENTS_LENGTH = "Line Comments should not contain more than 1000 characters";
	public static final String INVALID_LAST_TIME_BUY_LENGTH = "Last Time Buy should not contain more than 150 characters";
	public static final String INVALID_ITEM_LENGTH = "Item should not contain more than 1000 characters";
	public static final String INVALID_ATTACHMENT_FILE_NAME_LENGTH = "Attachment File Name field length is more than 100 characters";
	public static final String INVALID_CLAUSES_LENGTH = "Clauses should not contain more than 150 characters";
	public static final String INVALID_FREIGHT_TERMS_LENGTH = "Freight Terms should not contain more than 25 characters";
	public static final String INVALID_TRANS_METHOD_LENGTH = "Trans Method should not contain more than 25 characters";
	public static final String INVALID_SHIP_VIA_LENGTH = "Ship Via should not contain more than 25 characters";
	public static final String INVALID_ICC_SLC_LOCATION_LENGTH = "ICC SLC Location should not contain more than 150 characters";
	public static final String INVALID_PO_SITE_LENGTH = "PO Site should not contain more than 30 characters";
	public static final String INVALID_DEFAULT_SHIP_TO_LOCATION_LENGTH = "Default Ship To Location should not contain more than 60 characters";

	public static final String SAVING_DATA_TO_BULK_UPLOAD_PRICE_COLLECTION = "Saving data to Bulk Upload Price collection: ";
	public static final String GENERATED_TRANSACTION_ID_SEQUENCE = "Generated Transaction ID Sequence: ";
	public static final String GENERATING_TRANSACTION_ID_SEQUENCE = "Generating Transaction ID Sequence.";
	public static final String INVOKING_BULK_UPLOAD_VALIDATION_SERVICE_FOR_TRANSACTION_ID = "Invoking Bulk Upload Validation service for Transaction ID: ";
	public static final String FOR_TRANSACTION_ID = " for Transaction ID: ";
	public static final String SAVING_DATA_TO_BULK_UPLOAD_ERROR_COLLECTION = "Saving data to Bulk Upload Error collection: ";
	public static final String INVOKING_PO_PRICE_SERVICE_FOR_TRANSACTION_ID = "Invoking PO Price service for Transaction ID: ";
	public static final String SAVING_DATA_TO_BULK_UPLOAD_PAYLOAD_COLLECTION = "Saving data to Bulk Upload Payload collection: ";
	public static final String INVOKING_BULK_UPLOAD_IMPORT_SERVICE_FOR_TRANSACTION_ID = "Invoking Bulk Upload Import service for Transaction ID: ";
	public static final String PAYLOAD = "Payload: ";
	public static final String UNEXPECTED_EXCEPTION_ENCOUNTERED = "Unexpected Exception encountered: ";
	public static final String BULK_UPLOAD_PAYLOAD_SAVED_TO_MONGODB_FOR_TRANSACTION_ID = "BulkUpload payload saved to mongodb for Transaction ID : ";
	public static final String PRE_VALIDATION_CHECK_FAILED_WITH_ERROR_MESSAGE = "Pre-validation check failed with error message : ";
	public static final String STATING_ASYNC_METHOD_INVOCATION_PART_FOR_TRANSACTION_ID = "Stating Async Method invocation part for Transaction ID :";
	public static final String INVALID_VALUE_FOR_ALLOW_PRICE_OVERRIDE = "Invalid value for Allow Price Override";
	public static final String INVALID_VALUE_FOR_LAST_TIME_BUY = "Invalid value for Last Time Buy";
	public static final String REASON_CODE_IS_MANDATORY_WHEN_ALLOW_PRICE_OVERRIDE_IS_N = "Reason Code is mandatory when Allow Price Override is N";
	public static final String QUANTITY_IS_MANDATORY_WHEN_LAST_TIME_BUY_IS_Y = "Quantity is mandatory when Last Time Buy is Y";
	public static final String INTERNAL_COMMENTS_IS_MANDATORY_WHEN_REASON_CODE_IS_40 = "Internal Comments is mandatory when Reason Code is 40";
	public static final String ITEM_FIELD_IS_MISSING = "Item field is missing";
	public static final String SITE_FIELD_IS_MISSING = "Site field is missing";
	public static final String REASON_CODE_IS_MANDATORY_WHEN_PRICE_IS_ENTERED = "Reason Code is mandatory when Price is entered";
	public static final String BPA_TYPE_FIELD_IS_MISSING = "BPA Type field is missing";
	public static final String INVENTORY_ORG_FIELD_IS_MISSING = "Inventory Org field is missing";
	public static final String SUPPLIER_FIELD_IS_MISSING = "Supplier field is missing";
	public static final String STYLE_NAME_FIELD_IS_MISSING = "Style Name field is missing";
	public static final String OPERATING_UNIT_FIELD_IS_MISSING = "Operating Unit field is missing";
	public static final String INVALID_GROUP_ID_LENGTH = "Group ID should not contain more than 10 characters";
	public static final String PO_SITE_FIELD_IS_MISSING = "PO Site field is missing";
	public static final String DEFAULT_SHIP_TO_LOCATION_FIELD_IS_MISSING = "Default Ship To Location field is missing";

	public static final String INVALID_PRICE_RETURN_FROM_PRICE_SERVICE = "Invalid price returned from ONE COST or PO-Price service without error Message";
	public static final String APPLICATION_ERROR_NOT_ABLE_TO_CONNECT_WITH_ONE_COST = "APPLICATION ERROR: NOT ABLE TO CONNECT WITH ONE COST - PO-Price service is down or unreachable";
	public static final String VALIDATE_FIELD_LENGTH_CALLED_FOR_TRANSACTION_ID = "ValidateFieldLength Called for Transaction ID :";
	public static final String VALIDATE_COMMON_ATTRIBUTES_CALLED_FOR_TRANSACTION_ID = "ValidateCommonAttributes called for Transaction ID : ";
	public static final String INVALID_PURCHASE_ORDER_NUMBER_LENGTH = "Purchase Order Number should not contain more than 20 characters";
	public static final String ERROR_TOTAL_COST_MORE_THAN_DEFINED_LIMIT_ATTACHMENT_MANDATORY = "BPO Header Attachment is mandatory for Blanket Purchase Order total greater than ";
	public static final String ERROR_COST_TYPE_MN_ATTACHMENT_MANDATORY = "BPO Header Attachment is mandatory for Blanket Purchase Order when cost type is MN ";

}
