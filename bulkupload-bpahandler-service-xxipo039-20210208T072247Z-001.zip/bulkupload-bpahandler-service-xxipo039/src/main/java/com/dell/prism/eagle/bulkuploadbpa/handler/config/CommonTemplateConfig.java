package com.dell.prism.eagle.bulkuploadbpa.handler.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.web.client.RestTemplate;

import com.mongodb.MongoClientURI;

@Configuration
public class CommonTemplateConfig {

	@Value(value = "${spring.data.mongodb.uri}")
	private String mongodbUri;

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	public MongoDbFactory mongoDbFactory() {
		return new SimpleMongoDbFactory(new MongoClientURI(mongodbUri));
	}
	@Bean
	public MongoTemplate mongoTemplate() {
		return new MongoTemplate(mongoDbFactory());
	}

}
