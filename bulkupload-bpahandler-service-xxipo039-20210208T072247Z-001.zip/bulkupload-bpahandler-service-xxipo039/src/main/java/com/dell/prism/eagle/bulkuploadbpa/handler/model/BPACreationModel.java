package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import java.math.BigDecimal;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class BPACreationModel {

	@JsonProperty("Group ID")
	private String groupId;
	@JsonProperty("Operating Unit")
	private String operatingUnit;
	@JsonProperty("Style Name")
	private String styleName;
	@JsonProperty("Attachment File Name")
	private String attachment;
	@JsonProperty("Supplier")
	private String supplier;
	@JsonProperty("Supplier Site")
	private String supplierSite;
	@JsonProperty("Ship To")
	private String shipTo;
	@JsonProperty("Bill To Location")
	private String billTo;
	@JsonProperty("Description")
	private String description;
	@JsonProperty("Trans Method")
	private String transMethod;
	@JsonProperty("Ship Via")
	private String freightCarrier;
	@JsonProperty("Freight Terms")
	private String deliveryTerms;
	@JsonProperty("Clauses")
	private String clauses;
	@JsonProperty("BPO Type")
	private String vmiDirect;
	@JsonProperty("ICC SLC Location")
	private String iccSlcLocation;
	// Added new attributes Start
	@JsonProperty("PO Site")
	private String poSite;
	@JsonProperty("Default Ship To Location")
	private String defaultShipToLocation;
	// Added new attributes End
	@JsonProperty("Inventory Org")
	private String inventoryOrg;
	@JsonProperty("Item")
	private String item;
	@JsonProperty("Quantity Agreed")
	private BigDecimal quantity;
	@JsonProperty("Price")
	private Double price;
	@JsonProperty("Reason Code")
	private String reasonCode;
	@JsonProperty("Last Time Buy")
	private String lastTimeBuy;
	@JsonProperty("Line Comments")
	private String lineComments;
	@JsonProperty("Allow Price Override")
	private String allowPriceOverride;
	@JsonProperty("Internal Comments")
	private String internalComments;

	// Fields not coming from Excel
	@JsonIgnore
	@JsonProperty("Buyer Code")
	private String buyerCode;
	@JsonIgnore
	@JsonProperty("Cost Type")
	private String costType;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BPACreationModel other = (BPACreationModel) obj;
		return Objects.equals(attachment, other.attachment) && Objects.equals(billTo, other.billTo)
				&& Objects.equals(clauses, other.clauses) && Objects.equals(deliveryTerms, other.deliveryTerms)
				&& Objects.equals(description, other.description)
				&& Objects.equals(freightCarrier, other.freightCarrier) && Objects.equals(groupId, other.groupId)
				&& Objects.equals(inventoryOrg, other.inventoryOrg)
				// Added new attributes Start
				&& Objects.equals(poSite, other.poSite)
				&& Objects.equals(defaultShipToLocation, other.defaultShipToLocation)
				// Added new attributes End
				&& Objects.equals(operatingUnit, other.operatingUnit) && Objects.equals(shipTo, other.shipTo)
				&& Objects.equals(supplierSite, other.supplierSite) && Objects.equals(styleName, other.styleName)
				&& Objects.equals(supplier, other.supplier) && Objects.equals(transMethod, other.transMethod)
				&& Objects.equals(vmiDirect, other.vmiDirect);
	}

	@Override
	public int hashCode() {
		return Objects.hash(attachment, billTo, clauses, deliveryTerms, description, freightCarrier, groupId,
				inventoryOrg, poSite, defaultShipToLocation, operatingUnit, shipTo, supplierSite, styleName, supplier,
				transMethod, vmiDirect);
	}
}