package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class ValidationLineModel {
	private String action;
	private String item;
	private BigDecimal itemId;
	private BigDecimal poHeaderId;
	private BigDecimal poLineId;
	private BigDecimal lineNum;
	private BigDecimal lineOldPrice;
	private String lineOldCostType;
	private BigDecimal lineOldQuantity;
	private BigDecimal quantity;
	private Double unitPrice;
	private Double listPrice;
	private String costType;
	private String priceCompleteFlag;
	private String lastTimeBuy;
	private String allowPriceOverride;
	private Date needByDate;
	private Date shipByDate;
	private Date releaseDate;
	private String itemBuyerName;
	private BigDecimal itemBuyerId;
	private String itemType;
	private String vendorProductNum;
	private String lineComments;
	private String internalComments;
	private String reasonCode;
	private String shipToLocationShipping;
	private BigDecimal shipToLocationIdShipping;
	private String shipToOrgname;
	private BigDecimal shipToOrgId;
	private String subInventoryName;
	private String statusCode;
	private String errorMessage;
	private String errorCode;
}