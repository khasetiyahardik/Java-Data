package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.COLLECTION_BULK_UPLOAD_PAYLOAD;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
@Document(COLLECTION_BULK_UPLOAD_PAYLOAD)
public class BulkUploadPayloadModel<X, Y> {

	@Id
	private String id;
	private String transactionId;
	private String template;
	private String tranType;
	private List<X> inputPayload;
	private List<Y> responsePayload;
	private String fileName;
	private String userName;
	private String status;
	private StatusDetails statusDetails;
	private Date createdDate;
	private Date modifiedDate;
	private String modifiedBy;
}