package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class BPAUpdationInputModel {

	@NotNull
	private List<BPAUpdationModel> bpaUpdationModels;
	@NotNull
	private String fileName;
	@NotNull
	private String userName;
	@NotNull
	private BigDecimal buyerId;
	@NotNull
	private String transactionId;
}