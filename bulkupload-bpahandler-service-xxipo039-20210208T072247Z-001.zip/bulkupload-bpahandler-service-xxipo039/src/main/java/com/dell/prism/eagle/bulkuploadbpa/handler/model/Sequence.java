package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import static com.dell.prism.eagle.bulkuploadbpa.handler.constant.BulkUploadBPAConstant.COLLECTION_SEQUENCE;

import java.math.BigInteger;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(COLLECTION_SEQUENCE)
public class Sequence {

	@Id
	private String sequenceName;
	private BigInteger sequenceValue;
}