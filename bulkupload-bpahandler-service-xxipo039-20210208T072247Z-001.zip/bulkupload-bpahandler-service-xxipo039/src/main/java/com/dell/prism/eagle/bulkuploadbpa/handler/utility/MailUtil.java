package com.dell.prism.eagle.bulkuploadbpa.handler.utility;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.dell.eagle.mail.notification.client.model.MailDetailsDTO;
import com.dell.eagle.mail.notification.client.service.MailClientConsumer;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MailUtil {

	@Value("${mail.notification.service.alert}")
	private String mailNotificationServiceAlertUrl;

	@Autowired
	private MailClientConsumer mailClientConsumer;

	private static final String SERVICE_NAME = "bulkupload-bpahandler-service-xxipo039";

	public void mailNotification(String notificationType) {
		try {
			mailClientConsumer.sendMailNotification(getMailDetails(notificationType), mailNotificationServiceAlertUrl,
					SERVICE_NAME, true);
		} catch (Exception e) {
			log.error("Exception Ocuured while calling mailClientConsumer", e);
		}
	}

	private MailDetailsDTO getMailDetails(String notificationType) {
		Map<String, String> map = new HashMap<>();
		return MailDetailsDTO.builder().notificationType(notificationType).severity("MEDIUM").mailValues(map)
				.primaryKeyId("BPA_CREATED_" + new Date()).createdOn(new Date()).source(SERVICE_NAME).build();
	}
}