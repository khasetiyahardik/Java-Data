package com.dell.prism.eagle.bulkuploadbpa.handler.utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DateStringUtil {

	private DateStringUtil() {
	}

	/**
	 * The <code>getStringFromDate</code> is used to get the Date from String.
	 * 
	 * @param date
	 * @return
	 */
	public static String getStringFromDate(Date date) {
		String dateString = null;
		if (date != null) {
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			dateString = dateFormat.format(date);
		}
		return dateString;

	}

	public Date getDateFromString(String input) {
		if (input != null) {
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			try {
				return dateFormat.parse(input);
			} catch (ParseException e) {
				log.error("Exception occurred while parsing input date String: " + e);
			}
		}
		return null;
	}
}