package com.dell.prism.eagle.bulkuploadbpa.handler.model;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class ImportShipmentModel {

	private BigDecimal shipmentNumber;
	private BigDecimal shipToLocationIdShipping;
	private BigDecimal shipToOrgId;
	private String subinventoryName;
	private String statusCode;
	private String errorMessage;
	private String errorCode;

}