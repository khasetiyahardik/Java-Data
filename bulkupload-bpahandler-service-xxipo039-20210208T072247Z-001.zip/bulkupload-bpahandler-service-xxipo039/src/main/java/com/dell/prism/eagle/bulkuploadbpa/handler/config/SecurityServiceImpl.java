package com.dell.prism.eagle.bulkuploadbpa.handler.config;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SecurityServiceImpl {

	@Value(value = "${dias.clientdId}")
	private String clientid;
	@Value(value = "${dias.secretId}")
	private String secretKey;
	@Value(value = "${dias.url}")
	private String diasURL;
	
	@Autowired
	private RestTemplate restTemplate;

	public String getAccessToken() {
		
		String credentials = new StringBuilder().append(clientid).append(":").append(secretKey).toString();
		String encodedCredentials = new String(Base64.encodeBase64(credentials.getBytes()));

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("Authorization", "Basic " + encodedCredentials);
		ClientDetails clientRequest = new ClientDetails("client_credentials");
		HttpEntity<ClientDetails> request = new HttpEntity<>(clientRequest, headers);
		ResponseEntity<AccessTokenResponse> response = restTemplate.exchange(diasURL, HttpMethod.POST, request,
				AccessTokenResponse.class);
		log.info("Token generation response from DAIS " + "{}" + response);
		AccessTokenResponse accessTokenResponse = response.getBody();
		return accessTokenResponse.getAccess_token();
	}
}