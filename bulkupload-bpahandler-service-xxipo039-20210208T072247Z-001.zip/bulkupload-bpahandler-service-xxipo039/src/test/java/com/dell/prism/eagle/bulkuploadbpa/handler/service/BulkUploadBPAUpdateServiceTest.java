
package com.dell.prism.eagle.bulkuploadbpa.handler.service;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import org.apache.commons.lang.RandomStringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.dell.prism.eagle.bulkuploadbpa.handler.exception.ApiException;
import com.dell.prism.eagle.bulkuploadbpa.handler.integrator.BulkUploadBPAIntegrator;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPAUpdationInputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPAUpdationModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPAUpdationResponseModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadPayloadModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.util.TestUtil;
import com.dell.prism.eagle.bulkuploadbpa.handler.utility.BulkUploadBPAUtil;

@RunWith(SpringRunner.class)
public class BulkUploadBPAUpdateServiceTest {

	private static final String DUMMY = "DUMMY";

	@Mock
	private BulkUploadBPAUtil util;

	@Mock
	private BulkUploadBPAIntegrator integrator;

	@InjectMocks
	private BulkUploadBPAUpdateService bulkUploadBPAUpdateService;
	
	BulkUploadPayloadModel<BPAUpdationModel, BPAUpdationResponseModel> bulkUploadPayloadModel = new BulkUploadPayloadModel<>();

	@Before
	public void initialize() {
		when(util.initializeBulkUploadErrorModel(Mockito.any(), Mockito.anyString())).thenCallRealMethod();
		when(util.initializeBulkUploadPayloadModel(Mockito.any(), Mockito.anyString())).thenCallRealMethod();
		when(util.initializeBulkUploadPriceModel(Mockito.anyString())).thenCallRealMethod();
		util.initializeBulkUploadPayloadModel(bulkUploadPayloadModel, DUMMY);
	}

	@Test
	public void testInvokePOUpdation() {
		when(integrator.generateTransactionId()).thenReturn(DUMMY);

		bulkUploadBPAUpdateService.invokeBPAUpdation(TestUtil.createDummyBpaUpdationInputModel());

	}

	@Test
	public void testExecutePOUpdation() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponse());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyBpaUpdationInputModel(), DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testExecutePOUpdationImportLineAsNull() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponse());
		when(integrator.callbulkUploadImportService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyImportResponseAsLineNull());

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyBpaUpdationInputModel(), DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testInvalidMandatoryField() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponse());
		when(integrator.callbulkUploadImportService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyImportResponseAsLineNull());

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyInvalidBpaUpdationInputModel(), DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testInvalidMandatoryFieldForUpdate() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponse());
		when(integrator.callbulkUploadImportService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyImportResponseAsLineNull());

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.dummyInvalidBpaUpdationInputModelForUpdate(), DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testInvalidMandatoryFieldForAdd() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponse());
		when(integrator.callbulkUploadImportService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyImportResponseAsLineNull());

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.dummyInvalidBpaUpdationInputModelForAdd(), DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testValidationFailed() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyFailedValidationResponse());
		when(integrator.callbulkUploadImportService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyImportResponseAsLineNull());

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyBpaUpdationInputModel(), DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testImportFailed() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponse());
		when(integrator.callbulkUploadImportService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyFailedImportResponse());

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyBpaUpdationInputModel(), DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testExecuteBpaCreationForLengthCheck() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		BPAUpdationInputModel poUpdationInputModel = TestUtil.createDummyBpaUpdationInputModel();
		poUpdationInputModel.getBpaUpdationModels().get(0)
				.setOperatingUnit(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poUpdationInputModel.getBpaUpdationModels().get(0)
				.setClauses(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poUpdationInputModel.getBpaUpdationModels().get(0)
				.setAttachment(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poUpdationInputModel.getBpaUpdationModels().get(0)
				.setItem(RandomStringUtils.randomAlphanumeric(1001).toUpperCase());
		poUpdationInputModel.getBpaUpdationModels().get(0)
				.setLastTimeBuy(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poUpdationInputModel.getBpaUpdationModels().get(0)
				.setLineComments(RandomStringUtils.randomAlphanumeric(1001).toUpperCase());
		poUpdationInputModel.getBpaUpdationModels().get(0)
				.setInternalComments(RandomStringUtils.randomAlphanumeric(1001).toUpperCase());
		poUpdationInputModel.getBpaUpdationModels().get(0)
				.setReasonCode(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poUpdationInputModel.getBpaUpdationModels().get(0)
				.setAllowPriceOverride(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poUpdationInputModel.getBpaUpdationModels().get(0)
				.setInventoryOrg(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poUpdationInputModel.getBpaUpdationModels().get(0)
				.setIccSlcLocation(RandomStringUtils.randomAlphanumeric(256).toUpperCase());

		bulkUploadBPAUpdateService.executeBPAUpdation(poUpdationInputModel, DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testForCostAttributeMissingAddAction() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForAddMissingCostType());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.dummyBpaUpdationInputModelForAdd(), DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testExceptionForCallingPriceService() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.DummyValidationResponseWithHeaderNull());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.dummyBpaUpdationInputModelForAdd(), DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testExecuteBpaUpdationForDefaultValue() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyBpaUpdationInputModelForDefaultValue(),
				DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testExecutePOUpdation_Validation_ApiException() {

		when(integrator.callbulkUploadValidationService(Mockito.any())).thenThrow(ApiException.class);
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyBpaUpdationInputModel(), DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testExecutePOUpdation_Validation_Exception() {

		when(integrator.callbulkUploadValidationService(Mockito.any())).thenThrow(NullPointerException.class);
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyBpaUpdationInputModel(), DUMMY, bulkUploadPayloadModel);
	}

	@Test
	public void testImportException() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenThrow(NullPointerException.class);

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyBpaUpdationInputModel(), DUMMY, bulkUploadPayloadModel);
	}
	
	@Test
	public void testExecutePOUpdation1() {

		when(integrator.callbulkUploadValidationService(Mockito.any())).thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		doThrow(new RuntimeException()).when(integrator).savePricePayloadCollection(Mockito.any());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyBpaUpdationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}

	@Test
	public void testExecutePOUpdation2() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenThrow(RuntimeException.class);
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyBpaUpdationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}

	@Test
	public void testExecutePOUpdation3() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		doThrow(new ApiException("test")).when(integrator).savePricePayloadCollection(Mockito.any());
		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyBpaUpdationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}
	@Test
	public void testExecutePOUpdation4() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenThrow(ApiException.class);
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());

		bulkUploadBPAUpdateService.executeBPAUpdation(TestUtil.createDummyBpaUpdationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}
	
}
