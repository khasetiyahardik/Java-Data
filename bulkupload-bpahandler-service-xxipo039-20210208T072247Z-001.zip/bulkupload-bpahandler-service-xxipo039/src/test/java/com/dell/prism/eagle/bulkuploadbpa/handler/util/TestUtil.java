package com.dell.prism.eagle.bulkuploadbpa.handler.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPACreationInputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPACreationModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPAUpdationInputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPAUpdationModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportEBSOutputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportHeaderModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportLineModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ImportOutputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.PriceHeaderModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.PricePartDetailsModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationHeaderModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationLineModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.ValidationModel;

public class TestUtil {

	private static final String DUMMY = "DUMMY";
	private static final String ATTACHMENT_FILE_LENGHT = "DUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYDUMMY";

	public static BPACreationInputModel createDummyBpaCreationInputModelForLengthCheck() {

		List<BPACreationModel> BPACreationModelList = new ArrayList<>();

		BPACreationModel BPACreationModel = new BPACreationModel();
		BPACreationModel.setItem(DUMMY);
		BPACreationModel.setGroupId(DUMMY);
		BPACreationModel.setOperatingUnit(DUMMY);
		BPACreationModel.setLastTimeBuy("N");
		BPACreationModel.setQuantity(new BigDecimal(10));
		BPACreationModel.setStyleName(DUMMY);
		BPACreationModel.setSupplier(DUMMY);
		BPACreationModel.setSupplierSite(DUMMY);
		BPACreationModel.setReasonCode("40263647465745485");
		BPACreationModel.setInternalComments(DUMMY);
		BPACreationModel.setPrice(10.0);
		BPACreationModel.setPoSite(DUMMY);
		BPACreationModel.setDefaultShipToLocation(DUMMY);
		BPACreationModel.setTransMethod("transMethodtransMethodtransMethodtransMethod");
		BPACreationModel.setDeliveryTerms("deliveryTermsdeliveryTermsdeliveryTermsdeliveryTerms");
		BPACreationModel.setFreightCarrier("freightCarrierfreightCarrierfreightCarrierfreightCarrier");
		BPACreationModel.setAttachment(ATTACHMENT_FILE_LENGHT);

		BPACreationModelList.add(BPACreationModel);

		BPACreationInputModel BPACreationInputModel = new BPACreationInputModel();
		BPACreationInputModel.setFileName("a.text");
		BPACreationInputModel.setUserName("A");
		BPACreationInputModel.setBpaCreationModels(BPACreationModelList);

		return BPACreationInputModel;
	}

	public static BPAUpdationInputModel createDummyBpaUpdationInputModelForLengthCheck() {

		List<BPAUpdationModel> BPAUpdationModelList = new ArrayList<>();

		BPAUpdationModel BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setItem(DUMMY);
		BPAUpdationModel.setExistingPoNumber(DUMMY);
		BPAUpdationModel.setOperatingUnit(DUMMY);
		BPAUpdationModel.setLastTimeBuy("N");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setInventoryOrg(DUMMY);
		BPAUpdationModel.setReasonCode("40263647465745485");
		BPAUpdationModel.setInternalComments(DUMMY);
		BPAUpdationModel.setPrice(10.0);
		BPAUpdationModel.setDefaultShipToLocation(DUMMY);
		BPAUpdationModel.setAttachment(ATTACHMENT_FILE_LENGHT);

		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationInputModel BPAUpdationInputModel = new BPAUpdationInputModel();
		BPAUpdationInputModel.setFileName("a.text");
		BPAUpdationInputModel.setUserName("A");
		BPAUpdationInputModel.setBpaUpdationModels(BPAUpdationModelList);

		return BPAUpdationInputModel;
	}

	public static BPAUpdationInputModel createDummyBpaUpdationInputModel() {

		List<BPAUpdationModel> BPAUpdationModelList = new ArrayList<>();

		BPAUpdationModel BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setExistingPoNumber(DUMMY);
		BPAUpdationModel.setItem("Item1");
		BPAUpdationModel.setOperatingUnit(DUMMY);
		BPAUpdationModel.setAction("U");
		BPAUpdationModel.setLastTimeBuy("Y");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setDefaultShipToLocation(DUMMY);
		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setExistingPoNumber(DUMMY);
		BPAUpdationModel.setItem("Item2");
		BPAUpdationModel.setOperatingUnit(DUMMY);
		BPAUpdationModel.setAction("U");
		BPAUpdationModel.setLastTimeBuy("Y");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setDefaultShipToLocation(DUMMY);
		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setExistingPoNumber("DUMMY1");
		BPAUpdationModel.setItem("Item2");
		BPAUpdationModel.setOperatingUnit(DUMMY);
		BPAUpdationModel.setAction("U");
		BPAUpdationModel.setLastTimeBuy("Y");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setInventoryOrg(DUMMY);
		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setExistingPoNumber("DUMMY1");
		BPAUpdationModel.setItem("Item2");
		BPAUpdationModel.setOperatingUnit(DUMMY);
		BPAUpdationModel.setAction("U");
		BPAUpdationModel.setLastTimeBuy("Y");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setDefaultShipToLocation(DUMMY);
		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setItem("Item2");
		BPAUpdationModel.setOperatingUnit(DUMMY);
		BPAUpdationModel.setAction("U");
		BPAUpdationModel.setLastTimeBuy("Y");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setDefaultShipToLocation(DUMMY);
		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setExistingPoNumber("DUMMY3");
		BPAUpdationModel.setItem("Item2");
		BPAUpdationModel.setOperatingUnit(DUMMY);
		BPAUpdationModel.setAction("U");
		BPAUpdationModel.setLastTimeBuy("Y");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setDefaultShipToLocation(DUMMY);
		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setExistingPoNumber("DUMMY3");
		BPAUpdationModel.setItem("Item2");
		BPAUpdationModel.setOperatingUnit(DUMMY);
		BPAUpdationModel.setAction("A");
		BPAUpdationModel.setLastTimeBuy("Y");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setDefaultShipToLocation(DUMMY);
		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationInputModel BPAUpdationInputModel = new BPAUpdationInputModel();
		BPAUpdationInputModel.setFileName("a.text");
		BPAUpdationInputModel.setUserName("A");
		BPAUpdationInputModel.setBpaUpdationModels(BPAUpdationModelList);

		return BPAUpdationInputModel;
	}

	public static BPAUpdationInputModel createDummyInvalidBpaUpdationInputModel() {

		List<BPAUpdationModel> BPAUpdationModelList = new ArrayList<>();

		BPAUpdationModel BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setExistingPoNumber(DUMMY);
		BPAUpdationModel.setItem(DUMMY);
		BPAUpdationModel.setLastTimeBuy("Y");
		BPAUpdationModel.setReasonCode("40");
		BPAUpdationModel.setQuantity(new BigDecimal(10));

		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationInputModel BPAUpdationInputModel = new BPAUpdationInputModel();
		BPAUpdationInputModel.setFileName("a.text");
		BPAUpdationInputModel.setUserName("A");
		BPAUpdationInputModel.setBpaUpdationModels(BPAUpdationModelList);

		return BPAUpdationInputModel;
	}

	public static BPAUpdationInputModel dummyInvalidBpaUpdationInputModelForUpdate() {

		List<BPAUpdationModel> BPAUpdationModelList = new ArrayList<>();

		BPAUpdationModel BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setExistingPoNumber(DUMMY);
		BPAUpdationModel.setItem(DUMMY);
		BPAUpdationModel.setAction("U");
		BPAUpdationModel.setLastTimeBuy("Y");
		BPAUpdationModel.setInternalComments(DUMMY);
		BPAUpdationModel.setReasonCode("40");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setAllowPriceOverride("Y");
		BPAUpdationModel.setDefaultShipToLocation(DUMMY);

		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationInputModel BPAUpdationInputModel = new BPAUpdationInputModel();
		BPAUpdationInputModel.setFileName("a.text");
		BPAUpdationInputModel.setUserName("A");
		BPAUpdationInputModel.setBpaUpdationModels(BPAUpdationModelList);

		return BPAUpdationInputModel;
	}

	public static BPAUpdationInputModel dummyInvalidBpaUpdationInputModelForAdd() {

		List<BPAUpdationModel> BPAUpdationModelList = new ArrayList<>();

		BPAUpdationModel BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setExistingPoNumber(DUMMY);
		BPAUpdationModel.setAction("ADD");
		BPAUpdationModel.setLastTimeBuy("Y");
		BPAUpdationModel.setInternalComments(DUMMY);
		BPAUpdationModel.setReasonCode("40");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setDefaultShipToLocation(DUMMY);

		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationInputModel BPAUpdationInputModel = new BPAUpdationInputModel();
		BPAUpdationInputModel.setFileName("a.text");
		BPAUpdationInputModel.setUserName("A");
		BPAUpdationInputModel.setBpaUpdationModels(BPAUpdationModelList);

		return BPAUpdationInputModel;
	}

	public static BPAUpdationInputModel dummyBpaUpdationInputModelForAdd() {

		List<BPAUpdationModel> BPAUpdationModelList = new ArrayList<>();

		BPAUpdationModel BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setExistingPoNumber(DUMMY);
		BPAUpdationModel.setItem("Item1");
		BPAUpdationModel.setOperatingUnit(DUMMY);
		BPAUpdationModel.setAction("ADD");
		BPAUpdationModel.setLastTimeBuy("Y");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setDefaultShipToLocation(DUMMY);

		BPAUpdationModelList.add(BPAUpdationModel);
		BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setExistingPoNumber(DUMMY);
		BPAUpdationModel.setItem("Item2");
		BPAUpdationModel.setOperatingUnit(DUMMY);
		BPAUpdationModel.setAction("ADD");
		BPAUpdationModel.setLastTimeBuy("Y");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setDefaultShipToLocation(DUMMY);
		
		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationInputModel BPAUpdationInputModel = new BPAUpdationInputModel();
		BPAUpdationInputModel.setFileName("a.text");
		BPAUpdationInputModel.setUserName("A");
		BPAUpdationInputModel.setBpaUpdationModels(BPAUpdationModelList);

		return BPAUpdationInputModel;
	}

	public static ValidationModel prepareDummyValidationResponse() {
		ValidationModel validationResponse = new ValidationModel();

		List<ValidationHeaderModel> validationHeaderModelList = new ArrayList<ValidationHeaderModel>();

		List<ValidationLineModel> validationLineModelList = new ArrayList<ValidationLineModel>();
		ValidationLineModel validationLineModel = new ValidationLineModel();
		validationLineModel.setAction("U");
		validationLineModel.setStatusCode("SUCCESS");
		validationLineModelList.add(validationLineModel);

		ValidationHeaderModel validationHeaderModel = new ValidationHeaderModel();
		validationHeaderModel.setAction("U");
		validationHeaderModel.setStatusCode("SUCCESS");
		validationHeaderModel.setLines(validationLineModelList);
		validationHeaderModelList.add(validationHeaderModel);

		validationResponse.setHeaderModels(validationHeaderModelList);

		validationResponse.setStatusCode("SUCCESS");
		return validationResponse;

	}

	public static ValidationModel prepareDummyFailedValidationResponse() {
		ValidationModel validationResponse = new ValidationModel();

		List<ValidationHeaderModel> validationHeaderModelList = new ArrayList<ValidationHeaderModel>();

		List<ValidationLineModel> validationLineModelList = new ArrayList<ValidationLineModel>();
		ValidationLineModel validationLineModel = new ValidationLineModel();
		validationLineModel.setAction("U");
		validationLineModel.setStatusCode("Failed");
		validationLineModel.setErrorMessage(DUMMY);
		validationLineModelList.add(validationLineModel);

		ValidationHeaderModel validationHeaderModel = new ValidationHeaderModel();
		validationHeaderModel.setAction("U");
		validationHeaderModel.setStatusCode("Failed");
		validationHeaderModel.setErrorMessage(DUMMY);
		validationHeaderModel.setLines(validationLineModelList);
		validationHeaderModelList.add(validationHeaderModel);

		validationResponse.setHeaderModels(validationHeaderModelList);

		validationResponse.setStatusCode("Failed");
		return validationResponse;

	}

	public static ImportOutputModel prepareDummyImportResponse() {

		ImportLineModel importLineModel = new ImportLineModel();
		importLineModel.setItem("Item1");
		importLineModel.setStatusCode("S");

		List<ImportLineModel> importLineModelList = new ArrayList<>();
		importLineModelList.add(importLineModel);
		importLineModel = new ImportLineModel();
		importLineModel.setItem("Item2");
		importLineModel.setStatusCode("S");
		importLineModelList.add(importLineModel);

		ImportHeaderModel importHeaderModel = new ImportHeaderModel();
		importHeaderModel.setAttachmentFileName(DUMMY);
		importHeaderModel.setExistingPoNumber(DUMMY);
		importHeaderModel.setGroupId("1");
		importHeaderModel.setLines(importLineModelList);
		importHeaderModel.setStatusCode("S");
		List<ImportHeaderModel> importHeaderModelList = new ArrayList<>();
		importHeaderModelList.add(importHeaderModel);

		ImportEBSOutputModel importEBSOutputModel = new ImportEBSOutputModel();
		importEBSOutputModel.setBulkUploadImportHeaderModel(importHeaderModel);
		importEBSOutputModel.setStatusCode("SUCCESS");

		List<ImportEBSOutputModel> importEBSOutputModelList = new ArrayList<>();
		importEBSOutputModelList.add(importEBSOutputModel);

		ImportOutputModel importOutputModel = new ImportOutputModel();

		importOutputModel.setBulkUploadImportOutput(importEBSOutputModelList);

		return importOutputModel;

	}

	public static ImportOutputModel prepareDummyImportResponseAsLineNull() {

		List<ImportLineModel> importLineModelList = new ArrayList<>();
		ImportHeaderModel importHeaderModel = new ImportHeaderModel();
		importHeaderModel.setAttachmentFileName(DUMMY);
		importHeaderModel.setExistingPoNumber(DUMMY);
		importHeaderModel.setGroupId(DUMMY);
		importHeaderModel.setStatusCode("S");
		importHeaderModel.setLines(importLineModelList);
		List<ImportHeaderModel> importHeaderModelList = new ArrayList<>();
		importHeaderModelList.add(importHeaderModel);

		ImportEBSOutputModel importEBSOutputModel = new ImportEBSOutputModel();
		importEBSOutputModel.setBulkUploadImportHeaderModel(importHeaderModel);
		importEBSOutputModel.setStatusCode("SUCCESS");

		List<ImportEBSOutputModel> importEBSOutputModelList = new ArrayList<>();
		importEBSOutputModelList.add(importEBSOutputModel);

		ImportOutputModel importOutputModel = new ImportOutputModel();

		importOutputModel.setBulkUploadImportOutput(importEBSOutputModelList);

		return importOutputModel;

	}

	public static ImportOutputModel prepareDummyFailedImportResponse() {

		ImportLineModel importLineModel = new ImportLineModel();
		importLineModel.setItem(DUMMY);
		importLineModel.setStatusCode("Failed");
		importLineModel.setErrorMessage(DUMMY);

		List<ImportLineModel> importLineModelList = new ArrayList<>();
		importLineModelList.add(importLineModel);

		ImportHeaderModel importHeaderModel = new ImportHeaderModel();
		importHeaderModel.setAttachmentFileName(DUMMY);
		importHeaderModel.setExistingPoNumber(DUMMY);
		importHeaderModel.setGroupId(DUMMY);
		importHeaderModel.setLines(importLineModelList);
		importHeaderModel.setErrorMessage(DUMMY);
		importHeaderModel.setStatusCode("Failed");
		List<ImportHeaderModel> importHeaderModelList = new ArrayList<>();
		importHeaderModelList.add(importHeaderModel);

		ImportEBSOutputModel importEBSOutputModel = new ImportEBSOutputModel();
		importEBSOutputModel.setBulkUploadImportHeaderModel(importHeaderModel);
		importEBSOutputModel.setStatusCode("Failed");

		List<ImportEBSOutputModel> importEBSOutputModelList = new ArrayList<>();
		importEBSOutputModelList.add(importEBSOutputModel);

		ImportOutputModel importOutputModel = new ImportOutputModel();

		importOutputModel.setBulkUploadImportOutput(importEBSOutputModelList);

		return importOutputModel;

	}

	public static ValidationModel prepareDummyValidationResponseForAdd() {
		ValidationModel validationResponse = new ValidationModel();

		List<ValidationHeaderModel> validationHeaderModelList = new ArrayList<ValidationHeaderModel>();

		List<ValidationLineModel> validationLineModelList = new ArrayList<ValidationLineModel>();
		ValidationLineModel validationLineModel = new ValidationLineModel();
		validationLineModel.setAction("ADD");
		validationLineModel.setItem(DUMMY);
		validationLineModel.setStatusCode("SUCCESS");
		validationLineModelList.add(validationLineModel);

		ValidationHeaderModel validationHeaderModel = new ValidationHeaderModel();
		validationHeaderModel.setAction("ADD");
		validationHeaderModel.setPoType(DUMMY);
		validationHeaderModel.setPoSubType(DUMMY);
		validationHeaderModel.setPoSite(DUMMY);
		validationHeaderModel.setPoSiteCCN(DUMMY);
		validationHeaderModel.setVendorCCN(DUMMY);
		validationHeaderModel.setStatusCode("SUCCESS");
		validationHeaderModel.setLines(validationLineModelList);
		validationHeaderModelList.add(validationHeaderModel);

		validationResponse.setHeaderModels(validationHeaderModelList);

		validationResponse.setStatusCode("SUCCESS");
		return validationResponse;

	}

	public static ValidationModel prepareDummyValidationResponseForAddMissingCostType() {
		ValidationModel validationResponse = new ValidationModel();

		List<ValidationHeaderModel> validationHeaderModelList = new ArrayList<ValidationHeaderModel>();

		List<ValidationLineModel> validationLineModelList = new ArrayList<ValidationLineModel>();
		ValidationLineModel validationLineModel = new ValidationLineModel();
		validationLineModel.setAction("ADD");
		validationLineModel.setItem(DUMMY);
		validationLineModel.setStatusCode("SUCCESS");
		validationLineModelList.add(validationLineModel);

		ValidationHeaderModel validationHeaderModel = new ValidationHeaderModel();
		validationHeaderModel.setAction("ADD");
		validationHeaderModel.setStatusCode("SUCCESS");
		validationHeaderModel.setLines(validationLineModelList);
		validationHeaderModelList.add(validationHeaderModel);

		validationResponse.setHeaderModels(validationHeaderModelList);

		validationResponse.setStatusCode("SUCCESS");
		return validationResponse;

	}

	public static PriceHeaderModel prepareDummyPriceResp() {

		List<PricePartDetailsModel> pricePartDetailsModelList = new ArrayList<PricePartDetailsModel>();
		PricePartDetailsModel pricePartDetailsModel = new PricePartDetailsModel();
		pricePartDetailsModel.setPartNumber("Item1");
		pricePartDetailsModel.setPrice(10.0);
		pricePartDetailsModel.setCostType(DUMMY);

		pricePartDetailsModelList.add(pricePartDetailsModel);
		pricePartDetailsModel = new PricePartDetailsModel();
		pricePartDetailsModel.setPartNumber("Item2");
		pricePartDetailsModel.setPrice(5.0);
		pricePartDetailsModel.setCostType(DUMMY);

		pricePartDetailsModelList.add(pricePartDetailsModel);

		PriceHeaderModel priceHeaderModel = new PriceHeaderModel();
		priceHeaderModel.setOdmPoType(DUMMY);
		priceHeaderModel.setPartDetails(pricePartDetailsModelList);

		return priceHeaderModel;

	}

	public static PriceHeaderModel prepareDummyPriceRespWithNullPriceDetails() {

		List<PricePartDetailsModel> pricePartDetailsModelList = new ArrayList<PricePartDetailsModel>();
		/*
		 * PricePartDetailsModel pricePartDetailsModel = new PricePartDetailsModel();
		 * pricePartDetailsModel.setPartNumber(DUMMY);
		 * pricePartDetailsModel.setPrice(10.0);
		 * pricePartDetailsModel.setCostType(DUMMY);
		 */

		pricePartDetailsModelList.add(null);

		PriceHeaderModel priceHeaderModel = new PriceHeaderModel();
		priceHeaderModel.setOdmPoType(DUMMY);
		priceHeaderModel.setPartDetails(pricePartDetailsModelList);

		return priceHeaderModel;

	}

	public static ValidationModel DummyValidationResponseWithHeaderNull() {
		ValidationModel validationResponse = new ValidationModel();

		List<ValidationHeaderModel> validationHeaderModelList = new ArrayList<ValidationHeaderModel>();

		List<ValidationLineModel> validationLineModelList = new ArrayList<ValidationLineModel>();
		ValidationLineModel validationLineModel = new ValidationLineModel();
		validationLineModel.setAction("ADD");
		validationLineModel.setItem(DUMMY);
		validationLineModel.setStatusCode("SUCCESS");
		validationLineModelList.add(validationLineModel);

		ValidationHeaderModel validationHeaderModel = new ValidationHeaderModel();

		validationHeaderModelList.add(validationHeaderModel);

		validationResponse.setHeaderModels(validationHeaderModelList);

		validationResponse.setStatusCode("SUCCESS");
		return validationResponse;

	}

	public static BPACreationInputModel createDummyBpaCreationInputModel() {

		List<BPACreationModel> BPACreationModelList = new ArrayList<>();

		BPACreationModel BPACreationModel = new BPACreationModel();
		BPACreationModel.setItem("Item1");
		BPACreationModel.setGroupId("1");
		BPACreationModel.setOperatingUnit(DUMMY);
		BPACreationModel.setLastTimeBuy("Y");
		BPACreationModel.setQuantity(new BigDecimal(10));
		BPACreationModel.setStyleName(DUMMY);
		BPACreationModel.setSupplier(DUMMY);
		BPACreationModel.setSupplierSite(DUMMY);
		BPACreationModel.setVmiDirect(DUMMY);
		BPACreationModel.setPoSite(DUMMY);
		BPACreationModel.setDefaultShipToLocation(DUMMY);

		BPACreationModelList.add(BPACreationModel);

		BPACreationModel = new BPACreationModel();
		BPACreationModel.setItem("Item2");
		BPACreationModel.setGroupId("1");
		BPACreationModel.setOperatingUnit(DUMMY);
		BPACreationModel.setLastTimeBuy("Y");
		BPACreationModel.setQuantity(new BigDecimal(10));
		BPACreationModel.setStyleName(DUMMY);
		BPACreationModel.setSupplier(DUMMY);
		BPACreationModel.setSupplierSite(DUMMY);
		BPACreationModel.setVmiDirect(DUMMY);
		BPACreationModel.setPoSite(DUMMY);
		BPACreationModel.setDefaultShipToLocation(DUMMY);
		BPACreationModelList.add(BPACreationModel);

		BPACreationModel = new BPACreationModel();
		BPACreationModel.setItem("Item2");
		BPACreationModel.setGroupId("2");
		BPACreationModel.setOperatingUnit(DUMMY);
		BPACreationModel.setLastTimeBuy("Y");
		BPACreationModel.setQuantity(new BigDecimal(10));
		BPACreationModel.setStyleName(DUMMY);
		BPACreationModel.setSupplier(DUMMY);
		BPACreationModel.setSupplierSite(DUMMY);
		BPACreationModel.setVmiDirect(DUMMY);
		BPACreationModel.setPoSite(DUMMY);
		BPACreationModel.setDefaultShipToLocation(DUMMY);
		BPACreationModelList.add(BPACreationModel);

		BPACreationModel = new BPACreationModel();
		BPACreationModel.setItem("Item2");
		BPACreationModel.setGroupId("2");
		BPACreationModel.setOperatingUnit(DUMMY);
		BPACreationModel.setLastTimeBuy("Y");
		BPACreationModel.setQuantity(new BigDecimal(10));
		BPACreationModel.setStyleName(DUMMY);
		BPACreationModel.setSupplier(DUMMY);
		BPACreationModel.setSupplierSite(DUMMY);
		BPACreationModel.setVmiDirect(DUMMY);
		BPACreationModel.setPoSite(DUMMY);
		BPACreationModel.setDefaultShipToLocation(DUMMY);
		BPACreationModelList.add(BPACreationModel);

		BPACreationModel = new BPACreationModel();
		BPACreationModel.setItem("Item2");
		BPACreationModel.setOperatingUnit(DUMMY);
		BPACreationModel.setLastTimeBuy("Y");
		BPACreationModel.setQuantity(new BigDecimal(10));
		BPACreationModel.setStyleName(DUMMY);
		BPACreationModel.setSupplier(DUMMY);
		BPACreationModel.setSupplierSite(DUMMY);
		BPACreationModel.setVmiDirect(DUMMY);
		BPACreationModel.setPoSite(DUMMY);
		BPACreationModel.setDefaultShipToLocation(DUMMY);
		BPACreationModelList.add(BPACreationModel);

		BPACreationInputModel BPACreationInputModel = new BPACreationInputModel();
		BPACreationInputModel.setFileName("a.text");
		BPACreationInputModel.setUserName("A");
		BPACreationInputModel.setTransactionId("TX100");
		BPACreationInputModel.setBpaCreationModels(BPACreationModelList);

		return BPACreationInputModel;
	}

	public static ValidationModel prepareDummyValidationResponseForCreate() {
		ValidationModel validationResponse = new ValidationModel();

		List<ValidationHeaderModel> validationHeaderModelList = new ArrayList<ValidationHeaderModel>();

		List<ValidationLineModel> validationLineModelList = new ArrayList<ValidationLineModel>();
		ValidationLineModel validationLineModel = new ValidationLineModel();
		validationLineModel.setItem("Item1");
		validationLineModel.setQuantity(BigDecimal.ONE);
		validationLineModel.setLineOldPrice(BigDecimal.ONE);
		validationLineModel.setUnitPrice(1d);
		validationLineModel.setLineOldQuantity(BigDecimal.ONE);
		validationLineModel.setAction("ADD");
		validationLineModel.setStatusCode("SUCCESS");
		validationLineModelList.add(validationLineModel);

		validationLineModel = new ValidationLineModel();
		validationLineModel.setItem("Item2");
		validationLineModel.setQuantity(BigDecimal.ONE);
		validationLineModel.setLineOldPrice(BigDecimal.ONE);
		validationLineModel.setStatusCode("SUCCESS");
		validationLineModel.setAction("ADD");
		validationLineModelList.add(validationLineModel);

		ValidationHeaderModel validationHeaderModel = new ValidationHeaderModel();
		validationHeaderModel.setPoSite(DUMMY);
		validationHeaderModel.setPoType(DUMMY);
		validationHeaderModel.setPoSubType(DUMMY);
		validationHeaderModel.setPoSiteCCN(DUMMY);
		validationHeaderModel.setVendorLoc(DUMMY);
		validationHeaderModel.setVendorCCN(DUMMY);
		validationHeaderModel.setBillToLocation(DUMMY);
		validationHeaderModel.setEmailAddress(DUMMY);
		validationHeaderModel.setGroupId(DUMMY);
		validationHeaderModel.setPoAmount(1d);
		validationHeaderModel.setDefaultShipToLocation(DUMMY);
		validationHeaderModel.setStatusCode("SUCCESS");
		validationHeaderModel.setLines(validationLineModelList);
		validationHeaderModelList.add(validationHeaderModel);

		validationLineModelList = new ArrayList<ValidationLineModel>();
		validationLineModel = new ValidationLineModel();
		validationLineModel.setItem("Item1");
		validationLineModel.setQuantity(BigDecimal.ONE);
		validationLineModel.setLineOldPrice(BigDecimal.ONE);
		validationLineModel.setUnitPrice(1d);
		validationLineModel.setLineOldQuantity(BigDecimal.ONE);
		validationLineModel.setAction("UPDATE");
		validationLineModel.setStatusCode("SUCCESS");
		validationLineModelList.add(validationLineModel);

		validationLineModel = new ValidationLineModel();
		validationLineModel.setItem("Item2");
		validationLineModel.setQuantity(BigDecimal.ONE);
		validationLineModel.setLineOldPrice(BigDecimal.ONE);
		validationLineModel.setStatusCode("SUCCESS");
		validationLineModel.setAction("UPDATE");
		validationLineModelList.add(validationLineModel);

		validationHeaderModel = new ValidationHeaderModel();
		validationHeaderModel.setPoSite(DUMMY);
		validationHeaderModel.setPoType(DUMMY);
		validationHeaderModel.setPoSubType(DUMMY);
		validationHeaderModel.setPoSiteCCN(DUMMY);
		validationHeaderModel.setVendorLoc(DUMMY);
		validationHeaderModel.setVendorCCN(DUMMY);
		validationHeaderModel.setBillToLocation(DUMMY);
		validationHeaderModel.setEmailAddress(DUMMY);
		validationHeaderModel.setGroupId(DUMMY);
		validationHeaderModel.setPoAmount(1d);
		validationHeaderModel.setPoSite(DUMMY);
		validationHeaderModel.setDefaultShipToLocation(DUMMY);
		validationHeaderModel.setStatusCode("SUCCESS");
		validationHeaderModel.setLines(validationLineModelList);
		validationHeaderModelList.add(validationHeaderModel);

		validationResponse.setHeaderModels(validationHeaderModelList);

		validationResponse.setStatusCode("SUCCESS");
		return validationResponse;

	}

	public static ValidationModel DummyValidationRespForCreateWithCostTypeMissing() {
		ValidationModel validationResponse = new ValidationModel();

		List<ValidationHeaderModel> validationHeaderModelList = new ArrayList<ValidationHeaderModel>();

		List<ValidationLineModel> validationLineModelList = new ArrayList<ValidationLineModel>();
		ValidationLineModel validationLineModel = new ValidationLineModel();
		validationLineModel.setItem(DUMMY);

		validationLineModel.setStatusCode("SUCCESS");
		validationLineModelList.add(validationLineModel);

		ValidationHeaderModel validationHeaderModel = new ValidationHeaderModel();
		validationHeaderModel.setPoSite(DUMMY);
		validationHeaderModel.setVendorCCN(DUMMY);
		validationHeaderModel.setPoSiteCCN(DUMMY);
		validationHeaderModel.setVendorLoc(DUMMY);
		validationHeaderModel.setBillToLocation(DUMMY);
		validationHeaderModel.setEmailAddress(DUMMY);
		validationHeaderModel.setGroupId(DUMMY);
		validationHeaderModel.setPoSite(DUMMY);
		validationHeaderModel.setDefaultShipToLocation(DUMMY);
		validationHeaderModel.setStatusCode("SUCCESS");
		validationHeaderModel.setLines(validationLineModelList);
		validationHeaderModelList.add(validationHeaderModel);

		validationResponse.setHeaderModels(validationHeaderModelList);

		validationResponse.setStatusCode("SUCCESS");
		return validationResponse;

	}

	public static BPACreationInputModel DummyBpaCreationInputModelWithInvalidField() {

		List<BPACreationModel> BPACreationModelList = new ArrayList<>();

		BPACreationModel BPACreationModel = new BPACreationModel();
		BPACreationModel.setItem(DUMMY);
		BPACreationModel.setGroupId(DUMMY);
		// BPACreationModel.setOperatingUnit(DUMMY);
		BPACreationModel.setLastTimeBuy("Y");
		BPACreationModel.setQuantity(new BigDecimal(10));
		// BPACreationModel.setStyleName(DUMMY);
		// BPACreationModel.setSupplier(DUMMY);
		// BPACreationModel.setSite(DUMMY);
		// BPACreationModel.setVmiDirect(DUMMY);
		// BPACreationModel.setInventoryOrg(DUMMY);
		// BPACreationModel.setAllowPriceOveride("N");
		// BPACreationModel.setInternalComments(DUMMY);
		// BPACreationModel.setPrice(10.0);

		BPACreationModelList.add(BPACreationModel);

		BPACreationInputModel BPACreationInputModel = new BPACreationInputModel();
		BPACreationInputModel.setFileName("a.text");
		BPACreationInputModel.setUserName("A");
		BPACreationInputModel.setBpaCreationModels(BPACreationModelList);

		return BPACreationInputModel;
	}

	public static BPACreationInputModel createDummyBpaCreationInputModelForDefaultValue() {

		List<BPACreationModel> BPACreationModelList = new ArrayList<>();

		BPACreationModel BPACreationModel = new BPACreationModel();
		BPACreationModel.setItem(DUMMY);
		BPACreationModel.setGroupId(DUMMY);
		BPACreationModel.setOperatingUnit(DUMMY);
		BPACreationModel.setLastTimeBuy("N");
		BPACreationModel.setQuantity(new BigDecimal(10));
		BPACreationModel.setStyleName(DUMMY);
		BPACreationModel.setSupplier(DUMMY);
		BPACreationModel.setSupplierSite(DUMMY);
		BPACreationModel.setReasonCode("40");
		BPACreationModel.setInternalComments(DUMMY);
		BPACreationModel.setPrice(10.0);
		BPACreationModel.setPoSite(DUMMY);
		BPACreationModel.setDefaultShipToLocation(DUMMY);

		BPACreationModelList.add(BPACreationModel);

		BPACreationInputModel BPACreationInputModel = new BPACreationInputModel();
		BPACreationInputModel.setFileName("a.text");
		BPACreationInputModel.setUserName("A");
		BPACreationInputModel.setBpaCreationModels(BPACreationModelList);

		return BPACreationInputModel;
	}

	public static BPAUpdationInputModel createDummyBpaUpdationInputModelForDefaultValue() {

		List<BPAUpdationModel> BPAUpdationModelList = new ArrayList<>();

		BPAUpdationModel BPAUpdationModel = new BPAUpdationModel();
		BPAUpdationModel.setItem(DUMMY);
		BPAUpdationModel.setOperatingUnit(DUMMY);
		BPAUpdationModel.setLastTimeBuy("N");
		BPAUpdationModel.setQuantity(new BigDecimal(10));
		BPAUpdationModel.setReasonCode("40");
		BPAUpdationModel.setInternalComments(DUMMY);
		BPAUpdationModel.setPrice(10.0);
		BPAUpdationModel.setAction("A");
		BPAUpdationModel.setInventoryOrg(DUMMY);
		BPAUpdationModel.setAllowPriceOverride("N");

		BPAUpdationModelList.add(BPAUpdationModel);

		BPAUpdationInputModel BPAUpdationInputModel = new BPAUpdationInputModel();
		BPAUpdationInputModel.setFileName("a.text");
		BPAUpdationInputModel.setUserName("A");
		BPAUpdationInputModel.setBpaUpdationModels(BPAUpdationModelList);

		return BPAUpdationInputModel;
	}

	public static ImportOutputModel prepareDummyPassedImportResponse() {

		ImportLineModel importLineModel = new ImportLineModel();
		importLineModel.setItem(DUMMY);
		importLineModel.setStatusCode("S");
		importLineModel.setErrorMessage(DUMMY);

		List<ImportLineModel> importLineModelList = new ArrayList<>();
		importLineModelList.add(importLineModel);

		ImportHeaderModel importHeaderModel = new ImportHeaderModel();
		importHeaderModel.setAttachmentFileName(DUMMY);
		importHeaderModel.setExistingPoNumber(DUMMY);
		importHeaderModel.setGroupId(DUMMY);
		importHeaderModel.setLines(importLineModelList);
		importHeaderModel.setErrorMessage(DUMMY);
		importHeaderModel.setStatusCode("S");
		List<ImportHeaderModel> importHeaderModelList = new ArrayList<>();
		importHeaderModelList.add(importHeaderModel);

		ImportEBSOutputModel importEBSOutputModel = new ImportEBSOutputModel();
		importEBSOutputModel.setBulkUploadImportHeaderModel(importHeaderModel);
		importEBSOutputModel.setStatusCode("S");

		List<ImportEBSOutputModel> importEBSOutputModelList = new ArrayList<>();
		importEBSOutputModelList.add(importEBSOutputModel);

		ImportOutputModel importOutputModel = new ImportOutputModel();

		importOutputModel.setBulkUploadImportOutput(importEBSOutputModelList);

		return importOutputModel;

	}

}