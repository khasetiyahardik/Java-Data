/*
 * package com.dell.prism.eagle.bulkuploadbpa.handler;
 * 
 * import org.junit.Test; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * @SpringBootTest class BulkuploadBpahandlerServiceXxipo039ApplicationTests {
 * 
 * @Test void contextLoads() { }
 * 
 * }
 */