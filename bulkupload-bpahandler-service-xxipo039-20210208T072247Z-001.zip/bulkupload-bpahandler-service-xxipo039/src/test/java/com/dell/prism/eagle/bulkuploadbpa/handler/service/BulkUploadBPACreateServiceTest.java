
package com.dell.prism.eagle.bulkuploadbpa.handler.service;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import org.apache.commons.lang.RandomStringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.dell.prism.eagle.bulkuploadbpa.handler.exception.ApiException;
import com.dell.prism.eagle.bulkuploadbpa.handler.integrator.BulkUploadBPAIntegrator;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPACreationInputModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPACreationModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BPACreationResponseModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.model.BulkUploadPayloadModel;
import com.dell.prism.eagle.bulkuploadbpa.handler.util.TestUtil;
import com.dell.prism.eagle.bulkuploadbpa.handler.utility.BulkUploadBPAUtil;

@RunWith(SpringRunner.class)
public class BulkUploadBPACreateServiceTest {

	@Mock
	private BulkUploadBPAUtil util;

	@Mock
	private BulkUploadBPAIntegrator integrator;

	@InjectMocks
	private BulkUploadBPACreateService bulkUploadBPACreateService;

	private static final String DUMMY = "DUMMY";

	BulkUploadPayloadModel<BPACreationModel, BPACreationResponseModel> bulkUploadPayloadModel = new BulkUploadPayloadModel<>();

	@Before
	public void initialize() {
		when(util.initializeBulkUploadErrorModel(Mockito.any(), Mockito.anyString())).thenCallRealMethod();
		when(util.initializeBulkUploadPayloadModel(Mockito.any(), Mockito.anyString())).thenCallRealMethod();
		when(util.initializeBulkUploadPriceModel(Mockito.anyString())).thenCallRealMethod();
		util.initializeBulkUploadPayloadModel(bulkUploadPayloadModel, DUMMY);
	}

	@Test
	public void testInvokePOUpdation() {
		when(integrator.generateTransactionId()).thenReturn(DUMMY);
		bulkUploadBPACreateService.invokeBPACreation(TestUtil.createDummyBpaCreationInputModel());

	}

	@Test
	public void testExecuteBpaCreation() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());

		bulkUploadBPACreateService.executeBPACreation(TestUtil.createDummyBpaCreationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}

	@Test
	public void testForInvalidMandatoryField() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate()); //
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp()); //
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());

		bulkUploadBPACreateService.executeBPACreation(TestUtil.DummyBpaCreationInputModelWithInvalidField(), DUMMY,
				bulkUploadPayloadModel);
	}

	@Test
	public void testValidationFailed() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyFailedValidationResponse()); //
		when(integrator.callbulkUploadImportService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyImportResponseAsLineNull());

		bulkUploadBPACreateService.executeBPACreation(TestUtil.createDummyBpaCreationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}

	@Test
	public void testImportFailed() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		when(integrator.callbulkUploadImportService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyFailedImportResponse());

		bulkUploadBPACreateService.executeBPACreation(TestUtil.createDummyBpaCreationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}

	@Test()
	public void testExceptionForCallingPriceService() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.DummyValidationResponseWithHeaderNull());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp()); //
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		bulkUploadBPACreateService.executeBPACreation(TestUtil.createDummyBpaCreationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}

	@Test
	public void testExecuteBpaCreationWithCostTypeMissing() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.DummyValidationRespForCreateWithCostTypeMissing());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());

		bulkUploadBPACreateService.executeBPACreation(TestUtil.createDummyBpaCreationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}

	@Test
	public void testExecuteBpaCreationForDefaultValue() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());

		bulkUploadBPACreateService.executeBPACreation(TestUtil.createDummyBpaCreationInputModelForDefaultValue(), DUMMY,
				bulkUploadPayloadModel);
	}

	@Test
	public void testExecuteBpaCreationForLengthCheck() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		BPACreationInputModel poCreationInputModel = TestUtil.createDummyBpaCreationInputModel();
		poCreationInputModel.getBpaCreationModels().get(0)
				.setStyleName(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setOperatingUnit(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setSupplier(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setSupplierSite(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setShipTo(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setBillTo(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setDescription(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setTransMethod(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setFreightCarrier(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setClauses(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setAttachment(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setItem(RandomStringUtils.randomAlphanumeric(1001).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setLastTimeBuy(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setLineComments(RandomStringUtils.randomAlphanumeric(1001).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setInternalComments(RandomStringUtils.randomAlphanumeric(1001).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setReasonCode(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setVmiDirect(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setAllowPriceOverride(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setInventoryOrg(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setFreightCarrier(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setIccSlcLocation(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
		poCreationInputModel.getBpaCreationModels().get(0)
				.setDeliveryTerms(RandomStringUtils.randomAlphanumeric(256).toUpperCase());

		bulkUploadBPACreateService.executeBPACreation(poCreationInputModel, DUMMY, bulkUploadPayloadModel);
		poCreationInputModel.getBpaCreationModels().get(0)
				.setStyleName(RandomStringUtils.randomAlphanumeric(256).toUpperCase());
	}

	@Test
	public void testExecutePOUpdation_Validation_ApiException() {

		when(integrator.callbulkUploadValidationService(Mockito.any())).thenThrow(ApiException.class);
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());

		bulkUploadBPACreateService.executeBPACreation(TestUtil.createDummyBpaCreationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}

	@Test
	public void testExecutePOUpdation_Validation_Exception() {

		when(integrator.callbulkUploadValidationService(Mockito.any())).thenThrow(NullPointerException.class);
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());

		bulkUploadBPACreateService.executeBPACreation(TestUtil.createDummyBpaCreationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}

	@Test
	public void testImportException() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenThrow(NullPointerException.class);

		bulkUploadBPACreateService.executeBPACreation(TestUtil.createDummyBpaCreationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}
	
	@Test
	public void testExecutePOCreation3() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenReturn(TestUtil.prepareDummyPriceResp());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenThrow(ApiException.class);
		bulkUploadBPACreateService.executeBPACreation(TestUtil.createDummyBpaCreationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}
	@Test
	public void testExecutePOCreation4() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
		.thenThrow(RuntimeException.class);
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenThrow(ApiException.class);
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		bulkUploadBPACreateService.executeBPACreation(TestUtil.createDummyBpaCreationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}
	@Test
	public void testExecutePOCreation5() {

		when(integrator.callbulkUploadValidationService(Mockito.any()))
				.thenReturn(TestUtil.prepareDummyValidationResponseForCreate());
		when(integrator.fetchPOPrice(Mockito.any(), Mockito.anyString())).thenThrow(ApiException.class);
		doThrow(new ApiException("test")).when(integrator).savePricePayloadCollection(Mockito.any());
		when(integrator.callbulkUploadImportService(Mockito.any())).thenReturn(TestUtil.prepareDummyImportResponse());
		bulkUploadBPACreateService.executeBPACreation(TestUtil.createDummyBpaCreationInputModel(), DUMMY,
				bulkUploadPayloadModel);
	}
}
